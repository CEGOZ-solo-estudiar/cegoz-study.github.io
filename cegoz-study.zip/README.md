# CEGOZ Study

Plataforma educativa con IA: subes tus apuntes y un profesor virtual te explica,
te pregunta, te examina, te corrige y te ayuda a mejorar usando solo tu material.

## Qué hace

- **Temarios**: sube PDF, fotos, Word, TXT o texto pegado. Se organizan por
  asignaturas y temas, y se pueden eliminar o sustituir.
- **Modo clase**: el profesor virtual explica por apartados, hace una pregunta
  cada vez, espera la respuesta, la corrige y vuelve a preguntar lo que no has
  acertado.
- **Modo examen**: elige dificultad, número de preguntas y tipos (test,
  desarrollo, prácticos). Una pregunta cada vez, corrección automática con nota
  sobre 10 y explicación de cada fallo.
- **Práctica**: preguntas sueltas con corrección inmediata, repetición de las
  falladas y dificultad adaptable.
- **Resúmenes y tarjetas**: resumen completo, esquema, conceptos esenciales,
  definiciones, tarjetas de memoria y preguntas de repaso.
- **Progreso**: temas estudiados, exámenes, calificaciones, conceptos dominados
  y a repasar, e historial de sesiones.
- **Cuentas**: registro con confirmación por correo, inicio y cierre de sesión y
  recuperación de contraseña. Cada usuario solo accede a sus datos.

## Tecnología

- [TanStack Start](https://tanstack.com/start) (React 19 + Vite 7), TypeScript.
- Tailwind CSS 4.
- Backend en Lovable Cloud (base de datos, almacenamiento, autenticación y
  funciones de servidor). La IA se llama desde el servidor: ninguna clave
  privada va en el navegador.
- Pruebas con Vitest.

## Estructura

```text
src/
  routes/            páginas (portada, acceso, panel y pantallas de estudio)
  components/        interfaz reutilizable
  lib/functions/     funciones de servidor (IA, documentos, exámenes, progreso)
  lib/study/         reglas de estudio y corrección (notas, dificultad, dominio)
  integrations/      cliente del backend (autogenerado, no editar)
supabase/schema.sql  esquema completo de la base de datos
```

## Puesta en marcha

1. Instala las dependencias:

   ```sh
   bun install    # o: npm install
   ```

2. Copia `.env.example` a `.env` y comprueba la URL y la clave publicable del
   backend. Son valores publicables por diseño; las claves privadas viven solo
   en el servidor.

3. Prepara la base de datos: ejecuta `supabase/schema.sql` sobre una base de
   datos de Supabase (crea las 12 tablas, las claves, los índices, las políticas
   por usuario y el depósito de archivos).

4. Arranca en local:

   ```sh
   bun run dev
   ```

## Comandos

| Comando            | Para qué                                  |
| ------------------ | ----------------------------------------- |
| `bun run dev`      | Servidor de desarrollo                     |
| `bun run build`    | Compilación de producción                  |
| `bun run preview`  | Servir la compilación                      |
| `bun test`         | Pruebas automatizadas                      |
| `bun run lint`     | Revisión de código                         |
| `bun run format`   | Formato automático                         |

## Subir a GitHub

```sh
git init
git add .
git commit -m "CEGOZ Study"
git branch -M main
git remote add origin https://github.com/<tu-usuario>/<tu-repo>.git
git push -u origin main
```

Antes del primer `git add .`, comprueba que `.gitignore` incluye `.env`: si no
está, añádelo. Así la configuración del backend se queda fuera del repositorio.

## Notas

- Este paquete no incluye `.env`, solo la plantilla `.env.example`.
- Las soluciones de exámenes y prácticas viven en `question_keys`, sin política
  de lectura: solo el servidor las consulta para corregir.
- `src/integrations/` y `.env` los genera el backend; no se editan a mano.
