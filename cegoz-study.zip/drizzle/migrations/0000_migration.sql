
-- Profiles
CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name text NOT NULL DEFAULT '',
  level text NOT NULL DEFAULT 'intermedio',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Own profile select" ON public.profiles FOR SELECT TO authenticated USING (auth.uid() = id);
CREATE POLICY "Own profile insert" ON public.profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);
CREATE POLICY "Own profile update" ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, display_name)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'display_name', NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'name', split_part(NEW.email, '@', 1), ''))
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END; $$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

CREATE OR REPLACE FUNCTION public.touch_updated_at()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;
CREATE TRIGGER profiles_touch BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- Subjects
CREATE TABLE public.subjects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  name text NOT NULL,
  color text NOT NULL DEFAULT 'blue',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX subjects_user_idx ON public.subjects(user_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.subjects TO authenticated;
GRANT ALL ON public.subjects TO service_role;
ALTER TABLE public.subjects ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Own subjects" ON public.subjects FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Topics
CREATE TABLE public.topics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  subject_id uuid NOT NULL REFERENCES public.subjects(id) ON DELETE CASCADE,
  name text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX topics_user_idx ON public.topics(user_id);
CREATE INDEX topics_subject_idx ON public.topics(subject_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.topics TO authenticated;
GRANT ALL ON public.topics TO service_role;
ALTER TABLE public.topics ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Own topics" ON public.topics FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Documents
CREATE TABLE public.documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  topic_id uuid NOT NULL REFERENCES public.topics(id) ON DELETE CASCADE,
  title text NOT NULL,
  source_type text NOT NULL,
  storage_path text,
  mime_type text,
  size_bytes bigint,
  content text NOT NULL DEFAULT '',
  char_count integer NOT NULL DEFAULT 0,
  summary text,
  key_concepts jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX documents_user_idx ON public.documents(user_id);
CREATE INDEX documents_topic_idx ON public.documents(topic_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.documents TO authenticated;
GRANT ALL ON public.documents TO service_role;
ALTER TABLE public.documents ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Own documents" ON public.documents FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE TRIGGER documents_touch BEFORE UPDATE ON public.documents FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- Class sessions
CREATE TABLE public.class_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  topic_id uuid NOT NULL REFERENCES public.topics(id) ON DELETE CASCADE,
  title text NOT NULL DEFAULT 'Clase',
  progress_note text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX class_sessions_user_idx ON public.class_sessions(user_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.class_sessions TO authenticated;
GRANT ALL ON public.class_sessions TO service_role;
ALTER TABLE public.class_sessions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Own class sessions" ON public.class_sessions FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE TRIGGER class_sessions_touch BEFORE UPDATE ON public.class_sessions FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TABLE public.class_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  session_id uuid NOT NULL REFERENCES public.class_sessions(id) ON DELETE CASCADE,
  role text NOT NULL,
  kind text NOT NULL DEFAULT 'message',
  content text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX class_messages_session_idx ON public.class_messages(session_id, created_at);
GRANT SELECT, INSERT, DELETE ON public.class_messages TO authenticated;
GRANT ALL ON public.class_messages TO service_role;
ALTER TABLE public.class_messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Own class messages" ON public.class_messages FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Exams
CREATE TABLE public.exams (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  topic_id uuid NOT NULL REFERENCES public.topics(id) ON DELETE CASCADE,
  difficulty text NOT NULL,
  question_count integer NOT NULL,
  question_types jsonb NOT NULL DEFAULT '[]'::jsonb,
  status text NOT NULL DEFAULT 'en_curso',
  score numeric(4,2),
  feedback text,
  created_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz
);
CREATE INDEX exams_user_idx ON public.exams(user_id, created_at DESC);
GRANT SELECT, DELETE ON public.exams TO authenticated;
GRANT ALL ON public.exams TO service_role;
ALTER TABLE public.exams ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Own exams select" ON public.exams FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Own exams delete" ON public.exams FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- Questions (exam + practice). Written only by the server.
CREATE TABLE public.questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  topic_id uuid NOT NULL REFERENCES public.topics(id) ON DELETE CASCADE,
  exam_id uuid REFERENCES public.exams(id) ON DELETE CASCADE,
  source text NOT NULL,
  position integer NOT NULL DEFAULT 0,
  qtype text NOT NULL,
  difficulty text NOT NULL,
  prompt text NOT NULL,
  options jsonb,
  concept text,
  user_answer text,
  is_correct boolean,
  score numeric(4,3),
  feedback text,
  answered_at timestamptz,
  retry_of uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX questions_user_idx ON public.questions(user_id, created_at DESC);
CREATE INDEX questions_exam_idx ON public.questions(exam_id, position);
GRANT SELECT ON public.questions TO authenticated;
GRANT ALL ON public.questions TO service_role;
ALTER TABLE public.questions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Own questions select" ON public.questions FOR SELECT TO authenticated USING (auth.uid() = user_id);

-- Hidden solutions: never readable by students directly.
CREATE TABLE public.question_keys (
  question_id uuid PRIMARY KEY REFERENCES public.questions(id) ON DELETE CASCADE,
  correct_answer text NOT NULL,
  explanation text NOT NULL,
  rubric text
);
GRANT ALL ON public.question_keys TO service_role;
ALTER TABLE public.question_keys ENABLE ROW LEVEL SECURITY;

-- Study materials (summaries, outlines, flashcards...)
CREATE TABLE public.study_materials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  topic_id uuid NOT NULL REFERENCES public.topics(id) ON DELETE CASCADE,
  kind text NOT NULL,
  title text NOT NULL,
  content text NOT NULL DEFAULT '',
  data jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX study_materials_user_idx ON public.study_materials(user_id, created_at DESC);
GRANT SELECT, INSERT, DELETE ON public.study_materials TO authenticated;
GRANT ALL ON public.study_materials TO service_role;
ALTER TABLE public.study_materials ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Own materials" ON public.study_materials FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Concept mastery
CREATE TABLE public.concept_mastery (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  topic_id uuid NOT NULL REFERENCES public.topics(id) ON DELETE CASCADE,
  concept text NOT NULL,
  correct_count integer NOT NULL DEFAULT 0,
  incorrect_count integer NOT NULL DEFAULT 0,
  last_seen_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, topic_id, concept)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.concept_mastery TO authenticated;
GRANT ALL ON public.concept_mastery TO service_role;
ALTER TABLE public.concept_mastery ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Own mastery" ON public.concept_mastery FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.record_concept_result(_topic_id uuid, _concept text, _correct boolean)
RETURNS void LANGUAGE plpgsql SECURITY INVOKER SET search_path = public AS $$
BEGIN
  IF auth.uid() IS NULL OR _concept IS NULL OR length(trim(_concept)) = 0 THEN RETURN; END IF;
  INSERT INTO public.concept_mastery (user_id, topic_id, concept, correct_count, incorrect_count)
  VALUES (auth.uid(), _topic_id, left(trim(_concept), 200), CASE WHEN _correct THEN 1 ELSE 0 END, CASE WHEN _correct THEN 0 ELSE 1 END)
  ON CONFLICT (user_id, topic_id, concept) DO UPDATE SET
    correct_count = public.concept_mastery.correct_count + CASE WHEN _correct THEN 1 ELSE 0 END,
    incorrect_count = public.concept_mastery.incorrect_count + CASE WHEN _correct THEN 0 ELSE 1 END,
    last_seen_at = now();
END; $$;
GRANT EXECUTE ON FUNCTION public.record_concept_result(uuid, text, boolean) TO authenticated;

-- Activity history
CREATE TABLE public.study_activity (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  topic_id uuid REFERENCES public.topics(id) ON DELETE CASCADE,
  kind text NOT NULL,
  title text NOT NULL,
  score numeric(4,2),
  details jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX study_activity_user_idx ON public.study_activity(user_id, created_at DESC);
GRANT SELECT, INSERT, DELETE ON public.study_activity TO authenticated;
GRANT ALL ON public.study_activity TO service_role;
ALTER TABLE public.study_activity ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Own activity" ON public.study_activity FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Storage policies for the private "temarios" bucket: files live under <user_id>/...
CREATE POLICY "Own temario files read" ON storage.objects FOR SELECT TO authenticated USING (bucket_id = 'temarios' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "Own temario files insert" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'temarios' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "Own temario files update" ON storage.objects FOR UPDATE TO authenticated USING (bucket_id = 'temarios' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "Own temario files delete" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'temarios' AND (storage.foldername(name))[1] = auth.uid()::text);
