import { useQueryClient } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { ArrowRight, CheckCircle2, Dumbbell, RotateCcw, XCircle } from "lucide-react";
import {
  answerPractice,
  generatePractice,
  retryFailedPractice,
  type PracticeQuestion,
} from "@/lib/functions/practice.functions";
import { topicSearchSchema } from "@/lib/client/search";
import { errorMessage } from "@/lib/client/errors";
import { pageHead } from "@/lib/client/format";
import {
  DIFFICULTY_LABELS,
  QUESTION_TYPE_LABELS,
  type Difficulty,
  type QuestionType,
} from "@/lib/study/grading";
import { cn } from "@/lib/utils";
import { PageHeader } from "@/components/study/page-header";
import { TopicSelect } from "@/components/study/topic-select";
import { AIWorking } from "@/components/study/ai-working";
import { Markdown } from "@/components/study/markdown";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";

export const Route = createFileRoute("/_authenticated/practica")({
  validateSearch: topicSearchSchema,
  head: () =>
    pageHead(
      "Práctica",
      "Preguntas con corrección inmediata, dificultad adaptable y repaso de lo que fallas.",
    ),
  component: PracticePage,
});

type Mode = "mixta" | "test" | "rapida" | "ejercicio";
const MODES: { id: Mode; label: string }[] = [
  { id: "mixta", label: "Mixta" },
  { id: "test", label: "Tipo test" },
  { id: "rapida", label: "Preguntas rápidas" },
  { id: "ejercicio", label: "Ejercicios" },
];
type Level = Difficulty | "adaptativa";
const LEVELS: { id: Level; label: string }[] = [
  { id: "adaptativa", label: "Adaptativa" },
  { id: "facil", label: "Fácil" },
  { id: "media", label: "Media" },
  { id: "dificil", label: "Difícil" },
];
type Result = Awaited<ReturnType<typeof answerPractice>>;

function Chips<T extends string>({
  items,
  value,
  onChange,
}: {
  items: { id: T; label: string }[];
  value: T;
  onChange: (v: T) => void;
}) {
  return (
    <div className="flex flex-wrap gap-2">
      {items.map((it) => (
        <button
          key={it.id}
          type="button"
          aria-pressed={value === it.id}
          onClick={() => onChange(it.id)}
          className={cn(
            "rounded-full border px-3.5 py-1.5 text-sm font-medium transition-colors",
            value === it.id
              ? "border-primary bg-secondary text-secondary-foreground"
              : "hover:bg-secondary/50",
          )}
        >
          {it.label}
        </button>
      ))}
    </div>
  );
}

function PracticePage() {
  const { tema } = Route.useSearch();
  const qc = useQueryClient();
  const [topicId, setTopicId] = useState<string | undefined>(tema);
  const [mode, setMode] = useState<Mode>("mixta");
  const [level, setLevel] = useState<Level>("adaptativa");
  const [loading, setLoading] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [round, setRound] = useState<{
    questions: PracticeQuestion[];
    difficulty?: string;
    retry: boolean;
  } | null>(null);
  const [index, setIndex] = useState(0);
  const [results, setResults] = useState<Record<string, Result>>({});

  async function start(kind: "new" | "retry") {
    if (!topicId) return;
    setError(null);
    setLoading(
      kind === "new"
        ? "Preparando preguntas de tu temario…"
        : "Buscando las preguntas que fallaste…",
    );
    try {
      if (kind === "new") {
        const r = await generatePractice({ data: { topicId, mode, difficulty: level, count: 5 } });
        setRound({ questions: r.questions, difficulty: r.difficulty, retry: false });
      } else {
        const r = await retryFailedPractice({ data: { topicId } });
        if (r.questions.length === 0) {
          setError("¡No tienes preguntas falladas pendientes en este tema!");
          setRound(null);
          return;
        }
        setRound({ questions: r.questions, retry: true });
      }
      setIndex(0);
      setResults({});
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setLoading(null);
    }
  }

  const done = round && index >= round.questions.length;
  const correct = Object.values(results).filter((r) => r.isCorrect).length;

  return (
    <div className="mx-auto max-w-3xl">
      <PageHeader
        eyebrow="Práctica"
        title="Practica con corrección inmediata"
        description="Responde y recibe al momento la corrección y la explicación. En modo adaptativo la dificultad cambia según aciertes o falles."
      />

      <section className="space-y-4 rounded-2xl border bg-card p-5 shadow-soft">
        <div className="space-y-1.5">
          <Label htmlFor="practice-topic">Tema</Label>
          <TopicSelect
            id="practice-topic"
            value={topicId}
            onChange={(v) => {
              setTopicId(v);
              setRound(null);
            }}
          />
        </div>
        <div className="space-y-2">
          <Label>Tipo</Label>
          <Chips items={MODES} value={mode} onChange={setMode} />
        </div>
        <div className="space-y-2">
          <Label>Dificultad</Label>
          <Chips items={LEVELS} value={level} onChange={setLevel} />
        </div>
        {loading ? (
          <AIWorking label={loading} />
        ) : (
          <div className="flex flex-wrap gap-2">
            <Button variant="brand" disabled={!topicId} onClick={() => start("new")}>
              <Dumbbell /> {round ? "Nueva tanda" : "Empezar a practicar"}
            </Button>
            <Button variant="outline" disabled={!topicId} onClick={() => start("retry")}>
              <RotateCcw /> Repetir falladas
            </Button>
          </div>
        )}
        {error && (
          <p role="alert" className="rounded-lg bg-secondary px-3 py-2 text-sm">
            {error}
          </p>
        )}
      </section>

      {round && !loading && (
        <div className="mt-6">
          <div className="mb-2 flex items-center justify-between text-sm text-muted-foreground">
            <span>
              {round.retry
                ? "Repaso de falladas"
                : `Dificultad: ${DIFFICULTY_LABELS[round.difficulty as Difficulty] ?? "—"}`}
            </span>
            <span>
              {correct} aciertos · {Math.min(index + 1, round.questions.length)}/
              {round.questions.length}
            </span>
          </div>
          <Progress value={(Object.keys(results).length / round.questions.length) * 100} />
          {done ? (
            <section className="mt-5 rounded-2xl border bg-card p-6 text-center shadow-soft">
              <p className="font-display text-4xl font-extrabold text-gradient-brand">
                {correct}/{round.questions.length}
              </p>
              <p className="mt-1 font-semibold">
                {correct === round.questions.length
                  ? "¡Perfecto!"
                  : correct >= round.questions.length / 2
                    ? "¡Buen trabajo!"
                    : "Sigue practicando"}
              </p>
              <div className="mt-4 flex flex-wrap justify-center gap-2">
                <Button variant="brand" onClick={() => start("new")}>
                  <Dumbbell /> Otra tanda
                </Button>
                {correct < round.questions.length && (
                  <Button variant="outline" onClick={() => start("retry")}>
                    <RotateCcw /> Repetir falladas
                  </Button>
                )}
              </div>
            </section>
          ) : (
            round.questions[index] && (
              <QuestionCard
                key={round.questions[index].id}
                question={round.questions[index]}
                result={results[round.questions[index].id]}
                onResult={(r) => {
                  setResults((prev) => ({ ...prev, [round.questions[index]!.id]: r }));
                  void qc.invalidateQueries({ queryKey: ["progress"] });
                }}
                onNext={() => setIndex((i) => i + 1)}
                isLast={index === round.questions.length - 1}
              />
            )
          )}
        </div>
      )}
    </div>
  );
}

function QuestionCard({
  question,
  result,
  onResult,
  onNext,
  isLast,
}: {
  question: PracticeQuestion;
  result: Result | undefined;
  onResult: (r: Result) => void;
  onNext: () => void;
  isLast: boolean;
}) {
  const [answer, setAnswer] = useState("");
  const [checking, setChecking] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const options = question.options ?? [];

  async function check(e?: FormEvent) {
    e?.preventDefault();
    if (!answer.trim() || result) return;
    setChecking(true);
    setError(null);
    try {
      onResult(await answerPractice({ data: { questionId: question.id, answer } }));
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setChecking(false);
    }
  }

  const correctText =
    question.qtype === "test" && result
      ? options[Number(result.correctAnswer)]
      : result?.correctAnswer;

  return (
    <form onSubmit={check} className="mt-5 rounded-2xl border bg-card p-5 shadow-soft sm:p-6">
      <p className="text-xs font-semibold uppercase tracking-wider text-accent-foreground">
        {QUESTION_TYPE_LABELS[question.qtype as QuestionType] ?? question.qtype}
        {question.concept ? ` · ${question.concept}` : ""}
      </p>
      <Markdown className="mt-2 text-base font-medium">{question.prompt}</Markdown>

      {question.qtype === "test" ? (
        <div className="mt-4 space-y-2" role="radiogroup" aria-label="Opciones">
          {options.map((opt, i) => {
            const picked = answer === String(i);
            const isRight = result && Number(result.correctAnswer) === i;
            return (
              <button
                key={i}
                type="button"
                role="radio"
                aria-checked={picked}
                disabled={!!result}
                onClick={() => setAnswer(String(i))}
                className={cn(
                  "flex w-full items-start gap-3 rounded-xl border px-4 py-3 text-left text-sm transition-colors",
                  isRight && "border-success bg-success/10",
                  result && picked && !isRight && "border-destructive bg-destructive/10",
                  !result && picked && "border-primary bg-secondary",
                  !result && !picked && "hover:bg-secondary/50",
                )}
              >
                <span className="grid size-6 shrink-0 place-items-center rounded-full border text-xs font-bold">
                  {String.fromCharCode(65 + i)}
                </span>
                <span>{opt}</span>
              </button>
            );
          })}
        </div>
      ) : question.qtype === "rapida" ? (
        <Input
          className="mt-4"
          value={answer}
          onChange={(e) => setAnswer(e.target.value)}
          disabled={!!result}
          placeholder="Tu respuesta"
          aria-label="Tu respuesta"
        />
      ) : (
        <Textarea
          className="mt-4"
          rows={6}
          value={answer}
          onChange={(e) => setAnswer(e.target.value)}
          disabled={!!result}
          placeholder="Escribe tu respuesta…"
          aria-label="Tu respuesta"
        />
      )}

      {error && (
        <p role="alert" className="mt-3 text-sm text-destructive">
          {error}
        </p>
      )}

      {result && (
        <div
          className={cn(
            "mt-4 rounded-xl border p-4 text-sm",
            result.isCorrect
              ? "border-success/40 bg-success/10"
              : "border-destructive/30 bg-destructive/5",
          )}
        >
          <p className="flex items-center gap-2 font-semibold">
            {result.isCorrect ? (
              <CheckCircle2 className="size-4 text-success" />
            ) : (
              <XCircle className="size-4 text-destructive" />
            )}
            {result.feedback}
          </p>
          {!result.isCorrect && correctText && (
            <p className="mt-2">
              <span className="font-semibold">Respuesta correcta: </span>
              {correctText}
            </p>
          )}
          {result.explanation && <p className="mt-2 text-muted-foreground">{result.explanation}</p>}
        </div>
      )}

      <div className="mt-5 flex justify-end">
        {checking ? (
          <AIWorking label="Corrigiendo…" />
        ) : result ? (
          <Button type="button" variant="brand" onClick={onNext}>
            {isLast ? "Ver resultado" : "Siguiente"} <ArrowRight />
          </Button>
        ) : (
          <Button type="submit" variant="brand" disabled={!answer.trim()}>
            Comprobar
          </Button>
        )}
      </div>
    </form>
  );
}
