import { useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { toast } from "sonner";
import { LogOut } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { profileQuery, userQuery } from "@/lib/client/queries";
import { pageHead } from "@/lib/client/format";
import { toastError } from "@/lib/client/errors";
import { STUDENT_LEVELS, type StudentLevel } from "@/lib/study/prompts";
import { PageHeader } from "@/components/study/page-header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export const Route = createFileRoute("/_authenticated/perfil")({
  head: () => pageHead("Mi perfil", "Tu nombre, tu nivel de estudios y la seguridad de tu cuenta."),
  loader: ({ context }) =>
    Promise.all([
      context.queryClient.ensureQueryData(profileQuery),
      context.queryClient.ensureQueryData(userQuery),
    ]),
  component: ProfilePage,
});

function ProfilePage() {
  const { data: profile } = useSuspenseQuery(profileQuery);
  const { data: user } = useSuspenseQuery(userQuery);
  const qc = useQueryClient();
  const navigate = useNavigate();
  const [name, setName] = useState(profile?.display_name ?? "");
  const [level, setLevel] = useState<string>(profile?.level ?? "intermedio");
  const [saving, setSaving] = useState(false);
  const [password, setPassword] = useState("");
  const [pwSaving, setPwSaving] = useState(false);

  async function saveProfile(e: FormEvent) {
    e.preventDefault();
    if (!user) return;
    setSaving(true);
    const { error } = await supabase
      .from("profiles")
      .update({ display_name: name.trim().slice(0, 80), level })
      .eq("id", user.id);
    setSaving(false);
    if (error) return toastError(new Error("No se ha podido guardar tu perfil."));
    await qc.invalidateQueries({ queryKey: ["profile"] });
    toast.success("Perfil guardado");
  }

  async function savePassword(e: FormEvent) {
    e.preventDefault();
    if (password.length < 8)
      return toastError(new Error("La contraseña debe tener al menos 8 caracteres."));
    setPwSaving(true);
    const { error } = await supabase.auth.updateUser({ password });
    setPwSaving(false);
    if (error)
      return toastError(
        new Error("No se ha podido cambiar la contraseña. Prueba con otra más segura."),
      );
    setPassword("");
    toast.success("Contraseña actualizada");
  }

  async function signOut() {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  return (
    <div className="max-w-2xl">
      <PageHeader
        eyebrow="Cuenta"
        title="Mi perfil"
        description="Tu nivel ayuda al profesor a adaptar sus explicaciones."
      />
      <form onSubmit={saveProfile} className="space-y-4 rounded-2xl border bg-card p-5 shadow-soft">
        <div className="space-y-1.5">
          <Label htmlFor="email">Correo electrónico</Label>
          <Input id="email" value={user?.email ?? ""} disabled />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="display-name">Nombre</Label>
          <Input
            id="display-name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            maxLength={80}
          />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="level">Nivel de estudios</Label>
          <Select value={level} onValueChange={setLevel}>
            <SelectTrigger id="level" className="w-full">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {(Object.keys(STUDENT_LEVELS) as StudentLevel[]).map((k) => (
                <SelectItem key={k} value={k}>
                  {STUDENT_LEVELS[k]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <Button type="submit" variant="brand" disabled={saving}>
          {saving ? "Guardando…" : "Guardar cambios"}
        </Button>
      </form>

      <form
        onSubmit={savePassword}
        className="mt-4 space-y-4 rounded-2xl border bg-card p-5 shadow-soft"
      >
        <h2 className="font-semibold">Cambiar contraseña</h2>
        <div className="space-y-1.5">
          <Label htmlFor="new-password">Nueva contraseña</Label>
          <Input
            id="new-password"
            type="password"
            autoComplete="new-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <p className="text-xs text-muted-foreground">Mínimo 8 caracteres.</p>
        </div>
        <Button type="submit" variant="outline" disabled={pwSaving || !password}>
          {pwSaving ? "Guardando…" : "Cambiar contraseña"}
        </Button>
      </form>

      <Button variant="ghost" className="mt-4 text-muted-foreground" onClick={signOut}>
        <LogOut /> Cerrar sesión
      </Button>
    </div>
  );
}
