import { useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import {
  BookOpenText,
  ChevronRight,
  FolderPlus,
  MoreVertical,
  Pencil,
  Plus,
  Trash2,
} from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { libraryQuery, type LibrarySubject } from "@/lib/client/queries";
import { removeTopicFiles } from "@/lib/client/documents";
import { pageHead } from "@/lib/client/format";
import { toastError } from "@/lib/client/errors";
import { PageHeader } from "@/components/study/page-header";
import { EmptyState } from "@/components/study/empty-state";
import { NameDialog } from "@/components/study/name-dialog";
import { ConfirmDialog } from "@/components/study/confirm-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export const Route = createFileRoute("/_authenticated/temarios/")({
  head: () => pageHead("Temarios", "Organiza tus apuntes por asignaturas y temas."),
  loader: ({ context }) => context.queryClient.ensureQueryData(libraryQuery),
  component: TemariosPage,
});

function useInvalidateLibrary() {
  const qc = useQueryClient();
  return () => qc.invalidateQueries({ queryKey: ["library"] });
}

function TemariosPage() {
  const { data: subjects } = useSuspenseQuery(libraryQuery);
  const invalidate = useInvalidateLibrary();
  const [creating, setCreating] = useState(false);

  async function createSubject(name: string) {
    const { error } = await supabase.from("subjects").insert({ name });
    if (error) {
      toastError(new Error("No se ha podido crear la asignatura."));
      throw error;
    }
    await invalidate();
    toast.success("Asignatura creada");
  }

  return (
    <div>
      <PageHeader
        eyebrow="Temarios"
        title="Tus apuntes"
        description="Crea asignaturas, divídelas en temas y sube tus documentos a cada tema."
        actions={
          <Button variant="brand" onClick={() => setCreating(true)}>
            <FolderPlus /> Nueva asignatura
          </Button>
        }
      />
      {subjects.length === 0 ? (
        <EmptyState
          icon={BookOpenText}
          title="Todavía no tienes asignaturas"
          description="Por ejemplo: «Historia», «Biología» o «Derecho Civil». Después podrás añadir temas y subir tus apuntes."
          action={
            <Button variant="brand" onClick={() => setCreating(true)}>
              <FolderPlus /> Crear mi primera asignatura
            </Button>
          }
        />
      ) : (
        <div className="grid gap-4 lg:grid-cols-2">
          {subjects.map((s) => (
            <SubjectCard key={s.id} subject={s} />
          ))}
        </div>
      )}
      <NameDialog
        open={creating}
        onOpenChange={setCreating}
        title="Nueva asignatura"
        label="Nombre de la asignatura"
        submitLabel="Crear"
        onSubmit={createSubject}
      />
    </div>
  );
}

function SubjectCard({ subject }: { subject: LibrarySubject }) {
  const invalidate = useInvalidateLibrary();
  const [renaming, setRenaming] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [topicName, setTopicName] = useState("");
  const [adding, setAdding] = useState(false);

  async function addTopic(e: FormEvent) {
    e.preventDefault();
    const name = topicName.trim();
    if (!name) return;
    setAdding(true);
    const { error } = await supabase
      .from("topics")
      .insert({ name: name.slice(0, 120), subject_id: subject.id });
    setAdding(false);
    if (error) return toastError(new Error("No se ha podido crear el tema."));
    setTopicName("");
    await invalidate();
  }

  async function rename(name: string) {
    const { error } = await supabase.from("subjects").update({ name }).eq("id", subject.id);
    if (error) {
      toastError(new Error("No se ha podido renombrar la asignatura."));
      throw error;
    }
    await invalidate();
  }

  async function remove() {
    await removeTopicFiles(subject.topics.map((t) => t.id));
    const { error } = await supabase.from("subjects").delete().eq("id", subject.id);
    if (error) {
      toastError(new Error("No se ha podido eliminar la asignatura."));
      throw error;
    }
    await invalidate();
    toast.success("Asignatura eliminada");
  }

  return (
    <section className="rounded-2xl border bg-card p-5 shadow-soft animate-fade-up">
      <div className="flex items-center justify-between gap-2">
        <h2 className="truncate text-lg font-bold">{subject.name}</h2>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" aria-label={`Opciones de ${subject.name}`}>
              <MoreVertical />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onSelect={() => setRenaming(true)}>
              <Pencil /> Renombrar
            </DropdownMenuItem>
            <DropdownMenuItem className="text-destructive" onSelect={() => setDeleting(true)}>
              <Trash2 /> Eliminar
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {subject.topics.length === 0 ? (
        <p className="mt-2 text-sm text-muted-foreground">
          Añade el primer tema de esta asignatura.
        </p>
      ) : (
        <ul className="mt-3 space-y-1.5">
          {subject.topics.map((t) => {
            const count = t.documents[0]?.count ?? 0;
            return (
              <li key={t.id}>
                <Link
                  to="/temarios/$topicId"
                  params={{ topicId: t.id }}
                  className="flex items-center justify-between gap-3 rounded-xl border bg-background px-3 py-2.5 text-sm transition-colors hover:border-primary/40 hover:bg-secondary/50"
                >
                  <span className="min-w-0 truncate font-medium">{t.name}</span>
                  <span className="flex shrink-0 items-center gap-2 text-xs text-muted-foreground">
                    {count === 0
                      ? "Sin documentos"
                      : `${count} ${count === 1 ? "documento" : "documentos"}`}
                    <ChevronRight className="size-4" />
                  </span>
                </Link>
              </li>
            );
          })}
        </ul>
      )}

      <form onSubmit={addTopic} className="mt-3 flex gap-2">
        <Input
          value={topicName}
          onChange={(e) => setTopicName(e.target.value)}
          placeholder="Nuevo tema, p. ej. «Tema 1: La célula»"
          aria-label={`Nuevo tema en ${subject.name}`}
          maxLength={120}
        />
        <Button type="submit" variant="soft" disabled={adding || !topicName.trim()}>
          <Plus /> Añadir
        </Button>
      </form>

      <NameDialog
        open={renaming}
        onOpenChange={setRenaming}
        title="Renombrar asignatura"
        label="Nombre"
        initial={subject.name}
        onSubmit={rename}
      />
      <ConfirmDialog
        open={deleting}
        onOpenChange={setDeleting}
        title={`¿Eliminar «${subject.name}»?`}
        description="Se eliminarán sus temas, documentos, clases, exámenes y materiales. Esta acción no se puede deshacer."
        onConfirm={remove}
      />
    </section>
  );
}
