import { useQuery, useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useRef, useState } from "react";
import {
  ArrowLeft,
  ClipboardCheck,
  Dumbbell,
  ExternalLink,
  Eye,
  FileText,
  Layers,
  MoreVertical,
  Pencil,
  Presentation,
  RefreshCw,
  Sparkles,
  Trash2,
} from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { documentContentQuery, topicQuery } from "@/lib/client/queries";
import {
  deleteDocument,
  openOriginal,
  removeTopicFiles,
  replaceDocument,
} from "@/lib/client/documents";
import { analyzeDocument } from "@/lib/functions/documents.functions";
import { errorMessage, toastError } from "@/lib/client/errors";
import { formatDate, pageHead } from "@/lib/client/format";
import {
  ACCEPTED_FILES,
  SOURCE_LABELS,
  extractFromFile,
  formatBytes,
  validateFile,
} from "@/lib/files/extract";
import { PageHeader } from "@/components/study/page-header";
import { EmptyState } from "@/components/study/empty-state";
import { DocumentUploader, ocrImages } from "@/components/study/document-uploader";
import { NameDialog } from "@/components/study/name-dialog";
import { ConfirmDialog } from "@/components/study/confirm-dialog";
import { AIWorking } from "@/components/study/ai-working";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export const Route = createFileRoute("/_authenticated/temarios/$topicId")({
  head: () => pageHead("Tema", "Los documentos de este tema y las formas de estudiarlo."),
  loader: ({ context, params }) => context.queryClient.ensureQueryData(topicQuery(params.topicId)),
  component: TopicPage,
});

type Doc = {
  id: string;
  title: string;
  source_type: string;
  storage_path: string | null;
  size_bytes: number | null;
  char_count: number;
  summary: string | null;
  key_concepts: unknown;
  updated_at: string;
};

function TopicPage() {
  const { topicId } = Route.useParams();
  const { data } = useSuspenseQuery(topicQuery(topicId));
  const qc = useQueryClient();
  const navigate = useNavigate();
  const [renaming, setRenaming] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const { topic, documents } = data;
  const hasDocs = documents.length > 0;

  const refresh = () =>
    Promise.all([
      qc.invalidateQueries({ queryKey: ["topic", topicId] }),
      qc.invalidateQueries({ queryKey: ["library"] }),
    ]);

  async function rename(name: string) {
    const { error } = await supabase.from("topics").update({ name }).eq("id", topicId);
    if (error) {
      toastError(new Error("No se ha podido renombrar el tema."));
      throw error;
    }
    await refresh();
  }

  async function remove() {
    await removeTopicFiles([topicId]);
    const { error } = await supabase.from("topics").delete().eq("id", topicId);
    if (error) {
      toastError(new Error("No se ha podido eliminar el tema."));
      throw error;
    }
    await qc.invalidateQueries({ queryKey: ["library"] });
    toast.success("Tema eliminado");
    navigate({ to: "/temarios", replace: true });
  }

  return (
    <div>
      <Link
        to="/temarios"
        className="mb-3 inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="size-4" /> Temarios
      </Link>
      <PageHeader
        eyebrow={topic.subjects?.name}
        title={topic.name}
        description={
          hasDocs
            ? `${documents.length} ${documents.length === 1 ? "documento" : "documentos"} · El profesor solo usará estos apuntes.`
            : "Sube tus apuntes para poder estudiar este tema."
        }
        actions={
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="icon" aria-label="Opciones del tema">
                <MoreVertical />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onSelect={() => setRenaming(true)}>
                <Pencil /> Renombrar tema
              </DropdownMenuItem>
              <DropdownMenuItem className="text-destructive" onSelect={() => setDeleting(true)}>
                <Trash2 /> Eliminar tema
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        }
      />

      {hasDocs && (
        <div className="mb-5 grid grid-cols-2 gap-2 sm:grid-cols-4">
          <Button asChild variant="brand">
            <Link to="/clase" search={{ tema: topicId }}>
              <Presentation /> Clase
            </Link>
          </Button>
          <Button asChild variant="soft">
            <Link to="/examen" search={{ tema: topicId }}>
              <ClipboardCheck /> Examen
            </Link>
          </Button>
          <Button asChild variant="soft">
            <Link to="/practica" search={{ tema: topicId }}>
              <Dumbbell /> Practicar
            </Link>
          </Button>
          <Button asChild variant="soft">
            <Link to="/resumenes" search={{ tema: topicId }}>
              <Layers /> Resúmenes
            </Link>
          </Button>
        </div>
      )}

      <div className="grid gap-5 lg:grid-cols-5">
        <div className="lg:col-span-3">
          <h2 className="mb-3 font-semibold">Documentos</h2>
          {hasDocs ? (
            <ul className="space-y-3">
              {documents.map((d) => (
                <DocumentRow key={d.id} doc={d} onChanged={refresh} />
              ))}
            </ul>
          ) : (
            <EmptyState
              icon={FileText}
              title="Sin documentos"
              description="Sube tu primer archivo o pega tus apuntes."
            />
          )}
        </div>
        <div className="lg:col-span-2">
          <h2 className="mb-3 font-semibold">Añadir apuntes</h2>
          <DocumentUploader topicId={topicId} />
        </div>
      </div>

      <NameDialog
        open={renaming}
        onOpenChange={setRenaming}
        title="Renombrar tema"
        label="Nombre"
        initial={topic.name}
        onSubmit={rename}
      />
      <ConfirmDialog
        open={deleting}
        onOpenChange={setDeleting}
        title={`¿Eliminar «${topic.name}»?`}
        description="Se eliminarán sus documentos, clases, exámenes, práctica y materiales. Esta acción no se puede deshacer."
        onConfirm={remove}
      />
    </div>
  );
}

function DocumentRow({ doc, onChanged }: { doc: Doc; onChanged: () => Promise<unknown> }) {
  const [viewing, setViewing] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [working, setWorking] = useState<string | null>(null);
  const replaceRef = useRef<HTMLInputElement>(null);
  const concepts = Array.isArray(doc.key_concepts) ? (doc.key_concepts as string[]) : [];

  async function analyze() {
    setWorking("Analizando el documento…");
    try {
      await analyzeDocument({ data: { documentId: doc.id } });
      await onChanged();
    } catch (e) {
      toastError(e);
    } finally {
      setWorking(null);
    }
  }

  async function replace(file: File | undefined) {
    if (!file) return;
    const invalid = validateFile(file);
    if (invalid) {
      toast.error(invalid);
      return;
    }
    setWorking("Leyendo el nuevo archivo…");
    try {
      const { text, kind } = await extractFromFile(file, ocrImages, (m) => setWorking(m));
      setWorking("Guardando…");
      await replaceDocument(
        { id: doc.id, storage_path: doc.storage_path },
        { title: file.name.replace(/\.[^.]+$/, ""), kind, text, file },
      );
      await onChanged();
      toast.success("Documento sustituido");
      setWorking("Analizando el documento…");
      await analyzeDocument({ data: { documentId: doc.id } }).catch(() => undefined);
      await onChanged();
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setWorking(null);
      if (replaceRef.current) replaceRef.current.value = "";
    }
  }

  return (
    <li className="rounded-2xl border bg-card p-4 shadow-soft">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h3 className="truncate font-semibold">{doc.title}</h3>
          <p className="mt-0.5 text-xs text-muted-foreground">
            {SOURCE_LABELS[doc.source_type as keyof typeof SOURCE_LABELS] ?? doc.source_type}
            {doc.size_bytes ? ` · ${formatBytes(doc.size_bytes)}` : ""} ·{" "}
            {doc.char_count.toLocaleString("es-ES")} caracteres · {formatDate(doc.updated_at)}
          </p>
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              aria-label={`Opciones de ${doc.title}`}
              disabled={!!working}
            >
              <MoreVertical />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onSelect={() => setViewing(true)}>
              <Eye /> Ver texto
            </DropdownMenuItem>
            {doc.storage_path && (
              <DropdownMenuItem onSelect={() => openOriginal(doc.storage_path!).catch(toastError)}>
                <ExternalLink /> Abrir original
              </DropdownMenuItem>
            )}
            <DropdownMenuItem onSelect={() => replaceRef.current?.click()}>
              <RefreshCw /> Sustituir archivo
            </DropdownMenuItem>
            <DropdownMenuItem onSelect={analyze}>
              <Sparkles /> {doc.summary ? "Volver a analizar" : "Analizar"}
            </DropdownMenuItem>
            <DropdownMenuItem className="text-destructive" onSelect={() => setDeleting(true)}>
              <Trash2 /> Eliminar
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
      {working ? (
        <AIWorking label={working} className="mt-3" />
      ) : doc.summary ? (
        <>
          <p className="mt-3 text-sm text-muted-foreground">{doc.summary}</p>
          {concepts.length > 0 && (
            <div className="mt-3 flex flex-wrap gap-1.5">
              {concepts.map((c) => (
                <span
                  key={c}
                  className="rounded-full bg-secondary px-2.5 py-0.5 text-xs font-medium text-secondary-foreground"
                >
                  {c}
                </span>
              ))}
            </div>
          )}
        </>
      ) : (
        <p className="mt-3 text-xs text-muted-foreground">
          Analizando los conceptos clave… vuelve en unos segundos.
        </p>
      )}
      <input
        ref={replaceRef}
        type="file"
        accept={ACCEPTED_FILES}
        className="hidden"
        aria-label={`Sustituir ${doc.title}`}
        onChange={(e) => replace(e.target.files?.[0])}
      />
      <ContentDialog
        open={viewing}
        onOpenChange={setViewing}
        documentId={doc.id}
        title={doc.title}
      />
      <ConfirmDialog
        open={deleting}
        onOpenChange={setDeleting}
        title={`¿Eliminar «${doc.title}»?`}
        description="El profesor dejará de usar este documento. Esta acción no se puede deshacer."
        onConfirm={async () => {
          try {
            await deleteDocument(doc);
            await onChanged();
            toast.success("Documento eliminado");
          } catch (e) {
            toastError(e);
            throw e;
          }
        }}
      />
    </li>
  );
}

function ContentDialog({
  open,
  onOpenChange,
  documentId,
  title,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  documentId: string;
  title: string;
}) {
  const { data, isLoading } = useQuery({ ...documentContentQuery(documentId), enabled: open });
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85vh] overflow-hidden sm:max-w-3xl">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
        </DialogHeader>
        <div className="max-h-[65vh] overflow-y-auto whitespace-pre-wrap rounded-lg bg-secondary/40 p-4 text-sm leading-relaxed">
          {isLoading ? <Skeleton className="h-40 w-full" /> : data?.content}
        </div>
      </DialogContent>
    </Dialog>
  );
}
