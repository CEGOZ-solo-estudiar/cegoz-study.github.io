import { useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { ChevronRight, ClipboardCheck } from "lucide-react";
import { examsQuery } from "@/lib/client/queries";
import { createExam } from "@/lib/functions/exam.functions";
import { topicSearchSchema } from "@/lib/client/search";
import { formatDateTime, formatGrade, pageHead } from "@/lib/client/format";
import { errorMessage } from "@/lib/client/errors";
import {
  DIFFICULTY_LABELS,
  EXAM_MAX_QUESTIONS,
  EXAM_MIN_QUESTIONS,
  QUESTION_TYPE_LABELS,
  gradeLabel,
  type Difficulty,
} from "@/lib/study/grading";
import { cn } from "@/lib/utils";
import { PageHeader } from "@/components/study/page-header";
import { TopicSelect } from "@/components/study/topic-select";
import { AIWorking } from "@/components/study/ai-working";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";

export const Route = createFileRoute("/_authenticated/examen/")({
  validateSearch: topicSearchSchema,
  head: () =>
    pageHead(
      "Modo examen",
      "Exámenes nuevos generados de tu temario, corregidos con nota sobre 10.",
    ),
  loader: ({ context }) => context.queryClient.ensureQueryData(examsQuery),
  component: ExamIndexPage,
});

type ExamType = "test" | "desarrollo" | "practico";
const TYPES: ExamType[] = ["test", "desarrollo", "practico"];

function ExamIndexPage() {
  const { tema } = Route.useSearch();
  const { data: exams } = useSuspenseQuery(examsQuery);
  const qc = useQueryClient();
  const navigate = useNavigate();
  const [topicId, setTopicId] = useState<string | undefined>(tema);
  const [difficulty, setDifficulty] = useState<Difficulty>("media");
  const [count, setCount] = useState(8);
  const [types, setTypes] = useState<ExamType[]>(["test", "desarrollo"]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function create() {
    if (!topicId || types.length === 0) return;
    setBusy(true);
    setError(null);
    try {
      const { examId } = await createExam({ data: { topicId, difficulty, count, types } });
      await qc.invalidateQueries({ queryKey: ["exams"] });
      navigate({ to: "/examen/$examId", params: { examId } });
    } catch (e) {
      setError(errorMessage(e));
      setBusy(false);
    }
  }

  const toggleType = (t: ExamType, on: boolean) =>
    setTypes((prev) => (on ? [...new Set([...prev, t])] : prev.filter((x) => x !== t)));

  return (
    <div>
      <PageHeader
        eyebrow="Modo examen"
        title="Ponte a prueba"
        description="Cada examen es nuevo y se basa solo en tus apuntes. Al terminar verás tu nota, las respuestas correctas y qué repasar."
      />
      <section className="space-y-5 rounded-2xl border bg-card p-5 shadow-soft">
        <div className="space-y-1.5">
          <Label htmlFor="exam-topic">Tema</Label>
          <TopicSelect id="exam-topic" value={topicId} onChange={setTopicId} />
        </div>
        <div className="space-y-2">
          <Label>Dificultad</Label>
          <div className="grid grid-cols-3 gap-2">
            {(Object.keys(DIFFICULTY_LABELS) as Difficulty[]).map((d) => (
              <button
                key={d}
                type="button"
                onClick={() => setDifficulty(d)}
                aria-pressed={difficulty === d}
                className={cn(
                  "rounded-xl border px-3 py-2.5 text-sm font-medium transition-colors",
                  difficulty === d
                    ? "border-primary bg-secondary text-secondary-foreground"
                    : "hover:bg-secondary/50",
                )}
              >
                {DIFFICULTY_LABELS[d]}
              </button>
            ))}
          </div>
        </div>
        <div className="space-y-2">
          <Label>
            Número de preguntas: <strong>{count}</strong>
          </Label>
          <Slider
            min={EXAM_MIN_QUESTIONS}
            max={EXAM_MAX_QUESTIONS}
            step={1}
            value={[count]}
            onValueChange={(v) => setCount(v[0] ?? count)}
            aria-label="Número de preguntas"
          />
        </div>
        <div className="space-y-2">
          <Label>Tipos de pregunta</Label>
          <div className="flex flex-wrap gap-4">
            {TYPES.map((t) => (
              <label key={t} className="flex items-center gap-2 text-sm">
                <Checkbox
                  checked={types.includes(t)}
                  onCheckedChange={(v) => toggleType(t, v === true)}
                />
                {QUESTION_TYPE_LABELS[t]}
              </label>
            ))}
          </div>
        </div>
        {error && (
          <p
            role="alert"
            className="rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive"
          >
            {error}
          </p>
        )}
        {busy ? (
          <AIWorking label="Preparando tu examen… puede tardar un minuto." />
        ) : (
          <Button
            variant="brand"
            size="lg"
            disabled={!topicId || types.length === 0}
            onClick={create}
          >
            <ClipboardCheck /> Crear examen
          </Button>
        )}
      </section>

      <h2 className="mb-3 mt-8 font-semibold">Historial de exámenes</h2>
      {exams.length === 0 ? (
        <p className="text-sm text-muted-foreground">Todavía no has hecho ningún examen.</p>
      ) : (
        <ul className="space-y-2">
          {exams.map((e) => (
            <li key={e.id}>
              <Link
                to="/examen/$examId"
                params={{ examId: e.id }}
                className="flex items-center justify-between gap-3 rounded-xl border bg-card px-4 py-3 shadow-soft transition-colors hover:border-primary/40"
              >
                <span className="min-w-0">
                  <span className="block truncate font-medium">{e.topics?.name ?? "Examen"}</span>
                  <span className="block text-xs text-muted-foreground">
                    {e.question_count} preguntas ·{" "}
                    {DIFFICULTY_LABELS[e.difficulty as Difficulty] ?? e.difficulty} ·{" "}
                    {formatDateTime(e.completed_at ?? e.created_at)}
                  </span>
                </span>
                <span className="flex shrink-0 items-center gap-2 text-sm">
                  {e.status === "completado" && e.score != null ? (
                    <strong className={Number(e.score) >= 5 ? "text-success" : "text-destructive"}>
                      {formatGrade(e.score)}/10 · {gradeLabel(Number(e.score))}
                    </strong>
                  ) : (
                    <span className="font-semibold text-primary">Continuar</span>
                  )}
                  <ChevronRight className="size-4 text-muted-foreground" />
                </span>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
