import { queryOptions, useQuery, useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  Dumbbell,
  RotateCcw,
  Send,
  XCircle,
} from "lucide-react";
import { examQuery } from "@/lib/client/queries";
import {
  createExam,
  finishExam,
  getExamResults,
  saveExamAnswer,
} from "@/lib/functions/exam.functions";
import { errorMessage, toastError } from "@/lib/client/errors";
import { formatGrade, pageHead } from "@/lib/client/format";
import {
  QUESTION_TYPE_LABELS,
  gradeLabel,
  type Difficulty,
  type QuestionType,
} from "@/lib/study/grading";
import { cn } from "@/lib/utils";
import { AIWorking } from "@/components/study/ai-working";
import { Markdown } from "@/components/study/markdown";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";

export const Route = createFileRoute("/_authenticated/examen/$examId")({
  head: () => pageHead("Examen", "Responde las preguntas y recibe tu nota sobre 10."),
  loader: ({ context, params }) => context.queryClient.ensureQueryData(examQuery(params.examId)),
  component: ExamPage,
});

const resultsQuery = (examId: string) =>
  queryOptions({
    queryKey: ["exam-results", examId],
    queryFn: () => getExamResults({ data: { examId } }),
  });

function ExamPage() {
  const { examId } = Route.useParams();
  const { data } = useSuspenseQuery(examQuery(examId));
  return data.exam.status === "completado" ? (
    <ExamResults examId={examId} />
  ) : (
    <ExamRunner examId={examId} />
  );
}

function ExamRunner({ examId }: { examId: string }) {
  const { data } = useSuspenseQuery(examQuery(examId));
  const qc = useQueryClient();
  const { exam, questions } = data;
  const [index, setIndex] = useState(() => {
    const first = questions.findIndex((q) => !q.user_answer);
    return first === -1 ? 0 : first;
  });
  const [answers, setAnswers] = useState<Record<string, string>>(() =>
    Object.fromEntries(questions.map((q) => [q.id, q.user_answer ?? ""])),
  );
  const [saved, setSaved] = useState<Record<string, string>>(answers);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const q = questions[index];
  const answeredCount = questions.filter((x) => (answers[x.id] ?? "").trim()).length;

  async function persist(id: string) {
    const value = answers[id] ?? "";
    if (value === (saved[id] ?? "")) return;
    await saveExamAnswer({ data: { questionId: id, answer: value } });
    setSaved((s) => ({ ...s, [id]: value }));
  }

  async function go(next: number) {
    if (!q) return;
    try {
      await persist(q.id);
      setIndex(next);
    } catch (e) {
      toastError(e);
    }
  }

  async function submit() {
    if (!q) return;
    setSubmitting(true);
    setError(null);
    try {
      await persist(q.id);
      await finishExam({ data: { examId } });
      await Promise.all([
        qc.invalidateQueries({ queryKey: ["exam", examId] }),
        qc.invalidateQueries({ queryKey: ["exams"] }),
        qc.invalidateQueries({ queryKey: ["progress"] }),
      ]);
    } catch (e) {
      setError(errorMessage(e));
      setSubmitting(false);
    }
  }

  if (!q) return <p className="text-sm text-muted-foreground">Este examen no tiene preguntas.</p>;
  const options = Array.isArray(q.options) ? (q.options as string[]) : [];
  const value = answers[q.id] ?? "";
  const isLast = index === questions.length - 1;

  return (
    <div className="mx-auto max-w-3xl">
      <Link
        to="/examen"
        search={{}}
        className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="size-4" /> Modo examen
      </Link>
      <div className="mt-2 flex items-center justify-between gap-3">
        <h1 className="truncate text-xl font-bold sm:text-2xl">{exam.topics?.name ?? "Examen"}</h1>
        <span className="shrink-0 text-sm text-muted-foreground">
          {answeredCount}/{questions.length} respondidas
        </span>
      </div>
      <Progress value={((index + 1) / questions.length) * 100} className="mt-3" />

      {submitting ? (
        <div className="mt-8">
          <AIWorking label="Corrigiendo tu examen… puede tardar un minuto." />
        </div>
      ) : (
        <section className="mt-6 rounded-2xl border bg-card p-5 shadow-soft sm:p-6">
          <p className="text-xs font-semibold uppercase tracking-wider text-accent-foreground">
            Pregunta {index + 1} de {questions.length} ·{" "}
            {QUESTION_TYPE_LABELS[q.qtype as QuestionType] ?? q.qtype}
          </p>
          <Markdown className="mt-2 text-base font-medium">{q.prompt}</Markdown>

          {q.qtype === "test" ? (
            <div className="mt-4 space-y-2" role="radiogroup" aria-label="Opciones">
              {options.map((opt, i) => (
                <button
                  key={i}
                  type="button"
                  role="radio"
                  aria-checked={value === String(i)}
                  onClick={() => setAnswers((a) => ({ ...a, [q.id]: String(i) }))}
                  className={cn(
                    "flex w-full items-start gap-3 rounded-xl border px-4 py-3 text-left text-sm transition-colors",
                    value === String(i) ? "border-primary bg-secondary" : "hover:bg-secondary/50",
                  )}
                >
                  <span className="grid size-6 shrink-0 place-items-center rounded-full border text-xs font-bold">
                    {String.fromCharCode(65 + i)}
                  </span>
                  <span>{opt}</span>
                </button>
              ))}
            </div>
          ) : (
            <Textarea
              className="mt-4"
              rows={8}
              value={value}
              maxLength={8000}
              onChange={(e) => setAnswers((a) => ({ ...a, [q.id]: e.target.value }))}
              placeholder="Escribe tu respuesta…"
              aria-label="Tu respuesta"
            />
          )}

          {error && (
            <p
              role="alert"
              className="mt-4 rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive"
            >
              {error}
            </p>
          )}

          <div className="mt-6 flex items-center justify-between gap-2">
            <Button variant="outline" disabled={index === 0} onClick={() => go(index - 1)}>
              <ArrowLeft /> Anterior
            </Button>
            {isLast ? (
              <Button variant="brand" onClick={submit}>
                <Send /> Entregar examen
              </Button>
            ) : (
              <Button variant="brand" onClick={() => go(index + 1)}>
                Siguiente <ArrowRight />
              </Button>
            )}
          </div>
        </section>
      )}

      <div className="mt-4 flex flex-wrap gap-1.5" aria-label="Ir a pregunta">
        {questions.map((x, i) => (
          <button
            key={x.id}
            type="button"
            onClick={() => go(i)}
            disabled={submitting}
            className={cn(
              "size-9 rounded-lg border text-xs font-semibold",
              i === index
                ? "border-primary bg-primary text-primary-foreground"
                : (answers[x.id] ?? "").trim()
                  ? "bg-secondary"
                  : "bg-card",
            )}
          >
            {i + 1}
          </button>
        ))}
      </div>
    </div>
  );
}

function ExamResults({ examId }: { examId: string }) {
  const { data, isLoading, error } = useQuery(resultsQuery(examId));
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [repeating, setRepeating] = useState(false);

  if (isLoading) return <Skeleton className="h-64 w-full" />;
  if (error || !data) return <p className="text-sm text-destructive">{errorMessage(error)}</p>;
  const { exam, questions } = data;
  const grade = Number(exam.score ?? 0);
  const failed = questions.filter((q) => !q.isCorrect).length;

  async function repeat() {
    setRepeating(true);
    try {
      const types = (Array.isArray(exam.question_types) ? exam.question_types : ["test"]) as (
        "test" | "desarrollo" | "practico"
      )[];
      const { examId: next } = await createExam({
        data: {
          topicId: exam.topic_id,
          difficulty: exam.difficulty as Difficulty,
          count: exam.question_count,
          types,
        },
      });
      await qc.invalidateQueries({ queryKey: ["exams"] });
      navigate({ to: "/examen/$examId", params: { examId: next } });
    } catch (e) {
      toastError(e);
    } finally {
      setRepeating(false);
    }
  }

  return (
    <div className="mx-auto max-w-3xl">
      <Link
        to="/examen"
        search={{}}
        className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="size-4" /> Modo examen
      </Link>
      <section className="mt-3 rounded-3xl border bg-card p-6 text-center shadow-soft">
        <p className="text-sm text-muted-foreground">{exam.topicName}</p>
        <p
          className={cn(
            "mt-2 font-display text-6xl font-extrabold",
            grade >= 5 ? "text-gradient-brand" : "text-destructive",
          )}
        >
          {formatGrade(grade)}
          <span className="text-2xl text-muted-foreground">/10</span>
        </p>
        <p className="mt-1 font-semibold">{gradeLabel(grade)}</p>
        <p className="mt-1 text-sm text-muted-foreground">
          {questions.length - failed} de {questions.length} preguntas superadas
        </p>
        {exam.feedback && <p className="mx-auto mt-4 max-w-xl text-sm">{exam.feedback}</p>}
        <div className="mt-5 flex flex-wrap justify-center gap-2">
          {repeating ? (
            <AIWorking label="Preparando un examen nuevo…" />
          ) : (
            <>
              <Button variant="brand" onClick={repeat}>
                <RotateCcw /> Repetir examen
              </Button>
              {failed > 0 && (
                <Button asChild variant="outline">
                  <Link to="/practica" search={{ tema: exam.topic_id }}>
                    <Dumbbell /> Practicar lo que he fallado
                  </Link>
                </Button>
              )}
            </>
          )}
        </div>
      </section>

      <ol className="mt-6 space-y-4">
        {questions.map((q, i) => {
          const options = q.options ?? [];
          const userText =
            q.qtype === "test"
              ? q.userAnswer
                ? options[Number(q.userAnswer)]
                : null
              : q.userAnswer;
          const correctText =
            q.qtype === "test" ? options[Number(q.correctAnswer)] : q.correctAnswer;
          return (
            <li key={q.id} className="rounded-2xl border bg-card p-5 shadow-soft">
              <div className="flex items-start gap-3">
                {q.isCorrect ? (
                  <CheckCircle2 className="mt-0.5 size-5 shrink-0 text-success" />
                ) : (
                  <XCircle className="mt-0.5 size-5 shrink-0 text-destructive" />
                )}
                <div className="min-w-0 flex-1">
                  <p className="text-xs text-muted-foreground">
                    Pregunta {i + 1} · {QUESTION_TYPE_LABELS[q.qtype as QuestionType] ?? q.qtype} ·{" "}
                    {formatGrade(Math.round(q.score * 100) / 100)}/1
                  </p>
                  <Markdown className="mt-1 font-medium">{q.prompt}</Markdown>
                  <div className="mt-3 space-y-2 text-sm">
                    <p>
                      <span className="font-semibold">Tu respuesta: </span>
                      <span className="whitespace-pre-wrap">{userText || "Sin responder"}</span>
                    </p>
                    {q.feedback && <p className="text-muted-foreground">{q.feedback}</p>}
                    <div className="rounded-lg bg-secondary/50 p-3">
                      <p className="font-semibold">Respuesta correcta</p>
                      <p className="mt-1 whitespace-pre-wrap">{correctText}</p>
                      {q.explanation && (
                        <p className="mt-2 text-muted-foreground">{q.explanation}</p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </li>
          );
        })}
      </ol>
    </div>
  );
}
