import { useSuspenseQuery } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ArrowRight,
  BookOpenText,
  ClipboardCheck,
  Dumbbell,
  FileText,
  GraduationCap,
  Layers,
  Presentation,
  Target,
  Upload,
} from "lucide-react";
import { libraryQuery, profileQuery, progressQuery } from "@/lib/client/queries";
import { formatDateTime, formatGrade, pageHead } from "@/lib/client/format";
import { masteryStatus } from "@/lib/study/grading";
import { PageHeader } from "@/components/study/page-header";
import { StatCard } from "@/components/study/stat-card";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/panel")({
  head: () =>
    pageHead(
      "Inicio",
      "Tu resumen de estudio: temarios, exámenes, práctica y conceptos para repasar.",
    ),
  loader: ({ context }) =>
    Promise.all([
      context.queryClient.ensureQueryData(progressQuery),
      context.queryClient.ensureQueryData(libraryQuery),
      context.queryClient.ensureQueryData(profileQuery),
    ]),
  component: PanelPage,
});

const ACTIONS = [
  { to: "/temarios", label: "Temarios", text: "Sube y organiza tus apuntes.", icon: BookOpenText },
  { to: "/clase", label: "Modo clase", text: "Tu profesor te explica el tema.", icon: Presentation },
  { to: "/examen", label: "Modo examen", text: "Preguntas nuevas con nota sobre 10.", icon: ClipboardCheck },
  { to: "/practica", label: "Práctica", text: "Corrección inmediata.", icon: Dumbbell },
  { to: "/resumenes", label: "Resúmenes y tarjetas", text: "Repasa lo esencial.", icon: Layers },
] as const;

function PanelPage() {
  const { data: progress } = useSuspenseQuery(progressQuery);
  const { data: library } = useSuspenseQuery(libraryQuery);
  const { data: profile } = useSuspenseQuery(profileQuery);

  const docCount = library.reduce(
    (acc, s) => acc + s.topics.reduce((a, t) => a + (t.documents[0]?.count ?? 0), 0),
    0,
  );
  const topicCount = library.reduce((acc, s) => acc + s.topics.length, 0);
  const avg =
    progress.exams.length > 0
      ? progress.exams.reduce((a, e) => a + Number(e.score ?? 0), 0) / progress.exams.length
      : null;
  const practiceOk = progress.practice.filter((q) => q.is_correct).length;
  const accuracy = progress.practice.length
    ? Math.round((practiceOk / progress.practice.length) * 100)
    : null;
  const weak = progress.mastery
    .filter((m) => masteryStatus(m.correct_count, m.incorrect_count) === "repasar")
    .slice(0, 6);
  const firstName = profile?.display_name?.split(" ")[0] || "estudiante";

  const mastered = progress.mastery.filter(
    (m) => masteryStatus(m.correct_count, m.incorrect_count) === "dominado",
  ).length;
  const masteredPct = progress.mastery.length
    ? Math.round((mastered / progress.mastery.length) * 100)
    : 0;

  return (
    <div>
      <PageHeader
        eyebrow="Inicio"
        title={`Hola, ${firstName}`}
        description="¿Qué quieres estudiar hoy? Elige un modo o sigue donde lo dejaste."
        actions={
          <Button asChild variant="brand">
            <Link to="/temarios">
              <Upload /> Subir apuntes
            </Link>
          </Button>
        }
      />

      {docCount === 0 && (
        <section className="mb-6 flex flex-col gap-3 rounded-2xl border border-primary/30 bg-gradient-soft p-5 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="font-semibold text-foreground">Empieza subiendo tus apuntes</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Crea una asignatura, añade un tema y sube PDF, fotos, Word o texto. Los modos de
              estudio usarán solo ese material.
            </p>
          </div>
          <Button asChild variant="brand" className="shrink-0">
            <Link to="/temarios">
              Ir a Temarios <ArrowRight />
            </Link>
          </Button>
        </section>
      )}

      <section className="grid grid-cols-2 gap-3 lg:grid-cols-5">
        {ACTIONS.map(({ to, label, text, icon: Icon }) => (
          <Link
            key={to}
            to={to}
            className="group rounded-2xl border bg-card p-4 shadow-soft transition-all hover:-translate-y-0.5 hover:border-primary/40"
          >
            <span className="grid size-10 place-items-center rounded-xl bg-gradient-brand text-primary-foreground">
              <Icon className="size-5" />
            </span>
            <h2 className="mt-3 font-semibold text-foreground">{label}</h2>
            <p className="text-sm text-muted-foreground">{text}</p>
          </Link>
        ))}
      </section>

      <section className="mt-6 rounded-2xl border bg-card p-5 shadow-soft">
        <div className="flex items-center justify-between gap-3">
          <h2 className="font-semibold">Tu progreso</h2>
          <Link to="/progreso" className="text-sm font-semibold text-primary hover:underline">
            Ver detalle
          </Link>
        </div>
        <div className="mt-4 grid grid-cols-2 gap-3 lg:grid-cols-4">
          <StatCard icon={FileText} label="Documentos" value={docCount} hint={`${topicCount} temas`} />
          <StatCard
            icon={GraduationCap}
            label="Nota media"
            value={avg == null ? "—" : formatGrade(Math.round(avg * 100) / 100)}
            hint={`${progress.exams.length} exámenes`}
          />
          <StatCard
            icon={Target}
            label="Aciertos en práctica"
            value={accuracy == null ? "—" : `${accuracy} %`}
            hint={`${progress.practice.length} respuestas`}
          />
          <StatCard
            icon={Layers}
            label="Conceptos dominados"
            value={mastered}
            hint={`de ${progress.mastery.length} trabajados`}
          />
        </div>
        <div className="mt-4">
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>Dominio del temario trabajado</span>
            <span>{masteredPct} %</span>
          </div>
          <div className="mt-1.5 h-2 overflow-hidden rounded-full bg-secondary">
            <div
              className="h-full rounded-full bg-gradient-brand transition-all"
              style={{ width: `${masteredPct}%` }}
            />
          </div>
        </div>
      </section>

      <div className="mt-6 grid gap-4 lg:grid-cols-5">
        <section className="rounded-2xl border bg-card p-5 shadow-soft lg:col-span-3">
          <h2 className="font-semibold">Actividad reciente</h2>
          {progress.activity.length === 0 ? (
            <p className="mt-3 text-sm text-muted-foreground">
              Aún no has estudiado. ¡Empieza con una clase!
            </p>
          ) : (
            <ul className="mt-3 divide-y">
              {progress.activity.slice(0, 8).map((a) => (
                <li key={a.id} className="flex items-center justify-between gap-3 py-2.5 text-sm">
                  <span className="min-w-0 truncate">{a.title}</span>
                  <span className="shrink-0 text-xs text-muted-foreground">
                    {a.score != null && (
                      <strong className="mr-2 text-foreground">{formatGrade(a.score)}/10</strong>
                    )}
                    {formatDateTime(a.created_at)}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </section>
        <section className="rounded-2xl border bg-card p-5 shadow-soft lg:col-span-2">
          <h2 className="font-semibold">Para repasar</h2>
          {weak.length === 0 ? (
            <p className="mt-3 text-sm text-muted-foreground">
              Cuando falles algún concepto aparecerá aquí para que lo refuerces.
            </p>
          ) : (
            <ul className="mt-3 space-y-2">
              {weak.map((m) => (
                <li key={m.id} className="rounded-lg bg-destructive/5 px-3 py-2 text-sm">
                  <span className="font-medium">{m.concept}</span>
                  <span className="block text-xs text-muted-foreground">{m.topics?.name}</span>
                </li>
              ))}
            </ul>
          )}
          <Button asChild variant="soft" className="mt-4 w-full">
            <Link to="/practica">Ir a Práctica</Link>
          </Button>
        </section>
      </div>
    </div>
  );
}
