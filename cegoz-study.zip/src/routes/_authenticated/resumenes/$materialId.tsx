import { useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowLeft, ArrowRight, RotateCw, Shuffle, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { materialQuery } from "@/lib/client/queries";
import { toastError } from "@/lib/client/errors";
import { formatDate, pageHead } from "@/lib/client/format";
import { MATERIAL_KINDS, type MaterialKind } from "@/lib/study/materials";
import { cn } from "@/lib/utils";
import { Markdown } from "@/components/study/markdown";
import { ConfirmDialog } from "@/components/study/confirm-dialog";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/resumenes/$materialId")({
  head: () => pageHead("Material de repaso", "Repasa tu resumen, esquema o tarjetas de memoria."),
  loader: ({ context, params }) =>
    context.queryClient.ensureQueryData(materialQuery(params.materialId)),
  component: MaterialPage,
});

type Item = { a: string; b: string; c: string };

function MaterialPage() {
  const { materialId } = Route.useParams();
  const { data: m } = useSuspenseQuery(materialQuery(materialId));
  const qc = useQueryClient();
  const navigate = useNavigate();
  const [deleting, setDeleting] = useState(false);
  const kind = m.kind as MaterialKind;
  const items = Array.isArray(m.data) ? (m.data as Item[]) : [];

  async function remove() {
    const { error } = await supabase.from("study_materials").delete().eq("id", materialId);
    if (error) {
      toastError(new Error("No se ha podido eliminar el material."));
      throw error;
    }
    await qc.invalidateQueries({ queryKey: ["materials"] });
    toast.success("Material eliminado");
    navigate({ to: "/resumenes", search: {}, replace: true });
  }

  return (
    <div className="mx-auto max-w-3xl">
      <Link
        to="/resumenes"
        search={{}}
        className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="size-4" /> Resúmenes y tarjetas
      </Link>
      <div className="mt-2 flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-xs font-semibold uppercase tracking-wider text-accent-foreground">
            {MATERIAL_KINDS[kind]?.label ?? m.kind}
          </p>
          <h1 className="mt-1 text-xl font-bold sm:text-2xl">{m.topics?.name}</h1>
          <p className="text-xs text-muted-foreground">{formatDate(m.created_at)}</p>
        </div>
        <Button
          variant="outline"
          size="icon"
          aria-label="Eliminar material"
          onClick={() => setDeleting(true)}
        >
          <Trash2 />
        </Button>
      </div>

      <div className="mt-5">
        {kind === "tarjetas" && items.length > 0 ? (
          <Flashcards items={items} />
        ) : items.length > 0 ? (
          <ul className="space-y-3">
            {items.map((it, i) => (
              <ItemCard key={i} item={it} reveal={kind === "preguntas_repaso"} />
            ))}
          </ul>
        ) : (
          <article className="rounded-2xl border bg-card p-5 shadow-soft sm:p-7">
            <Markdown>{m.content}</Markdown>
          </article>
        )}
      </div>

      <ConfirmDialog
        open={deleting}
        onOpenChange={setDeleting}
        title="¿Eliminar este material?"
        description="Podrás volver a generarlo cuando quieras."
        onConfirm={remove}
      />
    </div>
  );
}

function ItemCard({ item, reveal }: { item: Item; reveal: boolean }) {
  const [open, setOpen] = useState(!reveal);
  return (
    <li className="rounded-2xl border bg-card p-4 shadow-soft">
      <p className="font-semibold">{item.a}</p>
      {open ? (
        <p className="mt-1.5 text-sm text-muted-foreground">{item.b}</p>
      ) : (
        <Button variant="link" className="mt-1 h-auto p-0" onClick={() => setOpen(true)}>
          Ver respuesta
        </Button>
      )}
      {item.c && (
        <span className="mt-2 inline-block rounded-full bg-secondary px-2.5 py-0.5 text-xs">
          {item.c}
        </span>
      )}
    </li>
  );
}

function Flashcards({ items }: { items: Item[] }) {
  const [order, setOrder] = useState(() => items.map((_, i) => i));
  const [pos, setPos] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const card = items[order[pos] ?? 0];
  if (!card) return null;

  const go = (d: number) => {
    setFlipped(false);
    setPos((p) => (p + d + order.length) % order.length);
  };

  return (
    <div>
      <button
        type="button"
        onClick={() => setFlipped((f) => !f)}
        aria-label={flipped ? "Ver anverso" : "Ver reverso"}
        className={cn(
          "grid min-h-64 w-full place-items-center rounded-3xl border p-8 text-center shadow-soft transition-colors",
          flipped ? "bg-gradient-soft" : "bg-card",
        )}
      >
        <span>
          <span className="mb-3 block text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            {flipped ? "Reverso" : "Anverso"}
          </span>
          <span className={cn("block", flipped ? "text-base" : "font-display text-xl font-bold")}>
            {flipped ? card.b : card.a}
          </span>
        </span>
      </button>
      <div className="mt-4 flex items-center justify-between gap-2">
        <Button variant="outline" onClick={() => go(-1)} aria-label="Anterior">
          <ArrowLeft />
        </Button>
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">
            {pos + 1} / {order.length}
          </span>
          <Button
            variant="ghost"
            size="icon"
            aria-label="Girar tarjeta"
            onClick={() => setFlipped((f) => !f)}
          >
            <RotateCw />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            aria-label="Barajar"
            onClick={() => {
              setOrder((o) => [...o].sort(() => Math.random() - 0.5));
              setPos(0);
              setFlipped(false);
            }}
          >
            <Shuffle />
          </Button>
        </div>
        <Button variant="brand" onClick={() => go(1)} aria-label="Siguiente">
          <ArrowRight />
        </Button>
      </div>
    </div>
  );
}
