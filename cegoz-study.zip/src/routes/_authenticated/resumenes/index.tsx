import { useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { ChevronRight, Sparkles } from "lucide-react";
import { materialsQuery } from "@/lib/client/queries";
import { generateMaterial } from "@/lib/functions/materials.functions";
import { topicSearchSchema } from "@/lib/client/search";
import { errorMessage } from "@/lib/client/errors";
import { formatDate, pageHead } from "@/lib/client/format";
import { MATERIAL_KINDS, type MaterialKind } from "@/lib/study/materials";
import { PageHeader } from "@/components/study/page-header";
import { TopicSelect } from "@/components/study/topic-select";
import { AIWorking } from "@/components/study/ai-working";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/_authenticated/resumenes/")({
  validateSearch: topicSearchSchema,
  head: () =>
    pageHead(
      "Resúmenes y tarjetas",
      "Resúmenes, esquemas, definiciones y tarjetas de memoria de tu temario.",
    ),
  loader: ({ context }) => context.queryClient.ensureQueryData(materialsQuery),
  component: MaterialsPage,
});

function MaterialsPage() {
  const { tema } = Route.useSearch();
  const { data: materials } = useSuspenseQuery(materialsQuery);
  const qc = useQueryClient();
  const navigate = useNavigate();
  const [topicId, setTopicId] = useState<string | undefined>(tema);
  const [working, setWorking] = useState<MaterialKind | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function generate(kind: MaterialKind) {
    if (!topicId) return;
    setWorking(kind);
    setError(null);
    try {
      const { materialId } = await generateMaterial({ data: { topicId, kind } });
      await qc.invalidateQueries({ queryKey: ["materials"] });
      navigate({ to: "/resumenes/$materialId", params: { materialId } });
    } catch (e) {
      setError(errorMessage(e));
      setWorking(null);
    }
  }

  return (
    <div>
      <PageHeader
        eyebrow="Resúmenes y tarjetas"
        title="Material de repaso"
        description="Genera material a partir de tus apuntes. Todo queda guardado para que lo repases cuando quieras."
      />
      <section className="rounded-2xl border bg-card p-5 shadow-soft">
        <div className="space-y-1.5">
          <Label htmlFor="material-topic">Tema</Label>
          <TopicSelect id="material-topic" value={topicId} onChange={setTopicId} />
        </div>
        {working ? (
          <AIWorking
            className="mt-4"
            label={`Creando «${MATERIAL_KINDS[working].label}»… puede tardar un minuto.`}
          />
        ) : (
          <div className="mt-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {(Object.keys(MATERIAL_KINDS) as MaterialKind[]).map((k) => (
              <button
                key={k}
                type="button"
                disabled={!topicId}
                onClick={() => generate(k)}
                className="group rounded-xl border bg-background p-4 text-left transition-colors hover:border-primary/40 hover:bg-secondary/40 disabled:cursor-not-allowed disabled:opacity-50"
              >
                <span className="flex items-center justify-between font-semibold">
                  {MATERIAL_KINDS[k].label}
                  <Sparkles className="size-4 text-accent-foreground" />
                </span>
                <span className="mt-1 block text-xs text-muted-foreground">
                  {MATERIAL_KINDS[k].description}
                </span>
              </button>
            ))}
          </div>
        )}
        {error && (
          <p
            role="alert"
            className="mt-4 rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive"
          >
            {error}
          </p>
        )}
      </section>

      <h2 className="mb-3 mt-8 font-semibold">Guardados</h2>
      {materials.length === 0 ? (
        <p className="text-sm text-muted-foreground">Aún no has generado material.</p>
      ) : (
        <ul className="grid gap-2 sm:grid-cols-2">
          {materials.map((m) => (
            <li key={m.id}>
              <Link
                to="/resumenes/$materialId"
                params={{ materialId: m.id }}
                className="flex items-center justify-between gap-3 rounded-xl border bg-card px-4 py-3 shadow-soft transition-colors hover:border-primary/40"
              >
                <span className="min-w-0">
                  <span className="block truncate font-medium">
                    {MATERIAL_KINDS[m.kind as MaterialKind]?.label ?? m.kind}
                  </span>
                  <span className="block truncate text-xs text-muted-foreground">
                    {m.topics?.name} · {formatDate(m.created_at)}
                  </span>
                </span>
                <ChevronRight className="size-4 shrink-0 text-muted-foreground" />
              </Link>
            </li>
          ))}
        </ul>
      )}
      <div className="mt-4">
        <Button asChild variant="ghost" size="sm">
          <Link to="/temarios">Gestionar temarios</Link>
        </Button>
      </div>
    </div>
  );
}
