import { useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState, type FormEvent, type KeyboardEvent } from "react";
import { ArrowLeft, ArrowRight, CircleHelp, Lightbulb, Send } from "lucide-react";
import { classSessionQuery } from "@/lib/client/queries";
import { classTurn, type ClassIntent } from "@/lib/functions/class.functions";
import { errorMessage } from "@/lib/client/errors";
import { pageHead } from "@/lib/client/format";
import { cn } from "@/lib/utils";
import { AIWorking } from "@/components/study/ai-working";
import { Markdown } from "@/components/study/markdown";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

export const Route = createFileRoute("/_authenticated/clase/$sessionId")({
  head: () => pageHead("Clase", "Clase individual con tu profesor virtual."),
  loader: ({ context, params }) =>
    context.queryClient.ensureQueryData(classSessionQuery(params.sessionId)),
  component: ClassSessionPage,
});

const FIXED: Partial<Record<ClassIntent, string>> = {
  next: "Lo tengo claro, continúa con el siguiente apartado.",
  simpler: "No lo he entendido bien. ¿Me lo explicas de forma más sencilla?",
};

function ClassSessionPage() {
  const { sessionId } = Route.useParams();
  const { data } = useSuspenseQuery(classSessionQuery(sessionId));
  const qc = useQueryClient();
  const [text, setText] = useState("");
  const [pending, setPending] = useState<null | { text: string; doubt: boolean }>(null);
  const [error, setError] = useState<{
    message: string;
    intent: ClassIntent;
    text?: string | undefined;
  } | null>(null);
  const [finished, setFinished] = useState(false);
  const started = useRef(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const { session, messages } = data;
  const topic = session.topics as { name: string; subjects: { name: string } | null } | null;

  async function turn(intent: ClassIntent, message?: string) {
    setError(null);
    setPending({ text: message ?? FIXED[intent] ?? "", doubt: intent === "doubt" });
    try {
      const r = await classTurn({ data: { sessionId, intent, message } });
      setFinished(r.finished);
      if (intent === "answer" || intent === "doubt") setText("");
    } catch (e) {
      setError({ message: errorMessage(e), intent, text: message });
    } finally {
      await qc.invalidateQueries({ queryKey: ["class-session", sessionId] });
      await qc.invalidateQueries({ queryKey: ["class-sessions"] });
      setPending(null);
    }
  }

  useEffect(() => {
    if (!started.current && messages.length === 0) {
      started.current = true;
      void turn("start");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages.length, pending]);

  function send(e?: FormEvent, intent: ClassIntent = "answer") {
    e?.preventDefault();
    const value = text.trim();
    if (!value || pending) return;
    void turn(intent, value);
  }

  function onKey(e: KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      send();
    }
  }

  const lastSaved = messages.at(-1);
  const showPendingUser =
    pending && pending.text && !(lastSaved?.role === "user" && lastSaved.content === pending.text);

  return (
    <div className="flex min-h-[calc(100vh-10rem)] flex-col">
      <div className="mb-4 flex items-center justify-between gap-3">
        <div className="min-w-0">
          <Link
            to="/clase"
            search={{}}
            className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="size-4" /> Modo clase
          </Link>
          <h1 className="mt-1 truncate text-xl font-bold sm:text-2xl">
            {topic?.name ?? session.title}
          </h1>
          {session.progress_note && (
            <p className="truncate text-xs text-muted-foreground">
              Apartado: {session.progress_note}
            </p>
          )}
        </div>
      </div>

      <div className="flex-1 space-y-4 rounded-2xl border bg-card p-4 shadow-soft sm:p-6">
        {messages.map((m) => (
          <Bubble key={m.id} role={m.role} doubt={m.kind === "doubt"} content={m.content} />
        ))}
        {showPendingUser && <Bubble role="user" doubt={pending.doubt} content={pending.text} />}
        {pending && <AIWorking label="El profesor está pensando…" />}
        {error && (
          <div
            role="alert"
            className="rounded-xl border border-destructive/30 bg-destructive/5 p-4 text-sm"
          >
            <p className="text-destructive">{error.message}</p>
            {error.intent === "start" && messages.length === 0 && (
              <Button className="mt-3" size="sm" variant="outline" onClick={() => turn("start")}>
                Volver a intentarlo
              </Button>
            )}
          </div>
        )}
        {finished && !pending && (
          <div className="rounded-xl bg-gradient-soft p-4 text-sm">
            <p className="font-semibold">¡Clase terminada! ¿Lo pones a prueba?</p>
            <div className="mt-3 flex flex-wrap gap-2">
              <Button asChild size="sm" variant="brand">
                <Link to="/practica" search={{ tema: session.topic_id }}>
                  Practicar
                </Link>
              </Button>
              <Button asChild size="sm" variant="outline">
                <Link to="/examen" search={{ tema: session.topic_id }}>
                  Hacer un examen
                </Link>
              </Button>
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      <form
        onSubmit={send}
        className="sticky bottom-20 mt-4 rounded-2xl border bg-background p-3 shadow-soft lg:bottom-4"
      >
        <Textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={onKey}
          placeholder="Escribe tu respuesta… (Intro para enviar)"
          aria-label="Tu respuesta"
          rows={2}
          maxLength={6000}
          disabled={!!pending || messages.length === 0}
          className="resize-none border-0 shadow-none focus-visible:ring-0"
        />
        <div className="mt-2 flex flex-wrap items-center justify-between gap-2">
          <div className="flex flex-wrap gap-2">
            <Button
              type="button"
              size="sm"
              variant="soft"
              disabled={!!pending || messages.length === 0}
              onClick={() => turn("next")}
            >
              <ArrowRight /> Siguiente
            </Button>
            <Button
              type="button"
              size="sm"
              variant="soft"
              disabled={!!pending || messages.length === 0}
              onClick={() => turn("simpler")}
            >
              <Lightbulb /> Más sencillo
            </Button>
            <Button
              type="button"
              size="sm"
              variant="outline"
              disabled={!!pending || !text.trim()}
              onClick={() => send(undefined, "doubt")}
            >
              <CircleHelp /> Es una duda
            </Button>
          </div>
          <Button type="submit" size="sm" variant="brand" disabled={!!pending || !text.trim()}>
            <Send /> Responder
          </Button>
        </div>
      </form>
    </div>
  );
}

function Bubble({ role, doubt, content }: { role: string; doubt: boolean; content: string }) {
  const mine = role === "user";
  return (
    <div className={cn("flex", mine ? "justify-end" : "justify-start")}>
      <div
        className={cn(
          "max-w-[92%] rounded-2xl px-4 py-3 text-sm sm:max-w-[80%]",
          mine ? "bg-gradient-brand text-primary-foreground" : "bg-secondary/60 text-foreground",
        )}
      >
        {mine ? (
          <p className="whitespace-pre-wrap">
            {doubt && <strong className="mr-1">Duda:</strong>}
            {content}
          </p>
        ) : (
          <Markdown>{content}</Markdown>
        )}
      </div>
    </div>
  );
}
