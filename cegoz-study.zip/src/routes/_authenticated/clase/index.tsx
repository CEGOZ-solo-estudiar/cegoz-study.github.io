import { useQuery, useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { ChevronRight, Presentation } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { classSessionsQuery, libraryQuery } from "@/lib/client/queries";
import { topicSearchSchema } from "@/lib/client/search";
import { formatDateTime, pageHead } from "@/lib/client/format";
import { toastError } from "@/lib/client/errors";
import { PageHeader } from "@/components/study/page-header";
import { TopicSelect } from "@/components/study/topic-select";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/_authenticated/clase/")({
  validateSearch: topicSearchSchema,
  head: () =>
    pageHead("Modo clase", "Tu profesor virtual te explica el tema paso a paso y te pregunta."),
  loader: ({ context }) => context.queryClient.ensureQueryData(classSessionsQuery),
  component: ClassIndexPage,
});

function ClassIndexPage() {
  const { tema } = Route.useSearch();
  const { data: sessions } = useSuspenseQuery(classSessionsQuery);
  const { data: library } = useQuery(libraryQuery);
  const qc = useQueryClient();
  const navigate = useNavigate();
  const [topicId, setTopicId] = useState<string | undefined>(tema);
  const [busy, setBusy] = useState(false);

  async function start() {
    if (!topicId) return;
    setBusy(true);
    const topicName =
      library?.flatMap((s) => s.topics).find((t) => t.id === topicId)?.name ?? "Tema";
    const { data, error } = await supabase
      .from("class_sessions")
      .insert({ topic_id: topicId, title: `Clase: ${topicName}`.slice(0, 200) })
      .select("id")
      .single();
    setBusy(false);
    if (error || !data) return toastError(new Error("No se ha podido crear la clase."));
    await qc.invalidateQueries({ queryKey: ["class-sessions"] });
    navigate({ to: "/clase/$sessionId", params: { sessionId: data.id } });
  }

  return (
    <div>
      <PageHeader
        eyebrow="Modo clase"
        title="Clase con tu profesor"
        description="Te explica el temario por partes, te hace preguntas y corrige tus respuestas. Puedes interrumpirle con dudas cuando quieras."
      />
      <section className="rounded-2xl border bg-card p-5 shadow-soft">
        <div className="grid gap-3 sm:grid-cols-[1fr_auto] sm:items-end">
          <div className="space-y-1.5">
            <Label htmlFor="class-topic">Tema</Label>
            <TopicSelect id="class-topic" value={topicId} onChange={setTopicId} />
          </div>
          <Button variant="brand" size="lg" disabled={!topicId || busy} onClick={start}>
            <Presentation /> {busy ? "Preparando…" : "Empezar clase"}
          </Button>
        </div>
      </section>

      <h2 className="mb-3 mt-8 font-semibold">Tus clases</h2>
      {sessions.length === 0 ? (
        <p className="text-sm text-muted-foreground">Aún no has dado ninguna clase.</p>
      ) : (
        <ul className="space-y-2">
          {sessions.map((s) => (
            <li key={s.id}>
              <Link
                to="/clase/$sessionId"
                params={{ sessionId: s.id }}
                className="flex items-center justify-between gap-3 rounded-xl border bg-card px-4 py-3 shadow-soft transition-colors hover:border-primary/40"
              >
                <span className="min-w-0">
                  <span className="block truncate font-medium">{s.topics?.name ?? s.title}</span>
                  <span className="block truncate text-xs text-muted-foreground">
                    {s.progress_note ? `Por: ${s.progress_note} · ` : ""}
                    {formatDateTime(s.updated_at)}
                  </span>
                </span>
                <span className="flex shrink-0 items-center gap-1 text-sm font-semibold text-primary">
                  Continuar <ChevronRight className="size-4" />
                </span>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
