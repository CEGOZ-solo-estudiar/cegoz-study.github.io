import { useSuspenseQuery } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import {
  BarChart3,
  ClipboardCheck,
  Dumbbell,
  GraduationCap,
  Layers,
  Presentation,
  Target,
} from "lucide-react";
import { progressQuery } from "@/lib/client/queries";
import { formatDate, formatDateTime, formatGrade, pageHead } from "@/lib/client/format";
import { masteryStatus, type MasteryStatus } from "@/lib/study/grading";
import { cn } from "@/lib/utils";
import { PageHeader } from "@/components/study/page-header";
import { StatCard } from "@/components/study/stat-card";
import { EmptyState } from "@/components/study/empty-state";

export const Route = createFileRoute("/_authenticated/progreso")({
  head: () =>
    pageHead(
      "Progreso",
      "Tu evolución: notas, aciertos, conceptos dominados e historial de estudio.",
    ),
  loader: ({ context }) => context.queryClient.ensureQueryData(progressQuery),
  component: ProgressPage,
});

const KIND_ICONS: Record<string, typeof Presentation> = {
  clase: Presentation,
  examen: ClipboardCheck,
  practica: Dumbbell,
  resumen: Layers,
  tarjetas: Layers,
};

const STATUS: Record<MasteryStatus, { label: string; className: string }> = {
  dominado: { label: "Dominados", className: "bg-success/10" },
  en_progreso: { label: "En progreso", className: "bg-secondary/60" },
  repasar: { label: "Para repasar", className: "bg-destructive/5" },
};

function ProgressPage() {
  const { data } = useSuspenseQuery(progressQuery);
  const { exams, practice, mastery, activity } = data;
  const avg = exams.length
    ? exams.reduce((a, e) => a + Number(e.score ?? 0), 0) / exams.length
    : null;
  const ok = practice.filter((q) => q.is_correct).length;
  const grouped: Record<MasteryStatus, typeof mastery> = {
    dominado: [],
    en_progreso: [],
    repasar: [],
  };
  for (const m of mastery) grouped[masteryStatus(m.correct_count, m.incorrect_count)].push(m);
  const recentExams = exams.slice(-12);

  if (activity.length === 0 && exams.length === 0 && practice.length === 0) {
    return (
      <div>
        <PageHeader eyebrow="Progreso" title="Tu progreso" />
        <EmptyState
          icon={BarChart3}
          title="Todavía no hay datos"
          description="Da una clase, practica o haz un examen y aquí verás tu evolución."
        />
      </div>
    );
  }

  return (
    <div>
      <PageHeader eyebrow="Progreso" title="Tu progreso" description="Así vas con tus temarios." />
      <section className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard
          icon={GraduationCap}
          label="Nota media"
          value={avg == null ? "—" : formatGrade(Math.round(avg * 100) / 100)}
          hint={`${exams.length} exámenes`}
        />
        <StatCard
          icon={Target}
          label="Aciertos en práctica"
          value={practice.length ? `${Math.round((ok / practice.length) * 100)} %` : "—"}
          hint={`${practice.length} respuestas`}
        />
        <StatCard
          icon={Layers}
          label="Conceptos dominados"
          value={grouped.dominado.length}
          hint={`de ${mastery.length}`}
        />
        <StatCard icon={BarChart3} label="Sesiones de estudio" value={activity.length} />
      </section>

      {recentExams.length > 0 && (
        <section className="mt-6 rounded-2xl border bg-card p-5 shadow-soft">
          <h2 className="font-semibold">Evolución de tus notas</h2>
          <div
            className="mt-4 flex h-44 items-end gap-2"
            role="img"
            aria-label="Notas de tus últimos exámenes"
          >
            {recentExams.map((e) => {
              const s = Number(e.score ?? 0);
              return (
                <div
                  key={e.id}
                  className="flex flex-1 flex-col items-center gap-1"
                  title={`${e.topics?.name ?? ""}: ${formatGrade(s)}`}
                >
                  <span className="text-[11px] font-semibold">
                    {formatGrade(Math.round(s * 10) / 10)}
                  </span>
                  <div
                    className={cn(
                      "w-full max-w-10 rounded-t-lg",
                      s >= 5 ? "bg-gradient-brand" : "bg-destructive/70",
                    )}
                    style={{ height: `${Math.max(4, s * 10)}%` }}
                  />
                  <span className="text-[10px] text-muted-foreground">
                    {formatDate(e.completed_at ?? e.created_at).replace(/ \d{4}$/, "")}
                  </span>
                </div>
              );
            })}
          </div>
        </section>
      )}

      <section className="mt-6 grid gap-4 lg:grid-cols-3">
        {(["repasar", "en_progreso", "dominado"] as MasteryStatus[]).map((s) => (
          <div key={s} className="rounded-2xl border bg-card p-5 shadow-soft">
            <h2 className="font-semibold">
              {STATUS[s].label} <span className="text-muted-foreground">({grouped[s].length})</span>
            </h2>
            {grouped[s].length === 0 ? (
              <p className="mt-2 text-sm text-muted-foreground">Ninguno por ahora.</p>
            ) : (
              <ul className="mt-3 max-h-72 space-y-1.5 overflow-y-auto">
                {grouped[s].map((m) => (
                  <li
                    key={m.id}
                    className={cn("rounded-lg px-3 py-2 text-sm", STATUS[s].className)}
                  >
                    <span className="font-medium">{m.concept}</span>
                    <span className="block text-xs text-muted-foreground">
                      {m.topics?.name} · {m.correct_count} ✓ · {m.incorrect_count} ✗
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        ))}
      </section>

      <section className="mt-6 rounded-2xl border bg-card p-5 shadow-soft">
        <h2 className="font-semibold">Historial</h2>
        <ul className="mt-3 divide-y">
          {activity.map((a) => {
            const Icon = KIND_ICONS[a.kind] ?? BarChart3;
            return (
              <li key={a.id} className="flex items-center gap-3 py-2.5 text-sm">
                <Icon className="size-4 shrink-0 text-accent-foreground" />
                <span className="min-w-0 flex-1 truncate">{a.title}</span>
                {a.score != null && <strong className="shrink-0">{formatGrade(a.score)}/10</strong>}
                <span className="shrink-0 text-xs text-muted-foreground">
                  {formatDateTime(a.created_at)}
                </span>
              </li>
            );
          })}
        </ul>
      </section>
    </div>
  );
}
