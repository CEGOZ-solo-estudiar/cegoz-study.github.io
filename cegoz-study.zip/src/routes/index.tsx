import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  ArrowRight,
  BookOpenText,
  ClipboardCheck,
  Dumbbell,
  FileUp,
  Layers,
  Presentation,
  ShieldCheck,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Logo } from "@/components/study/logo";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "CEGOZ Study — Tu profesor particular con IA" },
      {
        name: "description",
        content:
          "Sube tus apuntes en PDF, fotos o Word y estudia con un profesor virtual que explica, pregunta, examina y corrige usando solo tu temario.",
      },
      { property: "og:title", content: "CEGOZ Study — Tu profesor particular con IA" },
      {
        property: "og:description",
        content:
          "Un profesor virtual que aprende de tus apuntes y te enseña, te examina y te corrige.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const FEATURES = [
  {
    icon: FileUp,
    title: "Tus apuntes, organizados",
    text: "PDF, fotos, Word o texto pegado, por asignaturas y temas.",
  },
  {
    icon: Presentation,
    title: "Modo clase",
    text: "Te explica paso a paso, te pregunta y corrige tus respuestas.",
  },
  {
    icon: ClipboardCheck,
    title: "Modo examen",
    text: "Exámenes nuevos cada vez, corregidos con nota sobre 10.",
  },
  {
    icon: Dumbbell,
    title: "Práctica adaptativa",
    text: "Corrección inmediata y repaso de lo que fallas.",
  },
  {
    icon: Layers,
    title: "Resúmenes y tarjetas",
    text: "Esquemas, definiciones y flashcards de tu temario.",
  },
  {
    icon: ShieldCheck,
    title: "Solo tu temario",
    text: "La IA se basa en tus documentos y no inventa contenido.",
  },
];

function Index() {
  const [signedIn, setSignedIn] = useState(false);
  const router = useRouter();
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSignedIn(!!data.session);
      // After Google / Lovable sign-in the provider returns here: continue to the saved page.
      const next = sessionStorage.getItem("cegoz:after-login");
      if (data.session && next) {
        sessionStorage.removeItem("cegoz:after-login");
        router.history.replace(next);
      }
    });
  }, [router]);

  return (
    <div className="min-h-screen bg-background bg-gradient-hero">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-5 py-5">
        <Logo />
        {signedIn ? (
          <Button asChild variant="brand">
            <Link to="/panel">Ir a mi panel</Link>
          </Button>
        ) : (
          <Button asChild variant="outline">
            <Link to="/auth">Iniciar sesión</Link>
          </Button>
        )}
      </header>

      <main className="mx-auto max-w-6xl px-5 pb-20 pt-10 sm:pt-16">
        <section className="mx-auto max-w-3xl text-center animate-fade-up">
          <span className="inline-flex items-center gap-2 rounded-full border bg-card px-3 py-1 text-xs font-semibold text-accent-foreground shadow-soft">
            <BookOpenText className="size-3.5" /> Profesor particular con inteligencia artificial
          </span>
          <h1 className="mt-6 text-4xl font-extrabold leading-tight text-foreground sm:text-6xl">
            Sube tus apuntes.
            <br />
            <span className="text-gradient-brand">Aprende con tu profesor.</span>
          </h1>
          <p className="mx-auto mt-5 max-w-xl text-base text-muted-foreground sm:text-lg">
            CEGOZ Study estudia tu temario y te enseña como un profesor particular: explica,
            pregunta, examina y corrige, siempre basándose en tus documentos.
          </p>
          <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
            <Button asChild size="lg" variant="brand">
              {signedIn ? (
                <Link to="/panel">
                  Continuar estudiando <ArrowRight />
                </Link>
              ) : (
                <Link to="/auth" search={{ mode: "signup" }}>
                  Crear cuenta gratis <ArrowRight />
                </Link>
              )}
            </Button>
            {!signedIn && (
              <Button asChild size="lg" variant="outline">
                <Link to="/auth">Ya tengo cuenta</Link>
              </Button>
            )}
          </div>
        </section>

        <section className="mt-20 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map(({ icon: Icon, title, text }, i) => (
            <div
              key={title}
              className="rounded-2xl border bg-card p-5 shadow-soft animate-fade-up"
              style={{ animationDelay: `${i * 60}ms` }}
            >
              <span className="grid size-10 place-items-center rounded-xl bg-gradient-soft text-accent-foreground">
                <Icon className="size-5" />
              </span>
              <h2 className="mt-4 text-base font-semibold text-foreground">{title}</h2>
              <p className="mt-1 text-sm text-muted-foreground">{text}</p>
            </div>
          ))}
        </section>
      </main>
      <footer className="border-t py-6 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} CEGOZ Study
      </footer>
    </div>
  );
}
