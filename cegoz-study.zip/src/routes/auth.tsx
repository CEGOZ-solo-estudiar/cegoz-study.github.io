import { createFileRoute, Link, useNavigate, useRouter } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { z } from "zod";
import { LovableMark } from "@lovable.dev/cloud-auth-js/react";
import { MailCheck } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Logo } from "@/components/study/logo";
import { errorMessage } from "@/lib/client/errors";

const searchSchema = z.object({
  mode: z.enum(["signin", "signup", "forgot"]).optional(),
  redirect: z.string().optional(),
});

export const Route = createFileRoute("/auth")({
  validateSearch: searchSchema,
  head: () => ({
    meta: [
      { title: "Acceder — CEGOZ Study" },
      {
        name: "description",
        content:
          "Inicia sesión o crea tu cuenta de CEGOZ Study para estudiar con tu profesor virtual.",
      },
      { property: "og:title", content: "Acceder — CEGOZ Study" },
      { property: "og:description", content: "Inicia sesión o crea tu cuenta de CEGOZ Study." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AuthPage,
});

/** Only same-origin relative paths are accepted as post-login destinations. */
function safeRedirect(value: string | undefined): string {
  if (!value) return "/panel";
  try {
    const url = new URL(value, window.location.origin);
    if (url.origin !== window.location.origin) return "/panel";
    const path = url.pathname + url.search + url.hash;
    return path.startsWith("/auth") ? "/panel" : path;
  } catch {
    return "/panel";
  }
}

const AUTH_ERRORS: Record<string, string> = {
  "Invalid login credentials": "Correo o contraseña incorrectos.",
  "Email not confirmed": "Todavía no has confirmado tu correo. Revisa tu bandeja de entrada.",
  "User already registered": "Ya existe una cuenta con este correo. Inicia sesión.",
};

function translate(message: string) {
  for (const [k, v] of Object.entries(AUTH_ERRORS)) if (message.includes(k)) return v;
  if (/Password should be at least/i.test(message))
    return "La contraseña debe tener al menos 6 caracteres.";
  if (/email address.*(not allowed|invalid)|invalid.*email/i.test(message))
    return "Esta dirección de correo no es válida. Revisa que esté bien escrita.";
  if (/rate limit/i.test(message))
    return "Demasiados intentos. Espera unos minutos y vuelve a probar.";
  if (/weak|pwned|leaked/i.test(message))
    return "Esta contraseña es demasiado débil o conocida. Elige otra.";
  return message;
}

function GoogleIcon() {
  return (
    <svg aria-hidden="true" viewBox="0 0 24 24" className="size-[18px]">
      <path
        fill="#4285F4"
        d="M23.49 12.27c0-.79-.07-1.54-.19-2.27H12v4.51h6.47c-.29 1.48-1.14 2.73-2.4 3.58v3h3.86c2.26-2.09 3.56-5.17 3.56-8.82z"
      />
      <path
        fill="#34A853"
        d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.86-3c-1.08.72-2.45 1.16-4.07 1.16-3.13 0-5.78-2.11-6.73-4.96H1.29v3.09C3.26 21.3 7.31 24 12 24z"
      />
      <path
        fill="#FBBC05"
        d="M5.27 14.29c-.25-.72-.38-1.49-.38-2.29s.14-1.57.38-2.29V6.62H1.29C.47 8.24 0 10.06 0 12s.47 3.76 1.29 5.38l3.98-3.09z"
      />
      <path
        fill="#EA4335"
        d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.7 1.29 6.62l3.98 3.09c.95-2.85 3.6-4.96 6.73-4.96z"
      />
    </svg>
  );
}

function AuthPage() {
  const search = Route.useSearch();
  const navigate = useNavigate();
  const router = useRouter();
  const mode = search.mode ?? "signin";
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [sent, setSent] = useState<null | "signup" | "forgot">(null);

  const goNext = () => router.history.replace(safeRedirect(search.redirect));

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) goNext();
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const setMode = (m: "signin" | "signup" | "forgot") => {
    setError(null);
    setSent(null);
    navigate({ to: "/auth", search: { ...search, mode: m }, replace: true });
  };

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      if (mode === "signin") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        goNext();
      } else if (mode === "signup") {
        if (name.trim().length < 2) throw new Error("Escribe tu nombre.");
        if (password.length < 8) throw new Error("La contraseña debe tener al menos 8 caracteres.");
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: `${window.location.origin}/auth`, data: { display_name: name.trim() } },
        });
        if (error) throw error;
        if (data.session) goNext();
        else setSent("signup");
      } else {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: `${window.location.origin}/reset-password`,
        });
        if (error) throw error;
        setSent("forgot");
      }
    } catch (err) {
      setError(translate(errorMessage(err)));
    } finally {
      setLoading(false);
    }
  }

  async function social(provider: "google" | "lovable") {
    setError(null);
    sessionStorage.setItem("cegoz:after-login", safeRedirect(search.redirect));
    const result = await lovable.auth.signInWithOAuth(provider, {
      redirect_uri: window.location.origin,
    });
    if (result.error) {
      setError("No se ha podido iniciar sesión. Inténtalo de nuevo.");
      return;
    }
    if (result.redirected) return;
    goNext();
  }

  const titles = {
    signin: ["Bienvenido de nuevo", "Inicia sesión para seguir estudiando."],
    signup: ["Crea tu cuenta", "Empieza a estudiar con tu profesor virtual."],
    forgot: ["Recuperar contraseña", "Te enviaremos un enlace para crear una nueva."],
  } as const;

  return (
    <div className="grid min-h-screen place-items-center bg-background bg-gradient-hero px-4 py-10">
      <div className="w-full max-w-md animate-fade-up">
        <Link to="/" className="mb-8 flex justify-center">
          <Logo />
        </Link>
        <div className="rounded-3xl border bg-card p-6 shadow-soft sm:p-8">
          {sent ? (
            <div className="text-center">
              <span className="mx-auto grid size-12 place-items-center rounded-2xl bg-gradient-soft text-accent-foreground">
                <MailCheck className="size-6" />
              </span>
              <h1 className="mt-4 text-xl font-bold">Revisa tu correo</h1>
              <p className="mt-2 text-sm text-muted-foreground">
                {sent === "signup"
                  ? `Te hemos enviado un enlace de confirmación a ${email}. Ábrelo para activar tu cuenta y después inicia sesión.`
                  : `Si existe una cuenta con ${email}, recibirás un enlace para crear una nueva contraseña.`}
              </p>
              <Button className="mt-6 w-full" variant="outline" onClick={() => setMode("signin")}>
                Volver a iniciar sesión
              </Button>
            </div>
          ) : (
            <>
              <h1 className="text-2xl font-bold">{titles[mode][0]}</h1>
              <p className="mt-1 text-sm text-muted-foreground">{titles[mode][1]}</p>

              {mode !== "forgot" && (
                <div className="mt-6 grid gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    className="h-11"
                    onClick={() => social("google")}
                  >
                    <GoogleIcon /> Continuar con Google
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    className="h-11"
                    onClick={() => social("lovable")}
                  >
                    <LovableMark /> Continuar con Lovable
                  </Button>
                  <div className="my-2 flex items-center gap-3 text-xs text-muted-foreground">
                    <span className="h-px flex-1 bg-border" /> o con tu correo{" "}
                    <span className="h-px flex-1 bg-border" />
                  </div>
                </div>
              )}

              <form
                onSubmit={onSubmit}
                className={mode === "forgot" ? "mt-6 space-y-4" : "space-y-4"}
              >
                {mode === "signup" && (
                  <div className="space-y-1.5">
                    <Label htmlFor="name">Nombre</Label>
                    <Input
                      id="name"
                      autoComplete="name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      required
                    />
                  </div>
                )}
                <div className="space-y-1.5">
                  <Label htmlFor="email">Correo electrónico</Label>
                  <Input
                    id="email"
                    type="email"
                    autoComplete="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </div>
                {mode !== "forgot" && (
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="password">Contraseña</Label>
                      {mode === "signin" && (
                        <button
                          type="button"
                          onClick={() => setMode("forgot")}
                          className="text-xs font-semibold text-primary hover:underline"
                        >
                          ¿La has olvidado?
                        </button>
                      )}
                    </div>
                    <Input
                      id="password"
                      type="password"
                      autoComplete={mode === "signup" ? "new-password" : "current-password"}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      minLength={mode === "signup" ? 8 : undefined}
                    />
                    {mode === "signup" && (
                      <p className="text-xs text-muted-foreground">Mínimo 8 caracteres.</p>
                    )}
                  </div>
                )}
                {error && (
                  <p
                    role="alert"
                    className="rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive"
                  >
                    {error}
                  </p>
                )}
                <Button type="submit" variant="brand" className="h-11 w-full" disabled={loading}>
                  {loading
                    ? "Un momento…"
                    : mode === "signin"
                      ? "Iniciar sesión"
                      : mode === "signup"
                        ? "Crear cuenta"
                        : "Enviar enlace"}
                </Button>
              </form>

              <p className="mt-6 text-center text-sm text-muted-foreground">
                {mode === "signin" ? (
                  <>
                    ¿No tienes cuenta?{" "}
                    <button
                      type="button"
                      onClick={() => setMode("signup")}
                      className="font-semibold text-primary hover:underline"
                    >
                      Regístrate
                    </button>
                  </>
                ) : (
                  <>
                    ¿Ya tienes cuenta?{" "}
                    <button
                      type="button"
                      onClick={() => setMode("signin")}
                      className="font-semibold text-primary hover:underline"
                    >
                      Inicia sesión
                    </button>
                  </>
                )}
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
