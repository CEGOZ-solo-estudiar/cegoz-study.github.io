import { describe, expect, it } from "vitest";
import {
  adaptDifficulty,
  examGrade,
  gradeLabel,
  isChoiceCorrect,
  masteryStatus,
} from "@/lib/study/grading";

describe("study rules", () => {
  it("grades exams out of 10, unanswered questions count as 0", () => {
    expect(examGrade([1, 1, 0, 0.5], 4)).toBe(6.25);
    expect(examGrade([1, 1], 4)).toBe(5);
  });

  it("labels grades with the Spanish scale", () => {
    expect(gradeLabel(4.99)).toBe("Suspenso");
    expect(gradeLabel(5)).toBe("Aprobado");
    expect(gradeLabel(9)).toBe("Sobresaliente");
  });

  it("compares multiple-choice answers by option index", () => {
    expect(isChoiceCorrect("2", "2")).toBe(true);
    expect(isChoiceCorrect("2", "1")).toBe(false);
    expect(isChoiceCorrect("0", "")).toBe(false);
  });

  it("raises difficulty at 80 % correct and lowers it at 40 % or less", () => {
    expect(adaptDifficulty([true, true, true, true, false], "media")).toBe("dificil");
    expect(adaptDifficulty([false, false, true, false], "media")).toBe("facil");
    expect(adaptDifficulty([true, true, true], "media")).toBe("media");
  });

  it("marks a concept as mastered with 2+ attempts and 75 % correct", () => {
    expect(masteryStatus(3, 1)).toBe("dominado");
    expect(masteryStatus(1, 2)).toBe("repasar");
    expect(masteryStatus(1, 0)).toBe("en_progreso");
  });
});
