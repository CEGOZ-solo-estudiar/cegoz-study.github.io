import { Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

/** Visible indicator shown while the AI processes a request. */
export function AIWorking({
  label = "La IA está trabajando…",
  className,
}: {
  label?: string;
  className?: string;
}) {
  return (
    <div
      role="status"
      aria-live="polite"
      className={cn(
        "inline-flex items-center gap-3 rounded-xl border bg-gradient-soft px-4 py-3 text-sm font-medium text-accent-foreground",
        className,
      )}
    >
      <Sparkles className="size-4" />
      <span>{label}</span>
      <span className="flex gap-1" aria-hidden>
        {[0, 1, 2].map((i) => (
          <span
            key={i}
            className="size-1.5 rounded-full bg-brand-violet animate-pulse-dot"
            style={{ animationDelay: `${i * 0.18}s` }}
          />
        ))}
      </span>
    </div>
  );
}
