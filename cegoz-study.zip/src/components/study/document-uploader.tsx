import { useQueryClient } from "@tanstack/react-query";
import { useRef, useState, type DragEvent, type FormEvent } from "react";
import { CheckCircle2, ClipboardPaste, FileUp, Loader2, XCircle } from "lucide-react";
import { toast } from "sonner";
import { analyzeDocument, extractImageText } from "@/lib/functions/documents.functions";
import { saveDocument } from "@/lib/client/documents";
import { errorMessage } from "@/lib/client/errors";
import {
  ACCEPTED_FILES,
  MAX_DOCUMENT_CHARS,
  MAX_FILES_PER_UPLOAD,
  cleanText,
  extractFromFile,
  validateFile,
} from "@/lib/files/extract";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

type Job = { name: string; status: "working" | "done" | "error"; message: string };

export const ocrImages = async (images: string[]) =>
  (await extractImageText({ data: { images } })).text;

function titleFromFile(name: string) {
  return (
    name
      .replace(/\.[^.]+$/, "")
      .replace(/[_-]+/g, " ")
      .trim() || name
  );
}

export function DocumentUploader({ topicId }: { topicId: string }) {
  const qc = useQueryClient();
  const inputRef = useRef<HTMLInputElement>(null);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [busy, setBusy] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [pasteOpen, setPasteOpen] = useState(false);

  const refresh = () =>
    Promise.all([
      qc.invalidateQueries({ queryKey: ["topic", topicId] }),
      qc.invalidateQueries({ queryKey: ["library"] }),
    ]);

  const analyze = (documentId: string) =>
    analyzeDocument({ data: { documentId } })
      .then(() => qc.invalidateQueries({ queryKey: ["topic", topicId] }))
      .catch(() => undefined);

  async function processFiles(list: FileList | File[]) {
    const files = Array.from(list);
    if (files.length === 0) return;
    if (files.length > MAX_FILES_PER_UPLOAD) {
      toast.error(`Puedes subir como máximo ${MAX_FILES_PER_UPLOAD} archivos a la vez.`);
      return;
    }
    setBusy(true);
    setJobs(files.map((f) => ({ name: f.name, status: "working", message: "En espera…" })));
    const update = (i: number, patch: Partial<Job>) =>
      setJobs((prev) => prev.map((j, k) => (k === i ? { ...j, ...patch } : j)));

    let saved = 0;
    for (const [i, file] of files.entries()) {
      const invalid = validateFile(file);
      if (invalid) {
        update(i, { status: "error", message: invalid });
        continue;
      }
      try {
        const { text, kind } = await extractFromFile(file, ocrImages, (message) =>
          update(i, { message }),
        );
        update(i, { message: "Guardando…" });
        const id = await saveDocument({
          topicId,
          title: titleFromFile(file.name),
          kind,
          text,
          file,
        });
        saved++;
        update(i, {
          status: "done",
          message: `Listo · ${text.length.toLocaleString("es-ES")} caracteres`,
        });
        void analyze(id);
      } catch (e) {
        update(i, { status: "error", message: errorMessage(e) });
      }
    }
    await refresh();
    setBusy(false);
    if (saved > 0)
      toast.success(saved === 1 ? "Documento guardado" : `${saved} documentos guardados`);
    if (inputRef.current) inputRef.current.value = "";
  }

  function onDrop(e: DragEvent) {
    e.preventDefault();
    setDragging(false);
    if (!busy) void processFiles(e.dataTransfer.files);
  }

  return (
    <div className="rounded-2xl border bg-card p-5 shadow-soft">
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={onDrop}
        className={cn(
          "flex flex-col items-center rounded-xl border-2 border-dashed px-4 py-8 text-center transition-colors",
          dragging ? "border-primary bg-secondary/60" : "border-border",
        )}
      >
        <span className="grid size-12 place-items-center rounded-2xl bg-gradient-soft text-accent-foreground">
          <FileUp className="size-6" />
        </span>
        <p className="mt-3 font-semibold">Arrastra aquí tus apuntes</p>
        <p className="mt-1 text-xs text-muted-foreground">
          PDF, fotos (JPG, PNG, WEBP), Word (.docx) o texto. Hasta {MAX_FILES_PER_UPLOAD} archivos a
          la vez.
        </p>
        <div className="mt-4 flex flex-wrap justify-center gap-2">
          <Button variant="brand" disabled={busy} onClick={() => inputRef.current?.click()}>
            <FileUp /> Elegir archivos
          </Button>
          <Button variant="outline" disabled={busy} onClick={() => setPasteOpen(true)}>
            <ClipboardPaste /> Pegar texto
          </Button>
        </div>
        <input
          ref={inputRef}
          type="file"
          multiple
          accept={ACCEPTED_FILES}
          className="hidden"
          aria-label="Subir archivos"
          onChange={(e) => e.target.files && processFiles(e.target.files)}
        />
      </div>

      {jobs.length > 0 && (
        <ul className="mt-4 space-y-2" aria-live="polite">
          {jobs.map((j, i) => (
            <li
              key={`${j.name}-${i}`}
              className="flex items-start gap-3 rounded-lg bg-secondary/50 px-3 py-2 text-sm"
            >
              {j.status === "working" && (
                <Loader2 className="mt-0.5 size-4 shrink-0 animate-spin text-primary" />
              )}
              {j.status === "done" && (
                <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-success" />
              )}
              {j.status === "error" && (
                <XCircle className="mt-0.5 size-4 shrink-0 text-destructive" />
              )}
              <span className="min-w-0">
                <span className="block truncate font-medium">{j.name}</span>
                <span
                  className={cn(
                    "text-xs",
                    j.status === "error" ? "text-destructive" : "text-muted-foreground",
                  )}
                >
                  {j.message}
                </span>
              </span>
            </li>
          ))}
        </ul>
      )}

      <PasteDialog
        open={pasteOpen}
        onOpenChange={setPasteOpen}
        onSave={async (title, text) => {
          const id = await saveDocument({ topicId, title, kind: "pasted", text });
          await refresh();
          void analyze(id);
          toast.success("Texto guardado");
        }}
      />
    </div>
  );
}

function PasteDialog({
  open,
  onOpenChange,
  onSave,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  onSave: (title: string, text: string) => Promise<void>;
}) {
  const [title, setTitle] = useState("");
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: FormEvent) {
    e.preventDefault();
    const clean = cleanText(text);
    if (clean.length < 20) return setError("Pega al menos unas líneas de texto.");
    if (clean.length > MAX_DOCUMENT_CHARS)
      return setError("El texto es demasiado largo. Divídelo en varios documentos.");
    setBusy(true);
    setError(null);
    try {
      await onSave(title.trim() || "Texto pegado", clean);
      setTitle("");
      setText("");
      onOpenChange(false);
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl">
        <form onSubmit={submit} className="space-y-4">
          <DialogHeader>
            <DialogTitle>Pegar texto</DialogTitle>
          </DialogHeader>
          <div className="space-y-1.5">
            <Label htmlFor="paste-title">Título</Label>
            <Input
              id="paste-title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Apuntes de clase"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="paste-text">Texto</Label>
            <Textarea
              id="paste-text"
              value={text}
              onChange={(e) => setText(e.target.value)}
              rows={12}
            />
          </div>
          {error && <p className="text-sm text-destructive">{error}</p>}
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button type="submit" variant="brand" disabled={busy}>
              {busy ? "Guardando…" : "Guardar"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
