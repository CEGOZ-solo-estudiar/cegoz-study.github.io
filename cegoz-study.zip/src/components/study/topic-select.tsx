import { useQuery } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { libraryQuery } from "@/lib/client/queries";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";

/** Picks a topic that already has documents. Shows a shortcut to upload when there are none. */
export function TopicSelect({
  value,
  onChange,
  id,
}: {
  value: string | undefined;
  onChange: (topicId: string) => void;
  id?: string;
}) {
  const { data, isLoading } = useQuery(libraryQuery);
  if (isLoading) return <Skeleton className="h-10 w-full" />;
  const subjects = (data ?? [])
    .map((s) => ({ ...s, topics: s.topics.filter((t) => (t.documents[0]?.count ?? 0) > 0) }))
    .filter((s) => s.topics.length > 0);
  if (subjects.length === 0) {
    return (
      <p className="rounded-lg border border-dashed p-3 text-sm text-muted-foreground">
        Todavía no tienes temas con documentos.{" "}
        <Link to="/temarios" className="font-semibold text-primary hover:underline">
          Sube tus apuntes
        </Link>{" "}
        para empezar.
      </p>
    );
  }
  return (
    <Select value={value ?? ""} onValueChange={onChange}>
      <SelectTrigger id={id} className="h-10 w-full">
        <SelectValue placeholder="Elige un tema" />
      </SelectTrigger>
      <SelectContent>
        {subjects.map((s) => (
          <SelectGroup key={s.id}>
            <SelectLabel>{s.name}</SelectLabel>
            {s.topics.map((t) => (
              <SelectItem key={t.id} value={t.id}>
                {t.name}
              </SelectItem>
            ))}
          </SelectGroup>
        ))}
      </SelectContent>
    </Select>
  );
}
