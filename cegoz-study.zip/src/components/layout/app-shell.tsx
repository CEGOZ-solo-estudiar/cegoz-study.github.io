import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { LogOut, Menu, UserRound } from "lucide-react";
import { useState, type ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import { profileQuery } from "@/lib/client/queries";
import { cn } from "@/lib/utils";
import { Logo } from "@/components/study/logo";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { MOBILE_PRIMARY, NAV_ITEMS } from "./nav-items";

function useSignOut() {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  return async () => {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  };
}

function isActive(pathname: string, to: string) {
  return pathname === to || pathname.startsWith(`${to}/`);
}

function NavLink({
  to,
  label,
  icon: Icon,
  onClick,
}: (typeof NAV_ITEMS)[number] & { onClick?: () => void }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const active = isActive(pathname, to);
  return (
    <Link
      to={to}
      onClick={onClick}
      className={cn(
        "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors",
        active
          ? "bg-sidebar-accent text-sidebar-accent-foreground"
          : "text-sidebar-foreground hover:bg-sidebar-accent/60",
      )}
    >
      <Icon className={cn("size-[18px]", active && "text-primary")} />
      {label}
    </Link>
  );
}

function UserBlock({ onNavigate }: { onNavigate?: () => void }) {
  const { data: profile } = useQuery(profileQuery);
  const signOut = useSignOut();
  const name = profile?.display_name || "Mi cuenta";
  return (
    <div className="space-y-1 border-t border-sidebar-border pt-3">
      <Link
        to="/perfil"
        onClick={onNavigate}
        className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-sidebar-foreground hover:bg-sidebar-accent/60"
      >
        <span className="grid size-7 place-items-center rounded-full bg-gradient-soft text-xs font-bold text-accent-foreground">
          {name.slice(0, 1).toUpperCase()}
        </span>
        <span className="truncate">{name}</span>
      </Link>
      <button
        type="button"
        onClick={signOut}
        className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-muted-foreground hover:bg-sidebar-accent/60 hover:text-foreground"
      >
        <LogOut className="size-[18px]" />
        Cerrar sesión
      </button>
    </div>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const [moreOpen, setMoreOpen] = useState(false);
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const primary = NAV_ITEMS.filter((i) => (MOBILE_PRIMARY as readonly string[]).includes(i.to));

  return (
    <div className="min-h-screen bg-surface">
      {/* Desktop / tablet sidebar */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 flex-col border-r border-sidebar-border bg-sidebar px-4 py-5 lg:flex">
        <Link to="/panel" className="mb-8 px-2">
          <Logo />
        </Link>
        <nav className="flex-1 space-y-1" aria-label="Principal">
          {NAV_ITEMS.map((item) => (
            <NavLink key={item.to} {...item} />
          ))}
        </nav>
        <UserBlock />
      </aside>

      {/* Mobile top bar */}
      <header className="sticky top-0 z-30 flex h-14 items-center justify-between border-b bg-background/85 px-4 backdrop-blur lg:hidden">
        <Link to="/panel">
          <Logo />
        </Link>
        <Link
          to="/perfil"
          aria-label="Mi perfil"
          className="grid size-9 place-items-center rounded-full bg-secondary text-secondary-foreground"
        >
          <UserRound className="size-4" />
        </Link>
      </header>

      <main className="pb-24 lg:pb-10 lg:pl-64">
        <div className="mx-auto w-full max-w-6xl px-4 py-6 sm:px-6 lg:px-10 lg:py-10">
          {children}
        </div>
      </main>

      {/* Mobile bottom navigation */}
      <nav
        aria-label="Navegación móvil"
        className="fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t bg-background/95 pb-[env(safe-area-inset-bottom)] backdrop-blur lg:hidden"
      >
        {primary.map(({ to, label, icon: Icon }) => {
          const active = isActive(pathname, to);
          return (
            <Link
              key={to}
              to={to}
              className={cn(
                "flex flex-col items-center gap-1 py-2.5 text-[11px] font-medium",
                active ? "text-primary" : "text-muted-foreground",
              )}
            >
              <Icon className="size-5" />
              {label.startsWith("Modo ") ? label.charAt(5).toUpperCase() + label.slice(6) : label}
            </Link>
          );
        })}
        <button
          type="button"
          onClick={() => setMoreOpen(true)}
          className="flex flex-col items-center gap-1 py-2.5 text-[11px] font-medium text-muted-foreground"
        >
          <Menu className="size-5" />
          Más
        </button>
      </nav>

      <Sheet open={moreOpen} onOpenChange={setMoreOpen}>
        <SheetContent side="bottom" className="rounded-t-3xl pb-8">
          <SheetHeader>
            <SheetTitle>Menú</SheetTitle>
          </SheetHeader>
          <div className="mt-2 space-y-1 px-4">
            {NAV_ITEMS.map((item) => (
              <NavLink key={item.to} {...item} onClick={() => setMoreOpen(false)} />
            ))}
          </div>
          <div className="mt-3 px-4">
            <UserBlock onNavigate={() => setMoreOpen(false)} />
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}
