import {
  BarChart3,
  BookOpenText,
  ClipboardCheck,
  Dumbbell,
  Layers,
  LayoutDashboard,
  Presentation,
} from "lucide-react";

export const NAV_ITEMS = [
  { to: "/panel", label: "Inicio", icon: LayoutDashboard },
  { to: "/temarios", label: "Temarios", icon: BookOpenText },
  { to: "/clase", label: "Modo clase", icon: Presentation },
  { to: "/examen", label: "Modo examen", icon: ClipboardCheck },
  { to: "/practica", label: "Práctica", icon: Dumbbell },
  { to: "/resumenes", label: "Resúmenes y tarjetas", icon: Layers },
  { to: "/progreso", label: "Progreso", icon: BarChart3 },
] as const;

export const MOBILE_PRIMARY = ["/panel", "/temarios", "/clase", "/examen"] as const;
