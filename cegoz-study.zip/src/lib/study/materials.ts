export const MATERIAL_KINDS = {
  resumen: { label: "Resumen completo", description: "Todo el temario condensado por apartados." },
  esquema: { label: "Esquema", description: "Estructura jerárquica de ideas." },
  conceptos: { label: "Conceptos esenciales", description: "Las ideas clave explicadas." },
  definiciones: { label: "Definiciones", description: "Términos y su significado." },
  tarjetas: { label: "Tarjetas de memoria", description: "Repaso activo con anverso y reverso." },
  preguntas_repaso: { label: "Preguntas de repaso", description: "Preguntas con su respuesta." },
  lista_conceptos: { label: "Lista de conceptos", description: "Conceptos importantes del tema." },
} as const;

export type MaterialKind = keyof typeof MATERIAL_KINDS;
