import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

/** Maximum characters of study material sent to the AI in one request. */
export const MAX_MATERIAL_CHARS = 160_000;

export type TopicMaterial = {
  topicId: string;
  topicName: string;
  subjectName: string;
  documentCount: number;
  text: string;
  truncated: boolean;
};

export async function loadTopicMaterial(
  supabase: SupabaseClient<Database>,
  topicId: string,
  maxChars = MAX_MATERIAL_CHARS,
): Promise<TopicMaterial> {
  const { data: topic, error: topicError } = await supabase
    .from("topics")
    .select("id, name, subjects(name)")
    .eq("id", topicId)
    .maybeSingle();
  if (topicError) throw new Error("No se ha podido cargar el tema.");
  if (!topic) throw new Error("El tema no existe o no tienes acceso a él.");

  const { data: docs, error } = await supabase
    .from("documents")
    .select("title, content")
    .eq("topic_id", topicId)
    .order("created_at", { ascending: true });
  if (error) throw new Error("No se han podido cargar los documentos del tema.");

  const usable = (docs ?? []).filter((d) => d.content.trim().length > 0);
  if (usable.length === 0) {
    throw new Error(
      "Este tema todavía no tiene documentos con texto. Sube tus apuntes en «Temarios» para empezar.",
    );
  }

  let text = "";
  let truncated = false;
  for (const doc of usable) {
    const block = `\n\n### Documento: ${doc.title}\n\n${doc.content.trim()}`;
    if (text.length + block.length > maxChars) {
      text += block.slice(0, Math.max(0, maxChars - text.length));
      truncated = true;
      break;
    }
    text += block;
  }

  const subject = topic.subjects as unknown as { name: string } | null;
  return {
    topicId: topic.id,
    topicName: topic.name,
    subjectName: subject?.name ?? "",
    documentCount: usable.length,
    text: text.trim(),
    truncated,
  };
}

export async function loadWeakConcepts(
  supabase: SupabaseClient<Database>,
  topicId: string,
): Promise<{ weak: string[]; strong: string[] }> {
  const { data } = await supabase
    .from("concept_mastery")
    .select("concept, correct_count, incorrect_count")
    .eq("topic_id", topicId)
    .order("last_seen_at", { ascending: false })
    .limit(60);
  const weak: string[] = [];
  const strong: string[] = [];
  for (const row of data ?? []) {
    const total = row.correct_count + row.incorrect_count;
    if (total === 0) continue;
    const ratio = row.correct_count / total;
    if (ratio < 0.6) weak.push(row.concept);
    else if (total >= 2 && ratio >= 0.75) strong.push(row.concept);
  }
  return { weak: weak.slice(0, 15), strong: strong.slice(0, 15) };
}
