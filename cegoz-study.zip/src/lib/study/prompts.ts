export const STUDENT_LEVELS = {
  basico: "Básico (secundaria / iniciación)",
  intermedio: "Intermedio (bachillerato / FP)",
  avanzado: "Avanzado (universidad / oposiciones)",
} as const;

export type StudentLevel = keyof typeof STUDENT_LEVELS;

export function levelDescription(level: string | null | undefined): string {
  return STUDENT_LEVELS[(level as StudentLevel) ?? "intermedio"] ?? STUDENT_LEVELS.intermedio;
}

/** Rules shared by every prompt that relies on the student's material. */
export const GROUNDING_RULES = `REGLAS DE FIDELIDAD AL TEMARIO (obligatorias):
- Tu ÚNICA fuente de contenido es el TEMARIO del estudiante que aparece entre <temario> y </temario>.
- No inventes datos, fechas, fórmulas, definiciones ni afirmaciones que no estén en el temario.
- Si algo que se pide no aparece en el temario, dilo claramente ("Esto no aparece en tu temario") en lugar de inventarlo.
- Puedes crear ejemplos sencillos o analogías para ayudar a entender, pero preséntalos siempre como ejemplos tuyos, nunca como contenido del documento.
- Escribe siempre en español correcto, claro y natural.`;

export function wrapMaterial(material: string): string {
  return `<temario>\n${material}\n</temario>`;
}
