/** Pure study rules shared by the server and the UI. Covered by src/test/grading.test.ts. */

export type Difficulty = "facil" | "media" | "dificil";
export type QuestionType = "test" | "desarrollo" | "practico" | "rapida";

export const DIFFICULTY_LABELS: Record<Difficulty, string> = {
  facil: "Fácil",
  media: "Media",
  dificil: "Difícil",
};

export const QUESTION_TYPE_LABELS: Record<QuestionType, string> = {
  test: "Tipo test",
  desarrollo: "Desarrollo",
  practico: "Ejercicio práctico",
  rapida: "Pregunta rápida",
};

/** An open answer counts as correct from this score (0–1) upwards. */
export const PASS_THRESHOLD = 0.5;

export const EXAM_MIN_QUESTIONS = 3;
export const EXAM_MAX_QUESTIONS = 20;

/** Exam grade out of 10, rounded to two decimals. Unanswered questions score 0. */
export function examGrade(scores: number[], totalQuestions: number): number {
  if (totalQuestions <= 0) return 0;
  const sum = scores.reduce((acc, s) => acc + Math.min(1, Math.max(0, s)), 0);
  const grade = (sum / totalQuestions) * 10;
  return Math.round(grade * 100) / 100;
}

export function normalizeAnswer(value: string): string {
  return value
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^\p{L}\p{N}\s.,-]/gu, "")
    .replace(/\s+/g, " ")
    .trim();
}

/** Multiple-choice answers are stored as the zero-based option index. */
export function isChoiceCorrect(correctIndex: string, answer: string | null | undefined): boolean {
  if (answer == null || answer === "") return false;
  return Number.parseInt(correctIndex, 10) === Number.parseInt(answer, 10);
}

const ORDER: Difficulty[] = ["facil", "media", "dificil"];

/**
 * Adaptive difficulty: with at least 4 recent answers, ≥ 80 % correct raises
 * the level and ≤ 40 % lowers it; otherwise it stays.
 */
export function adaptDifficulty(recentResults: boolean[], current: Difficulty): Difficulty {
  if (recentResults.length < 4) return current;
  const accuracy = recentResults.filter(Boolean).length / recentResults.length;
  const idx = ORDER.indexOf(current);
  if (accuracy >= 0.8) return ORDER[Math.min(ORDER.length - 1, idx + 1)] ?? current;
  if (accuracy <= 0.4) return ORDER[Math.max(0, idx - 1)] ?? current;
  return current;
}

export type MasteryStatus = "dominado" | "repasar" | "en_progreso";

/**
 * Mastered: at least 2 attempts with ≥ 75 % correct.
 * Needs review: at least one failure and < 60 % correct.
 */
export function masteryStatus(correct: number, incorrect: number): MasteryStatus {
  const total = correct + incorrect;
  if (total === 0) return "en_progreso";
  const ratio = correct / total;
  if (total >= 2 && ratio >= 0.75) return "dominado";
  if (incorrect >= 1 && ratio < 0.6) return "repasar";
  return "en_progreso";
}

export function gradeLabel(grade: number): string {
  if (grade < 5) return "Suspenso";
  if (grade < 6) return "Aprobado";
  if (grade < 7) return "Bien";
  if (grade < 9) return "Notable";
  return "Sobresaliente";
}
