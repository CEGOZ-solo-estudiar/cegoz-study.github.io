import type { AIProvider } from "@/lib/ai/types";
import { GROUNDING_RULES, levelDescription, wrapMaterial } from "./prompts";
import type { Difficulty, QuestionType } from "./grading";
import { DIFFICULTY_LABELS, QUESTION_TYPE_LABELS } from "./grading";

export type GeneratedQuestion = {
  qtype: QuestionType;
  prompt: string;
  options: string[];
  correct_option: number;
  model_answer: string;
  explanation: string;
  rubric: string;
  concept: string;
};

const QUESTION_SCHEMA = {
  type: "object",
  additionalProperties: false,
  properties: {
    questions: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        properties: {
          qtype: { type: "string", enum: ["test", "desarrollo", "practico", "rapida"] },
          prompt: { type: "string" },
          options: { type: "array", items: { type: "string" } },
          correct_option: { type: "integer" },
          model_answer: { type: "string" },
          explanation: { type: "string" },
          rubric: { type: "string" },
          concept: { type: "string" },
        },
        required: [
          "qtype",
          "prompt",
          "options",
          "correct_option",
          "model_answer",
          "explanation",
          "rubric",
          "concept",
        ],
      },
    },
  },
  required: ["questions"],
};

export async function generateQuestions(
  ai: AIProvider,
  args: {
    material: string;
    topicName: string;
    count: number;
    difficulty: Difficulty;
    types: QuestionType[];
    level: string;
    weakConcepts: string[];
    avoidPrompts: string[];
    purpose: "examen" | "practica";
  },
): Promise<GeneratedQuestion[]> {
  const typeList = args.types.map((t) => `"${t}" (${QUESTION_TYPE_LABELS[t]})`).join(", ");
  const system = `Eres un profesor experto que prepara ${args.purpose === "examen" ? "exámenes" : "ejercicios de práctica"} a partir de los apuntes de un estudiante.
${GROUNDING_RULES}

INSTRUCCIONES:
- Genera exactamente ${args.count} preguntas sobre el tema «${args.topicName}».
- Dificultad: ${DIFFICULTY_LABELS[args.difficulty]}. Nivel del estudiante: ${levelDescription(args.level)}.
- Tipos permitidos: ${typeList}. ${args.types.length > 1 ? "Mézclalos de forma equilibrada." : ""}
- Genera "practico" SOLO si el temario contiene procedimientos, cálculos, casos o problemas aplicables; si no, usa otro tipo permitido.
- Cada pregunta debe poder responderse únicamente con el temario. Reparte las preguntas entre los distintos apartados del temario.
- "test": entre 3 y 4 opciones plausibles en "options", una sola correcta, y su índice (empezando en 0) en "correct_option". No uses "todas las anteriores".
- "desarrollo", "practico" y "rapida": "options" vacío y "correct_option" = -1. "rapida" se responde con una palabra o una frase corta.
- "model_answer": respuesta correcta completa según el temario.
- "explanation": por qué esa es la respuesta correcta, citando lo que dice el temario.
- "rubric": criterios concretos para puntuar una respuesta abierta (vacío en "test").
- "concept": el concepto evaluado, en 2-6 palabras.
- No reveles la respuesta dentro del enunciado.
${args.weakConcepts.length ? `- Refuerza especialmente estos conceptos que el estudiante falla: ${args.weakConcepts.join("; ")}.` : ""}
${args.avoidPrompts.length ? `- No repitas estas preguntas ya hechas:\n${args.avoidPrompts.map((p) => `  · ${p.slice(0, 160)}`).join("\n")}` : ""}`;

  const result = await ai.generateJSON<{ questions: GeneratedQuestion[] }>({
    system,
    schemaName: "preguntas",
    schema: QUESTION_SCHEMA,
    maxOutputTokens: Math.min(16000, 1200 + args.count * 650),
    timeoutMs: 150_000,
    messages: [
      {
        role: "user",
        content: `${wrapMaterial(args.material)}\n\nGenera las preguntas. Devuelve JSON.`,
      },
    ],
  });

  const valid = (result.questions ?? []).filter((q) => {
    if (!q.prompt?.trim()) return false;
    if (!args.types.includes(q.qtype)) return false;
    if (q.qtype === "test") {
      return (
        Array.isArray(q.options) &&
        q.options.length >= 2 &&
        q.correct_option >= 0 &&
        q.correct_option < q.options.length
      );
    }
    return q.model_answer?.trim().length > 0;
  });
  if (valid.length === 0) {
    throw new Error(
      "La IA no ha podido generar preguntas válidas con este temario. Inténtalo de nuevo.",
    );
  }
  return valid.slice(0, args.count);
}

export type OpenGradeItem = {
  id: string;
  qtype: string;
  prompt: string;
  model_answer: string;
  rubric: string;
  answer: string;
};

export type OpenGradeResult = { id: string; score: number; feedback: string };

const GRADE_SCHEMA = {
  type: "object",
  additionalProperties: false,
  properties: {
    results: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        properties: {
          id: { type: "string" },
          score: { type: "number" },
          feedback: { type: "string" },
        },
        required: ["id", "score", "feedback"],
      },
    },
    overall_feedback: { type: "string" },
  },
  required: ["results", "overall_feedback"],
};

export async function gradeOpenAnswers(
  ai: AIProvider,
  items: OpenGradeItem[],
  level: string,
): Promise<{ results: Map<string, OpenGradeResult>; overall: string }> {
  if (items.length === 0) return { results: new Map(), overall: "" };
  const system = `Eres un profesor que corrige respuestas abiertas de un estudiante (nivel: ${levelDescription(level)}).
Para cada respuesta:
- Compárala con la respuesta modelo y los criterios. Puntúa de 0 a 1 (0 = incorrecta o vacía, 0.5 = parcialmente correcta, 1 = completa y correcta). Usa decimales si hace falta.
- Sé justo: acepta sinónimos y redacciones diferentes si el contenido es correcto.
- En "feedback" (2-4 frases en español) explica qué está bien, qué falta o qué es erróneo y por qué, en tono cercano y motivador.
- No inventes contenido que no esté en la respuesta modelo.
En "overall_feedback" resume en 2-3 frases los puntos fuertes y lo que debe repasar.`;
  const payload = items
    .map(
      (i) =>
        `<pregunta id="${i.id}" tipo="${i.qtype}">\nEnunciado: ${i.prompt}\nRespuesta modelo: ${i.model_answer}\nCriterios: ${i.rubric || "—"}\nRespuesta del estudiante: ${i.answer.trim() || "(sin respuesta)"}\n</pregunta>`,
    )
    .join("\n\n");
  const out = await ai.generateJSON<{ results: OpenGradeResult[]; overall_feedback: string }>({
    system,
    schemaName: "correccion",
    schema: GRADE_SCHEMA,
    maxOutputTokens: 800 + items.length * 400,
    timeoutMs: 120_000,
    messages: [{ role: "user", content: `${payload}\n\nCorrige y devuelve JSON.` }],
  });
  const map = new Map<string, OpenGradeResult>();
  for (const r of out.results ?? []) {
    map.set(r.id, {
      id: r.id,
      score: Math.min(1, Math.max(0, Number(r.score) || 0)),
      feedback: r.feedback,
    });
  }
  return { results: map, overall: out.overall_feedback ?? "" };
}
