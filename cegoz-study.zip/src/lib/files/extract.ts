/**
 * Browser-side text extraction for the student's material.
 * PDF → pdf.js (scanned pages fall back to OCR), images → OCR on the server,
 * Word (.docx) → mammoth, plain text → read directly.
 * Only import this module from event handlers / client components.
 */

export type SourceKind = "pdf" | "image" | "docx" | "text";

export const ACCEPTED_FILES =
  ".pdf,.png,.jpg,.jpeg,.webp,.docx,.txt,.md,application/pdf,image/png,image/jpeg,image/webp,text/plain,text/markdown,application/vnd.openxmlformats-officedocument.wordprocessingml.document";

const MB = 1024 * 1024;
export const FILE_LIMITS: Record<SourceKind, number> = {
  pdf: 25 * MB,
  image: 15 * MB,
  docx: 15 * MB,
  text: 5 * MB,
};

export const MAX_FILES_PER_UPLOAD = 10;
export const MAX_DOCUMENT_CHARS = 400_000;
const MAX_OCR_PAGES = 20;

export const SOURCE_LABELS: Record<SourceKind | "pasted", string> = {
  pdf: "PDF",
  image: "Imagen",
  docx: "Word",
  text: "Texto",
  pasted: "Texto pegado",
};

export function detectKind(file: File): SourceKind | null {
  const name = file.name.toLowerCase();
  if (file.type === "application/pdf" || name.endsWith(".pdf")) return "pdf";
  if (/^image\/(png|jpe?g|webp)$/.test(file.type) || /\.(png|jpe?g|webp)$/.test(name))
    return "image";
  if (name.endsWith(".docx")) return "docx";
  if (file.type.startsWith("text/") || /\.(txt|md)$/.test(name)) return "text";
  return null;
}

/** Returns an error message in Spanish, or null when the file is acceptable. */
export function validateFile(file: File): string | null {
  const kind = detectKind(file);
  if (!kind) {
    if (file.name.toLowerCase().endsWith(".doc"))
      return `«${file.name}»: el formato .doc antiguo no es compatible. Guárdalo como .docx o PDF.`;
    return `«${file.name}»: formato no compatible. Usa PDF, imágenes (JPG, PNG, WEBP), Word (.docx) o texto (.txt, .md).`;
  }
  if (file.size === 0) return `«${file.name}» está vacío.`;
  if (file.size > FILE_LIMITS[kind]) {
    return `«${file.name}» supera el tamaño máximo de ${Math.round(FILE_LIMITS[kind] / MB)} MB para este tipo de archivo.`;
  }
  return null;
}

export type OcrFn = (images: string[]) => Promise<string>;
export type ProgressFn = (message: string) => void;

export async function extractFromFile(
  file: File,
  ocr: OcrFn,
  onProgress: ProgressFn = () => {},
): Promise<{ text: string; kind: SourceKind }> {
  const kind = detectKind(file);
  if (!kind) throw new Error(validateFile(file) ?? "Formato no compatible.");
  let text: string;
  switch (kind) {
    case "pdf":
      text = await extractPdf(file, ocr, onProgress);
      break;
    case "image":
      onProgress("Leyendo la imagen con IA…");
      text = await ocr([await imageFileToDataUrl(file)]);
      break;
    case "docx":
      onProgress("Leyendo el documento de Word…");
      text = await extractDocx(file);
      break;
    default:
      onProgress("Leyendo el texto…");
      text = await file.text();
  }
  text = cleanText(text);
  if (!text) throw new Error(`No se ha encontrado texto legible en «${file.name}».`);
  return { text: text.slice(0, MAX_DOCUMENT_CHARS), kind };
}

export function cleanText(text: string): string {
  return text
    .replace(/\r\n?/g, "\n")
    .replace(/[ \t]+\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

async function loadPdfjs() {
  const pdfjs = await import("pdfjs-dist");
  const worker = await import("pdfjs-dist/build/pdf.worker.min.mjs?url");
  pdfjs.GlobalWorkerOptions.workerSrc = worker.default;
  return pdfjs;
}

async function extractPdf(file: File, ocr: OcrFn, onProgress: ProgressFn): Promise<string> {
  onProgress("Abriendo el PDF…");
  const pdfjs = await loadPdfjs();
  let doc;
  try {
    doc = await pdfjs.getDocument({ data: new Uint8Array(await file.arrayBuffer()) }).promise;
  } catch (e) {
    const name = (e as { name?: string }).name;
    if (name === "PasswordException")
      throw new Error(`«${file.name}» está protegido con contraseña.`);
    throw new Error(`No se ha podido abrir «${file.name}». Comprueba que el PDF no esté dañado.`);
  }
  const pages: string[] = [];
  for (let i = 1; i <= doc.numPages; i++) {
    onProgress(`Extrayendo texto: página ${i} de ${doc.numPages}…`);
    const page = await doc.getPage(i);
    const content = await page.getTextContent();
    let pageText = "";
    for (const item of content.items) {
      if ("str" in item) {
        pageText += item.str;
        if (item.hasEOL) pageText += "\n";
        else if (item.str && !item.str.endsWith(" ")) pageText += " ";
      }
    }
    pages.push(pageText.trim());
  }
  const totalChars = pages.join("").replace(/\s/g, "").length;
  // Scanned PDF (images only): fall back to OCR page by page.
  if (totalChars < 60 * doc.numPages) {
    const count = Math.min(doc.numPages, MAX_OCR_PAGES);
    const ocrPages: string[] = [];
    for (let start = 1; start <= count; start += 3) {
      const batch: string[] = [];
      for (let i = start; i < start + 3 && i <= count; i++) {
        onProgress(`PDF escaneado: preparando página ${i} de ${count}…`);
        batch.push(await renderPdfPage(doc, i));
      }
      onProgress(`Leyendo páginas ${start}–${Math.min(start + 2, count)} con IA…`);
      ocrPages.push(await ocr(batch));
    }
    let result = ocrPages.join("\n\n");
    if (doc.numPages > MAX_OCR_PAGES) {
      result += `\n\n[Nota: solo se han leído las primeras ${MAX_OCR_PAGES} páginas escaneadas.]`;
    }
    return result;
  }
  return pages.map((p, i) => `[Página ${i + 1}]\n${p}`).join("\n\n");
}

async function renderPdfPage(
  doc: { getPage: (n: number) => Promise<unknown> },
  pageNumber: number,
): Promise<string> {
  const page = (await doc.getPage(pageNumber)) as {
    getViewport: (o: { scale: number }) => { width: number; height: number };
    render: (o: {
      canvasContext: CanvasRenderingContext2D;
      viewport: unknown;
      canvas: HTMLCanvasElement;
    }) => {
      promise: Promise<void>;
    };
  };
  const base = page.getViewport({ scale: 1 });
  const scale = Math.min(2, 1600 / Math.max(base.width, base.height));
  const viewport = page.getViewport({ scale });
  const canvas = document.createElement("canvas");
  canvas.width = Math.floor(viewport.width);
  canvas.height = Math.floor(viewport.height);
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Tu navegador no permite procesar el PDF.");
  await page.render({ canvasContext: ctx, viewport, canvas }).promise;
  return canvas.toDataURL("image/jpeg", 0.82);
}

async function extractDocx(file: File): Promise<string> {
  const mod = (await import("mammoth/mammoth.browser.min.js")) as unknown as {
    default?: MammothLike;
  } & MammothLike;
  const mammoth = mod.default ?? mod;
  try {
    const result = await mammoth.extractRawText({ arrayBuffer: await file.arrayBuffer() });
    return result.value;
  } catch {
    throw new Error(
      `No se ha podido leer «${file.name}». Comprueba que sea un documento .docx válido.`,
    );
  }
}

type MammothLike = {
  extractRawText: (input: { arrayBuffer: ArrayBuffer }) => Promise<{ value: string }>;
};

/** Downscales a photo so OCR requests stay small. */
export async function imageFileToDataUrl(file: File, maxSide = 2000): Promise<string> {
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const el = new Image();
      el.onload = () => resolve(el);
      el.onerror = () => reject(new Error(`No se ha podido abrir la imagen «${file.name}».`));
      el.src = url;
    });
    const scale = Math.min(1, maxSide / Math.max(img.naturalWidth, img.naturalHeight));
    const canvas = document.createElement("canvas");
    canvas.width = Math.round(img.naturalWidth * scale);
    canvas.height = Math.round(img.naturalHeight * scale);
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("Tu navegador no permite procesar imágenes.");
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL("image/jpeg", 0.85);
  } finally {
    URL.revokeObjectURL(url);
  }
}

export function formatBytes(bytes: number | null | undefined): string {
  if (!bytes) return "—";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < MB) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / MB).toFixed(1)} MB`;
}
