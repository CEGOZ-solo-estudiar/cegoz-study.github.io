/**
 * Provider-agnostic AI contract. Every AI feature in CEGOZ Study talks to this
 * interface, so swapping the underlying provider only means adding a new
 * implementation in ./providers and selecting it in ./index.server.ts.
 */
export type AIContentPart = { type: "text"; text: string } | { type: "image"; dataUrl: string };

export type AIMessage = {
  role: "user" | "assistant";
  content: string | AIContentPart[];
};

export type JsonSchema = Record<string, unknown>;

export interface AIGenerateOptions {
  system: string;
  messages: AIMessage[];
  maxOutputTokens?: number;
  /** Hard limit for the whole call, in milliseconds. */
  timeoutMs?: number;
}

export interface AIJsonOptions extends AIGenerateOptions {
  schemaName: string;
  /** Strict JSON schema: every property required, additionalProperties false. */
  schema: JsonSchema;
}

export interface AIProvider {
  readonly name: string;
  generateText(options: AIGenerateOptions): Promise<string>;
  generateJSON<T>(options: AIJsonOptions): Promise<T>;
}

export type AIErrorCode =
  "rate_limit" | "credits" | "timeout" | "config" | "rejected" | "unavailable" | "invalid_response";

const USER_MESSAGES: Record<AIErrorCode, string> = {
  rate_limit:
    "La IA está recibiendo demasiadas peticiones. Espera un momento y vuelve a intentarlo.",
  credits:
    "Se ha agotado la cuota de uso de la IA. El propietario de la aplicación debe recargar créditos para continuar.",
  timeout: "La IA ha tardado demasiado en responder. Inténtalo de nuevo en unos segundos.",
  config: "La IA no está configurada correctamente en el servidor.",
  rejected:
    "La IA no ha podido procesar esta petición. Prueba con un temario más corto o distinto.",
  unavailable: "La IA no está disponible en este momento. Inténtalo de nuevo más tarde.",
  invalid_response: "La IA ha devuelto una respuesta no válida. Vuelve a intentarlo.",
};

export class AIError extends Error {
  readonly code: AIErrorCode;
  constructor(code: AIErrorCode, detail?: string) {
    super(USER_MESSAGES[code]);
    this.name = "AIError";
    this.code = code;
    if (detail) console.error(`[AI:${code}]`, detail);
  }
}
