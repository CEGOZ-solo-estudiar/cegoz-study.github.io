import type { AIProvider } from "./types";
import { lovableGatewayProvider } from "./providers/lovable-gateway.server";

/**
 * Returns the active AI provider. To add another provider, implement
 * `AIProvider` in ./providers and register it here; select it with the
 * AI_PROVIDER server environment variable.
 */
const providers: Record<string, AIProvider> = {
  lovable: lovableGatewayProvider,
};

export function getAI(): AIProvider {
  const key = process.env["AI_PROVIDER"] ?? "lovable";
  return providers[key] ?? lovableGatewayProvider;
}

export { AIError } from "./types";
