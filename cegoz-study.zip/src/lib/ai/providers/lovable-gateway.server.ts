import {
  AuthenticationError,
  CancelledError,
  ConfigurationError,
  GatewayError,
  generateResponse,
  PaymentRequiredError,
  PermissionDeniedError,
  RateLimitError,
  RequestRejectedError,
  TimeoutError,
  InvalidResponseError,
} from "@lovable.dev/ai-gateway";

import {
  AIError,
  type AIGenerateOptions,
  type AIJsonOptions,
  type AIMessage,
  type AIProvider,
} from "../types";

const MODEL = "openai/gpt-6-astra" as const;
const DEFAULT_TIMEOUT_MS = 120_000;

function toInput(messages: AIMessage[]) {
  return messages.map((m) => {
    if (typeof m.content === "string") {
      return { role: m.role, content: m.content };
    }
    if (m.role === "assistant") {
      return {
        role: "assistant" as const,
        content: m.content.map((p) => (p.type === "text" ? p.text : "")).join("\n"),
      };
    }
    return {
      role: "user" as const,
      content: m.content.map((p) =>
        p.type === "text"
          ? { type: "input_text" as const, text: p.text }
          : { type: "input_image" as const, image_url: p.dataUrl, detail: "high" as const },
      ),
    };
  });
}

function extractText(response: unknown): string {
  const output = (response as { output?: unknown[] }).output ?? [];
  const parts: string[] = [];
  for (const item of output) {
    const it = item as { type?: string; content?: { type?: string; text?: string }[] };
    if (it.type !== "message" || !Array.isArray(it.content)) continue;
    for (const c of it.content) {
      if (c.type === "output_text" && typeof c.text === "string") parts.push(c.text);
      if (c.type === "refusal") throw new AIError("rejected", "Provider refusal");
    }
  }
  return parts.join("").trim();
}

function mapError(error: unknown): never {
  if (error instanceof AIError) throw error;
  if (error instanceof RateLimitError) throw new AIError("rate_limit", error.message);
  if (error instanceof PaymentRequiredError) throw new AIError("credits", error.message);
  if (error instanceof TimeoutError || error instanceof CancelledError)
    throw new AIError("timeout", error.message);
  if (error instanceof ConfigurationError || error instanceof AuthenticationError)
    throw new AIError("config", error.message);
  if (error instanceof RequestRejectedError || error instanceof PermissionDeniedError)
    throw new AIError("rejected", error.message);
  if (error instanceof InvalidResponseError) throw new AIError("invalid_response", error.message);
  if (error instanceof GatewayError)
    throw new AIError("unavailable", `${error.code}: ${error.message}`);
  if (error instanceof Error && error.name === "TimeoutError")
    throw new AIError("timeout", error.message);
  throw new AIError("unavailable", error instanceof Error ? error.message : String(error));
}

async function call(
  options: AIGenerateOptions,
  format?: { name: string; schema: Record<string, unknown> },
) {
  try {
    const response = await generateResponse(
      {
        model: MODEL,
        instructions: options.system,
        input: toInput(options.messages),
        max_output_tokens: options.maxOutputTokens ?? 4000,
        ...(format
          ? {
              text: {
                format: {
                  type: "json_schema" as const,
                  name: format.name,
                  strict: true,
                  schema: format.schema,
                },
              },
            }
          : {}),
      },
      { signal: AbortSignal.timeout(options.timeoutMs ?? DEFAULT_TIMEOUT_MS) },
    );
    const status = (response as { status?: string }).status;
    const text = extractText(response);
    if (!text) {
      throw new AIError("invalid_response", `Empty output (status: ${status ?? "unknown"})`);
    }
    return { text, status };
  } catch (error) {
    mapError(error);
  }
}

export const lovableGatewayProvider: AIProvider = {
  name: "lovable-ai-gateway",
  async generateText(options) {
    const { text } = await call(options);
    return text;
  },
  async generateJSON<T>(options: AIJsonOptions) {
    const { text, status } = await call(options, {
      name: options.schemaName,
      schema: options.schema,
    });
    try {
      return JSON.parse(text) as T;
    } catch {
      throw new AIError(
        "invalid_response",
        `Unparseable JSON (status: ${status ?? "unknown"}, length ${text.length})`,
      );
    }
  },
};
