import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const MAX_IMAGES = 6;
const MAX_IMAGE_CHARS = 6_000_000; // ~4.5 MB of base64 per image

/** OCR: transcribes photos or scanned pages of the student's notes. */
export const extractImageText = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        images: z
          .array(
            z
              .string()
              .max(MAX_IMAGE_CHARS)
              .regex(/^data:image\/(png|jpeg|jpg|webp);base64,/),
          )
          .min(1)
          .max(MAX_IMAGES),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const { getAI } = await import("@/lib/ai/index.server");
    const text = await getAI().generateText({
      system: `Eres un sistema de transcripción (OCR) de apuntes de estudio.
- Transcribe fielmente TODO el texto legible de las imágenes, en el orden de lectura natural y en su idioma original.
- Conserva títulos, listas, numeraciones y tablas usando Markdown.
- Escribe las fórmulas en texto plano legible (por ejemplo: x^2 + 3x = 0).
- Si hay esquemas, gráficos o dibujos, descríbelos en una línea con el formato [Figura: descripción breve].
- No añadas explicaciones, comentarios ni información que no aparezca en la imagen.
- Si no hay texto legible, responde exactamente: SIN_TEXTO`,
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: `Transcribe ${data.images.length > 1 ? "estas páginas" : "esta imagen"}.`,
            },
            ...data.images.map((dataUrl) => ({ type: "image" as const, dataUrl })),
          ],
        },
      ],
      maxOutputTokens: 8000,
      timeoutMs: 150_000,
    });
    const clean = text.trim() === "SIN_TEXTO" ? "" : text.trim();
    return { text: clean };
  });

/** Analyses a stored document: short summary + key concepts, saved on the row. */
export const analyzeDocument = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ documentId: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const { data: doc, error } = await supabase
      .from("documents")
      .select("id, title, content")
      .eq("id", data.documentId)
      .maybeSingle();
    if (error || !doc) throw new Error("No se ha encontrado el documento.");
    if (!doc.content.trim()) throw new Error("El documento no tiene texto que analizar.");

    const { getAI } = await import("@/lib/ai/index.server");
    const { GROUNDING_RULES, wrapMaterial } = await import("@/lib/study/prompts");
    const result = await getAI().generateJSON<{ summary: string; key_concepts: string[] }>({
      system: `Analizas apuntes de estudio.
${GROUNDING_RULES}
Devuelve:
- "summary": de qué trata el documento en 2-3 frases.
- "key_concepts": entre 4 y 12 conceptos clave del documento (2-6 palabras cada uno), en el orden en que aparecen.`,
      schemaName: "analisis_documento",
      schema: {
        type: "object",
        additionalProperties: false,
        properties: {
          summary: { type: "string" },
          key_concepts: { type: "array", items: { type: "string" } },
        },
        required: ["summary", "key_concepts"],
      },
      maxOutputTokens: 1200,
      timeoutMs: 90_000,
      messages: [
        {
          role: "user",
          content: `Documento «${doc.title}»:\n${wrapMaterial(doc.content.slice(0, 60_000))}\n\nAnalízalo y devuelve JSON.`,
        },
      ],
    });

    const keyConcepts = (result.key_concepts ?? [])
      .map((c) => c.trim())
      .filter(Boolean)
      .slice(0, 12);
    const { error: updateError } = await supabase
      .from("documents")
      .update({ summary: result.summary, key_concepts: keyConcepts })
      .eq("id", doc.id);
    if (updateError) throw new Error("No se ha podido guardar el análisis.");
    return { summary: result.summary, keyConcepts };
  });
