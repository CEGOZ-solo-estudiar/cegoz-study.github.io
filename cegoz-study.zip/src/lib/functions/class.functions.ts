import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const intentSchema = z.enum(["start", "answer", "doubt", "next", "simpler"]);
export type ClassIntent = z.infer<typeof intentSchema>;

const TUTOR_SCHEMA = {
  type: "object",
  additionalProperties: false,
  properties: {
    message: { type: "string" },
    awaiting_answer: { type: "boolean" },
    current_section: { type: "string" },
    assessed: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        properties: { concept: { type: "string" }, understood: { type: "boolean" } },
        required: ["concept", "understood"],
      },
    },
    finished: { type: "boolean" },
  },
  required: ["message", "awaiting_answer", "current_section", "assessed", "finished"],
};

type TutorReply = {
  message: string;
  awaiting_answer: boolean;
  current_section: string;
  assessed: { concept: string; understood: boolean }[];
  finished: boolean;
};

const FIXED_TEXT: Partial<Record<ClassIntent, string>> = {
  next: "Lo tengo claro, continúa con el siguiente apartado.",
  simpler: "No lo he entendido bien. ¿Me lo explicas de forma más sencilla?",
};

/** One turn of the virtual tutor. Stores the student's message and the tutor's reply. */
export const classTurn = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        sessionId: z.string().uuid(),
        intent: intentSchema,
        message: z.string().max(6000).optional(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: session } = await supabase
      .from("class_sessions")
      .select("id, topic_id, title")
      .eq("id", data.sessionId)
      .maybeSingle();
    if (!session) throw new Error("No se ha encontrado la clase.");

    const studentText =
      data.intent === "answer" || data.intent === "doubt"
        ? (data.message ?? "").trim()
        : (FIXED_TEXT[data.intent] ?? "");
    if ((data.intent === "answer" || data.intent === "doubt") && !studentText) {
      throw new Error("Escribe tu respuesta o tu duda antes de enviarla.");
    }

    const { loadTopicMaterial, loadWeakConcepts } = await import("@/lib/study/material");
    const { GROUNDING_RULES, levelDescription, wrapMaterial } = await import("@/lib/study/prompts");
    const [material, mastery, profileRes, historyRes] = await Promise.all([
      loadTopicMaterial(supabase, session.topic_id),
      loadWeakConcepts(supabase, session.topic_id),
      supabase.from("profiles").select("display_name, level").eq("id", userId).maybeSingle(),
      supabase
        .from("class_messages")
        .select("role, kind, content")
        .eq("session_id", session.id)
        .order("created_at", { ascending: false })
        .limit(40),
    ]);
    const history = (historyRes.data ?? []).reverse();
    if (data.intent === "start" && history.length > 0) {
      throw new Error("Esta clase ya ha empezado.");
    }

    // Persist the student's message first so it is never lost if the AI fails.
    if (studentText) {
      const { error } = await supabase.from("class_messages").insert({
        session_id: session.id,
        role: "user",
        kind: data.intent === "doubt" ? "doubt" : "message",
        content: studentText,
      });
      if (error) throw new Error("No se ha podido guardar tu mensaje.");
    }

    const name = profileRes.data?.display_name?.trim() || "el estudiante";
    const system = `Eres «Profe CEGOZ», un profesor particular paciente, cercano y exigente. Estás dando una clase individual a ${name} sobre el tema «${material.topicName}»${material.subjectName ? ` de la asignatura «${material.subjectName}»` : ""}.
Nivel del estudiante: ${levelDescription(profileRes.data?.level)}. Adapta vocabulario, ritmo y profundidad a ese nivel.

${GROUNDING_RULES}

CÓMO DAS LA CLASE:
1. Primera intervención: saluda brevemente, presenta en una lista corta los apartados del temario que vais a trabajar (en su orden) y empieza a explicar el primero.
2. Explica paso a paso y en fragmentos breves (máximo unas 180 palabras por intervención). Usa un ejemplo sencillo cuando ayude, indicando que es un ejemplo.
3. Termina cada explicación con UNA sola pregunta para comprobar la comprensión. Nunca hagas varias preguntas a la vez y nunca incluyas la respuesta a tu propia pregunta.
4. Cuando el estudiante responda: dile claramente si es correcto, corrige los errores explicando por qué y, si no lo ha entendido, explícalo de otra forma más sencilla y vuelve a preguntar sobre el mismo concepto. Si lo ha entendido, avanza.
5. Si el estudiante interrumpe con una DUDA, respóndela primero con el temario y después retoma la clase donde estaba, terminando con una pregunta.
6. Si pide una explicación más sencilla, usa palabras más simples, una analogía y un ejemplo cotidiano.
7. Cuando se hayan cubierto todos los apartados, haz un repaso final breve, indica qué debe reforzar y propón practicar o hacer un examen (marca "finished" = true).
${mastery.weak.length ? `8. Conceptos que el estudiante ha fallado antes y debes reforzar: ${mastery.weak.join("; ")}.` : ""}
${mastery.strong.length ? `   Conceptos que ya domina (no insistas en ellos): ${mastery.strong.join("; ")}.` : ""}

FORMATO DE SALIDA (JSON):
- "message": tu intervención en Markdown (negritas para términos clave, listas cuando ayuden).
- "awaiting_answer": true si terminas con una pregunta.
- "current_section": nombre del apartado del temario que estáis trabajando.
- "assessed": conceptos evaluados en la ÚLTIMA respuesta del estudiante a una pregunta tuya, con "understood" true/false. Vacío si no ha respondido a una pregunta.
- "finished": true solo si la clase ha terminado.

${wrapMaterial(material.text)}`;

    const messages = history.map((m) => ({
      role: m.role === "assistant" ? ("assistant" as const) : ("user" as const),
      content:
        m.role === "assistant" ? m.content : m.kind === "doubt" ? `[DUDA] ${m.content}` : m.content,
    }));
    if (data.intent === "start") {
      messages.push({ role: "user", content: "Hola, empecemos la clase." });
    } else {
      messages.push({
        role: "user",
        content:
          data.intent === "doubt" ? `[DUDA — interrumpo la clase] ${studentText}` : studentText,
      });
    }

    const { getAI } = await import("@/lib/ai/index.server");
    const reply = await getAI().generateJSON<TutorReply>({
      system,
      schemaName: "intervencion_profesor",
      schema: TUTOR_SCHEMA,
      messages,
      maxOutputTokens: 2500,
      timeoutMs: 90_000,
    });

    const { data: saved, error: saveError } = await supabase
      .from("class_messages")
      .insert({
        session_id: session.id,
        role: "assistant",
        kind: "message",
        content: reply.message,
      })
      .select("id, role, kind, content, created_at")
      .single();
    if (saveError) throw new Error("No se ha podido guardar la respuesta del profesor.");

    await supabase
      .from("class_sessions")
      .update({ progress_note: reply.current_section?.slice(0, 200) || null })
      .eq("id", session.id);

    for (const a of reply.assessed ?? []) {
      await supabase.rpc("record_concept_result", {
        _topic_id: session.topic_id,
        _concept: a.concept,
        _correct: a.understood,
      });
    }

    if (data.intent === "start") {
      await supabase.from("study_activity").insert({
        topic_id: session.topic_id,
        kind: "clase",
        title: `Clase: ${material.topicName}`,
        details: { session_id: session.id },
      });
    }

    return {
      reply: saved,
      awaitingAnswer: reply.awaiting_answer,
      currentSection: reply.current_section,
      finished: reply.finished,
    };
  });
