import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { Difficulty, QuestionType } from "@/lib/study/grading";

const MODE_TYPES: Record<"test" | "rapida" | "ejercicio" | "mixta", QuestionType[]> = {
  test: ["test"],
  rapida: ["rapida"],
  ejercicio: ["practico", "desarrollo"],
  mixta: ["test", "rapida", "practico"],
};

export type PracticeQuestion = {
  id: string;
  qtype: string;
  difficulty: string;
  prompt: string;
  options: string[] | null;
  concept: string | null;
};

/** Generates a batch of practice questions (adaptive difficulty optional). */
export const generatePractice = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        topicId: z.string().uuid(),
        mode: z.enum(["test", "rapida", "ejercicio", "mixta"]),
        difficulty: z.enum(["facil", "media", "dificil", "adaptativa"]),
        count: z.number().int().min(1).max(10),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { loadTopicMaterial, loadWeakConcepts } = await import("@/lib/study/material");
    const { adaptDifficulty } = await import("@/lib/study/grading");
    const [material, mastery, profile, recent] = await Promise.all([
      loadTopicMaterial(supabase, data.topicId),
      loadWeakConcepts(supabase, data.topicId),
      supabase.from("profiles").select("level").eq("id", userId).maybeSingle(),
      supabase
        .from("questions")
        .select("prompt, is_correct, difficulty, answered_at")
        .eq("topic_id", data.topicId)
        .eq("source", "practica")
        .order("created_at", { ascending: false })
        .limit(30),
    ]);

    let difficulty: Difficulty;
    if (data.difficulty === "adaptativa") {
      const answered = (recent.data ?? []).filter((q) => q.answered_at).slice(0, 8);
      const current = (answered[0]?.difficulty as Difficulty | undefined) ?? "media";
      difficulty = adaptDifficulty(
        answered.map((q) => q.is_correct === true),
        current,
      );
    } else {
      difficulty = data.difficulty;
    }

    const { getAI } = await import("@/lib/ai/index.server");
    const { generateQuestions } = await import("@/lib/study/questions.server");
    const questions = await generateQuestions(getAI(), {
      material: material.text,
      topicName: material.topicName,
      count: data.count,
      difficulty,
      types: MODE_TYPES[data.mode],
      level: profile.data?.level ?? "intermedio",
      weakConcepts: mastery.weak,
      avoidPrompts: (recent.data ?? []).map((q) => q.prompt),
      purpose: "practica",
    });

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: rows, error } = await supabaseAdmin
      .from("questions")
      .insert(
        questions.map((q, i) => ({
          user_id: userId,
          topic_id: data.topicId,
          source: "practica",
          position: i,
          qtype: q.qtype,
          difficulty,
          prompt: q.prompt,
          options: q.qtype === "test" ? q.options : null,
          concept: q.concept,
        })),
      )
      .select("id, position, qtype, difficulty, prompt, options, concept");
    if (error || !rows) throw new Error("No se han podido guardar las preguntas.");
    const byPos = new Map(rows.map((r) => [r.position, r.id]));
    const { error: kError } = await supabaseAdmin.from("question_keys").insert(
      questions.map((q, i) => ({
        question_id: byPos.get(i)!,
        correct_answer: q.qtype === "test" ? String(q.correct_option) : q.model_answer,
        explanation: q.explanation,
        rubric: q.rubric,
      })),
    );
    if (kError) throw new Error("No se han podido guardar las soluciones.");

    await supabase.from("study_activity").insert({
      topic_id: data.topicId,
      kind: "practica",
      title: `Práctica: ${material.topicName}`,
      details: { count: rows.length, difficulty, mode: data.mode },
    });

    return {
      difficulty,
      questions: rows
        .sort((a, b) => a.position - b.position)
        .map((r) => ({
          ...r,
          options: (r.options as string[] | null) ?? null,
        })) as PracticeQuestion[],
    };
  });

/** Grades one practice answer immediately and reveals the explanation. */
export const answerPractice = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ questionId: z.string().uuid(), answer: z.string().min(1).max(8000) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: q } = await supabaseAdmin
      .from("questions")
      .select(
        "id, topic_id, qtype, prompt, concept, answered_at, question_keys(correct_answer, explanation, rubric)",
      )
      .eq("id", data.questionId)
      .eq("user_id", userId)
      .eq("source", "practica")
      .maybeSingle();
    if (!q) throw new Error("Pregunta no encontrada.");
    if (q.answered_at) throw new Error("Ya has respondido a esta pregunta.");
    const key = (Array.isArray(q.question_keys) ? q.question_keys[0] : q.question_keys) as {
      correct_answer: string;
      explanation: string;
      rubric: string | null;
    };

    const { isChoiceCorrect, normalizeAnswer, PASS_THRESHOLD } =
      await import("@/lib/study/grading");
    let score: number;
    let feedback: string;
    if (q.qtype === "test") {
      const ok = isChoiceCorrect(key.correct_answer, data.answer);
      score = ok ? 1 : 0;
      feedback = ok ? "¡Correcto!" : "No es la opción correcta.";
    } else if (
      q.qtype === "rapida" &&
      normalizeAnswer(data.answer) === normalizeAnswer(key.correct_answer)
    ) {
      score = 1;
      feedback = "¡Correcto!";
    } else {
      const { gradeOpenAnswers } = await import("@/lib/study/questions.server");
      const { getAI } = await import("@/lib/ai/index.server");
      const profile = await supabase
        .from("profiles")
        .select("level")
        .eq("id", userId)
        .maybeSingle();
      const graded = await gradeOpenAnswers(
        getAI(),
        [
          {
            id: q.id,
            qtype: q.qtype,
            prompt: q.prompt,
            model_answer: key.correct_answer,
            rubric: key.rubric ?? "",
            answer: data.answer,
          },
        ],
        profile.data?.level ?? "intermedio",
      );
      const g = graded.results.get(q.id) ?? [...graded.results.values()][0];
      score = g?.score ?? 0;
      feedback = g?.feedback ?? "No se ha podido corregir la respuesta.";
    }
    const isCorrect = score >= PASS_THRESHOLD;
    await supabaseAdmin
      .from("questions")
      .update({
        user_answer: data.answer,
        answered_at: new Date().toISOString(),
        score,
        is_correct: isCorrect,
        feedback,
      })
      .eq("id", q.id);
    if (q.concept) {
      await supabase.rpc("record_concept_result", {
        _topic_id: q.topic_id,
        _concept: q.concept,
        _correct: isCorrect,
      });
    }
    return {
      isCorrect,
      score,
      feedback,
      correctAnswer: key.correct_answer,
      explanation: key.explanation,
    };
  });

/** Creates fresh copies of recently failed practice questions so they can be answered again. */
export const retryFailedPractice = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ topicId: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { userId } = context;
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: failed } = await supabaseAdmin
      .from("questions")
      .select(
        "id, retry_of, qtype, difficulty, prompt, options, concept, question_keys(correct_answer, explanation, rubric)",
      )
      .eq("user_id", userId)
      .eq("topic_id", data.topicId)
      .in("source", ["practica", "examen"])
      .eq("is_correct", false)
      .order("answered_at", { ascending: false })
      .limit(30);
    const { data: retried } = await supabaseAdmin
      .from("questions")
      .select("retry_of, is_correct")
      .eq("user_id", userId)
      .eq("topic_id", data.topicId)
      .not("retry_of", "is", null);
    const solved = new Set((retried ?? []).filter((r) => r.is_correct).map((r) => r.retry_of));
    const seen = new Set<string>();
    const pending = (failed ?? [])
      .filter((q) => {
        const origin = q.retry_of ?? q.id;
        if (solved.has(origin) || seen.has(origin)) return false;
        seen.add(origin);
        return true;
      })
      .slice(0, 10);
    if (pending.length === 0) return { questions: [] as PracticeQuestion[] };

    const { data: rows, error } = await supabaseAdmin
      .from("questions")
      .insert(
        pending.map((q, i) => ({
          user_id: userId,
          topic_id: data.topicId,
          source: "practica",
          position: i,
          qtype: q.qtype,
          difficulty: q.difficulty,
          prompt: q.prompt,
          options: q.options,
          concept: q.concept,
          retry_of: q.retry_of ?? q.id,
        })),
      )
      .select("id, position, qtype, difficulty, prompt, options, concept");
    if (error || !rows) throw new Error("No se han podido preparar las preguntas falladas.");
    const byPos = new Map(rows.map((r) => [r.position, r.id]));
    await supabaseAdmin.from("question_keys").insert(
      pending.map((q, i) => {
        const key = (Array.isArray(q.question_keys) ? q.question_keys[0] : q.question_keys) as {
          correct_answer: string;
          explanation: string;
          rubric: string | null;
        };
        return {
          question_id: byPos.get(i)!,
          correct_answer: key.correct_answer,
          explanation: key.explanation,
          rubric: key.rubric,
        };
      }),
    );
    return {
      questions: rows
        .sort((a, b) => a.position - b.position)
        .map((r) => ({
          ...r,
          options: (r.options as string[] | null) ?? null,
        })) as PracticeQuestion[],
    };
  });
