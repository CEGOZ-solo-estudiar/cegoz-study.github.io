import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { EXAM_MAX_QUESTIONS, EXAM_MIN_QUESTIONS } from "@/lib/study/grading";

const difficulty = z.enum(["facil", "media", "dificil"]);
const qtype = z.enum(["test", "desarrollo", "practico"]);

/** Creates an exam with AI-generated questions. Solutions are stored apart and never sent before grading. */
export const createExam = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        topicId: z.string().uuid(),
        difficulty,
        count: z.number().int().min(EXAM_MIN_QUESTIONS).max(EXAM_MAX_QUESTIONS),
        types: z.array(qtype).min(1),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { loadTopicMaterial, loadWeakConcepts } = await import("@/lib/study/material");
    const [material, mastery, profile, previous] = await Promise.all([
      loadTopicMaterial(supabase, data.topicId),
      loadWeakConcepts(supabase, data.topicId),
      supabase.from("profiles").select("level").eq("id", userId).maybeSingle(),
      supabase
        .from("questions")
        .select("prompt")
        .eq("topic_id", data.topicId)
        .eq("source", "examen")
        .order("created_at", { ascending: false })
        .limit(40),
    ]);

    const { getAI } = await import("@/lib/ai/index.server");
    const { generateQuestions } = await import("@/lib/study/questions.server");
    const questions = await generateQuestions(getAI(), {
      material: material.text,
      topicName: material.topicName,
      count: data.count,
      difficulty: data.difficulty,
      types: data.types,
      level: profile.data?.level ?? "intermedio",
      weakConcepts: mastery.weak,
      avoidPrompts: (previous.data ?? []).map((q) => q.prompt),
      purpose: "examen",
    });

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: exam, error } = await supabaseAdmin
      .from("exams")
      .insert({
        user_id: userId,
        topic_id: data.topicId,
        difficulty: data.difficulty,
        question_count: questions.length,
        question_types: data.types,
      })
      .select("id")
      .single();
    if (error || !exam) throw new Error("No se ha podido crear el examen.");

    const { data: rows, error: qError } = await supabaseAdmin
      .from("questions")
      .insert(
        questions.map((q, i) => ({
          user_id: userId,
          topic_id: data.topicId,
          exam_id: exam.id,
          source: "examen",
          position: i,
          qtype: q.qtype,
          difficulty: data.difficulty,
          prompt: q.prompt,
          options: q.qtype === "test" ? q.options : null,
          concept: q.concept,
        })),
      )
      .select("id, position");
    if (qError || !rows) {
      await supabaseAdmin.from("exams").delete().eq("id", exam.id);
      throw new Error("No se han podido guardar las preguntas del examen.");
    }
    const byPos = new Map(rows.map((r) => [r.position, r.id]));
    const { error: kError } = await supabaseAdmin.from("question_keys").insert(
      questions.map((q, i) => ({
        question_id: byPos.get(i)!,
        correct_answer: q.qtype === "test" ? String(q.correct_option) : q.model_answer,
        explanation: q.explanation,
        rubric: q.rubric,
      })),
    );
    if (kError) {
      await supabaseAdmin.from("exams").delete().eq("id", exam.id);
      throw new Error("No se han podido guardar las soluciones del examen.");
    }
    return { examId: exam.id };
  });

/** Saves (or changes) the student's answer to one exam question. */
export const saveExamAnswer = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ questionId: z.string().uuid(), answer: z.string().max(8000) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    // RLS: the student can only read their own questions.
    const { data: q } = await supabase
      .from("questions")
      .select("id, exam_id, exams(status)")
      .eq("id", data.questionId)
      .maybeSingle();
    const exam = q?.exams as unknown as { status: string } | null;
    if (!q || !q.exam_id) throw new Error("Pregunta no encontrada.");
    if (exam?.status !== "en_curso") throw new Error("Este examen ya se ha corregido.");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("questions")
      .update({ user_answer: data.answer, answered_at: new Date().toISOString() })
      .eq("id", q.id);
    if (error) throw new Error("No se ha podido guardar tu respuesta.");
    return { ok: true };
  });

/** Grades the whole exam: test questions directly, open answers with the AI. */
export const finishExam = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ examId: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: exam } = await supabase
      .from("exams")
      .select("id, status, topic_id, topics(name)")
      .eq("id", data.examId)
      .maybeSingle();
    if (!exam) throw new Error("Examen no encontrado.");
    if (exam.status === "completado") return { examId: exam.id };

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: questions } = await supabaseAdmin
      .from("questions")
      .select(
        "id, qtype, prompt, concept, user_answer, question_keys(correct_answer, explanation, rubric)",
      )
      .eq("exam_id", exam.id)
      .eq("user_id", userId)
      .order("position");
    if (!questions?.length) throw new Error("El examen no tiene preguntas.");

    const { isChoiceCorrect, examGrade, PASS_THRESHOLD } = await import("@/lib/study/grading");
    const { gradeOpenAnswers } = await import("@/lib/study/questions.server");
    const { getAI } = await import("@/lib/ai/index.server");
    const profile = await supabase.from("profiles").select("level").eq("id", userId).maybeSingle();

    const keyOf = (q: (typeof questions)[number]) =>
      (Array.isArray(q.question_keys) ? q.question_keys[0] : q.question_keys) as {
        correct_answer: string;
        explanation: string;
        rubric: string | null;
      };

    const open = questions.filter((q) => q.qtype !== "test" && (q.user_answer ?? "").trim());
    const graded = await gradeOpenAnswers(
      getAI(),
      open.map((q) => ({
        id: q.id,
        qtype: q.qtype,
        prompt: q.prompt,
        model_answer: keyOf(q).correct_answer,
        rubric: keyOf(q).rubric ?? "",
        answer: q.user_answer ?? "",
      })),
      profile.data?.level ?? "intermedio",
    );

    const scores: number[] = [];
    for (const q of questions) {
      const key = keyOf(q);
      let score = 0;
      let feedback: string;
      if (!(q.user_answer ?? "").trim()) {
        feedback = "No has respondido a esta pregunta.";
      } else if (q.qtype === "test") {
        const ok = isChoiceCorrect(key.correct_answer, q.user_answer);
        score = ok ? 1 : 0;
        feedback = ok ? "¡Correcto!" : "Respuesta incorrecta.";
      } else {
        const g = graded.results.get(q.id);
        score = g?.score ?? 0;
        feedback = g?.feedback ?? "No se ha podido corregir esta respuesta.";
      }
      scores.push(score);
      await supabaseAdmin
        .from("questions")
        .update({ score, is_correct: score >= PASS_THRESHOLD, feedback })
        .eq("id", q.id);
      if (q.concept) {
        await supabase.rpc("record_concept_result", {
          _topic_id: exam.topic_id,
          _concept: q.concept,
          _correct: score >= PASS_THRESHOLD,
        });
      }
    }

    const grade = examGrade(scores, questions.length);
    const failedConcepts = questions
      .filter((_, i) => (scores[i] ?? 0) < PASS_THRESHOLD)
      .map((q) => q.concept)
      .filter(Boolean);
    const overall =
      graded.overall ||
      (failedConcepts.length
        ? `Repasa estos conceptos: ${[...new Set(failedConcepts)].join(", ")}.`
        : "¡Excelente! Has respondido correctamente a todas las preguntas.");

    await supabaseAdmin
      .from("exams")
      .update({
        status: "completado",
        score: grade,
        feedback: overall,
        completed_at: new Date().toISOString(),
      })
      .eq("id", exam.id);

    const topic = exam.topics as unknown as { name: string } | null;
    await supabase.from("study_activity").insert({
      topic_id: exam.topic_id,
      kind: "examen",
      title: `Examen: ${topic?.name ?? "tema"}`,
      score: grade,
      details: { exam_id: exam.id },
    });
    return { examId: exam.id, grade };
  });

/** Returns solutions and explanations — only once the exam has been graded. */
export const getExamResults = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ examId: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: exam } = await supabase
      .from("exams")
      .select(
        "id, status, score, feedback, difficulty, question_count, question_types, topic_id, completed_at, topics(name)",
      )
      .eq("id", data.examId)
      .maybeSingle();
    if (!exam) throw new Error("Examen no encontrado.");
    if (exam.status !== "completado") throw new Error("El examen todavía no se ha corregido.");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: questions } = await supabaseAdmin
      .from("questions")
      .select(
        "id, position, qtype, prompt, options, concept, user_answer, is_correct, score, feedback, question_keys(correct_answer, explanation)",
      )
      .eq("exam_id", exam.id)
      .eq("user_id", userId)
      .order("position");
    const topic = exam.topics as unknown as { name: string } | null;
    return {
      exam: { ...exam, topicName: topic?.name ?? "" },
      questions: (questions ?? []).map((q) => {
        const key = (Array.isArray(q.question_keys) ? q.question_keys[0] : q.question_keys) as {
          correct_answer: string;
          explanation: string;
        } | null;
        return {
          id: q.id,
          position: q.position,
          qtype: q.qtype,
          prompt: q.prompt,
          options: (q.options as string[] | null) ?? null,
          concept: q.concept,
          userAnswer: q.user_answer,
          isCorrect: q.is_correct,
          score: q.score == null ? 0 : Number(q.score),
          feedback: q.feedback,
          correctAnswer: key?.correct_answer ?? "",
          explanation: key?.explanation ?? "",
        };
      }),
    };
  });
