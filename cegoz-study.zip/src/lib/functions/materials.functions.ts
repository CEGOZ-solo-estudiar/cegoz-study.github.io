import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { MATERIAL_KINDS, type MaterialKind } from "@/lib/study/materials";

const kindSchema = z.enum(Object.keys(MATERIAL_KINDS) as [MaterialKind, ...MaterialKind[]]);

const MARKDOWN_INSTRUCTIONS: Partial<Record<MaterialKind, string>> = {
  resumen:
    "Redacta un RESUMEN COMPLETO del temario, organizado con títulos (##) por apartados, que conserve todas las ideas importantes, datos y relaciones. Usa negritas para los términos clave.",
  esquema:
    "Crea un ESQUEMA jerárquico del temario usando listas anidadas en Markdown (títulos ## para los bloques principales y viñetas anidadas para las ideas). Frases muy breves.",
  conceptos:
    "Explica los CONCEPTOS ESENCIALES del temario: para cada uno, un título ### y 2-4 frases claras sobre qué es y por qué es importante.",
};

const ITEM_INSTRUCTIONS: Partial<Record<MaterialKind, { prompt: string; a: string; b: string }>> = {
  definiciones: {
    prompt:
      "Extrae las DEFINICIONES de los términos del temario (entre 8 y 30). Usa las definiciones tal y como aparecen o muy fieles al texto.",
    a: "término",
    b: "definición",
  },
  tarjetas: {
    prompt:
      "Crea entre 10 y 30 TARJETAS DE MEMORIA (flashcards). Anverso: una pregunta o término breve. Reverso: respuesta concisa (máx. 40 palabras).",
    a: "anverso",
    b: "reverso",
  },
  preguntas_repaso: {
    prompt:
      "Crea entre 8 y 20 PREGUNTAS DE REPASO abiertas que cubran todo el temario, con su respuesta modelo breve.",
    a: "pregunta",
    b: "respuesta",
  },
  lista_conceptos: {
    prompt:
      "Haz una LISTA DE CONCEPTOS IMPORTANTES (entre 8 y 30), cada uno con una nota de una frase sobre su papel en el temario. En 'c' indica la importancia: 'alta' o 'media'.",
    a: "concepto",
    b: "nota",
  },
};

export type MaterialItem = { a: string; b: string; c: string };

export const generateMaterial = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ topicId: z.string().uuid(), kind: kindSchema }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { loadTopicMaterial } = await import("@/lib/study/material");
    const { GROUNDING_RULES, levelDescription, wrapMaterial } = await import("@/lib/study/prompts");
    const [material, profile] = await Promise.all([
      loadTopicMaterial(supabase, data.topicId),
      supabase.from("profiles").select("level").eq("id", userId).maybeSingle(),
    ]);
    const { getAI } = await import("@/lib/ai/index.server");
    const ai = getAI();
    const label = MATERIAL_KINDS[data.kind].label;
    const baseSystem = `Eres un profesor que prepara material de estudio a partir de los apuntes de un estudiante (nivel: ${levelDescription(profile.data?.level)}).
${GROUNDING_RULES}
Tema: «${material.topicName}».`;

    let content = "";
    let items: MaterialItem[] | null = null;

    const md = MARKDOWN_INSTRUCTIONS[data.kind];
    if (md) {
      content = await ai.generateText({
        system: `${baseSystem}\n${md}\nDevuelve solo el Markdown, sin introducciones ni despedidas.`,
        messages: [{ role: "user", content: wrapMaterial(material.text) }],
        maxOutputTokens: data.kind === "resumen" ? 7000 : 4500,
        timeoutMs: 150_000,
      });
    } else {
      const spec = ITEM_INSTRUCTIONS[data.kind]!;
      const out = await ai.generateJSON<{ items: MaterialItem[] }>({
        system: `${baseSystem}\n${spec.prompt}\nCampos: "a" = ${spec.a}, "b" = ${spec.b}, "c" = concepto relacionado (2-6 palabras)${data.kind === "lista_conceptos" ? " o la importancia" : ""}.`,
        schemaName: "material",
        schema: {
          type: "object",
          additionalProperties: false,
          properties: {
            items: {
              type: "array",
              items: {
                type: "object",
                additionalProperties: false,
                properties: { a: { type: "string" }, b: { type: "string" }, c: { type: "string" } },
                required: ["a", "b", "c"],
              },
            },
          },
          required: ["items"],
        },
        messages: [{ role: "user", content: `${wrapMaterial(material.text)}\n\nDevuelve JSON.` }],
        maxOutputTokens: 7000,
        timeoutMs: 150_000,
      });
      items = (out.items ?? []).filter((i) => i.a?.trim() && i.b?.trim());
      if (items.length === 0)
        throw new Error("La IA no ha podido generar este material. Inténtalo de nuevo.");
      content = items.map((i) => `- **${i.a}**: ${i.b}`).join("\n");
    }

    const { data: saved, error } = await supabase
      .from("study_materials")
      .insert({
        topic_id: data.topicId,
        kind: data.kind,
        title: `${label} · ${material.topicName}`,
        content,
        data: items,
      })
      .select("id")
      .single();
    if (error || !saved) throw new Error("No se ha podido guardar el material.");

    await supabase.from("study_activity").insert({
      topic_id: data.topicId,
      kind: data.kind === "tarjetas" ? "tarjetas" : "resumen",
      title: `${label}: ${material.topicName}`,
      details: { material_id: saved.id },
    });
    return { materialId: saved.id };
  });
