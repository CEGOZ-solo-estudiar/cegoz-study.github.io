import { z } from "zod";

/** Optional preselected topic shared by the study modes (?tema=<uuid>). */
export const topicSearchSchema = z.object({ tema: z.string().uuid().optional().catch(undefined) });
