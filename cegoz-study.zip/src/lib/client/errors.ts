import { toast } from "sonner";

export function errorMessage(error: unknown): string {
  if (error instanceof Error && error.message) {
    if (/Unauthorized/i.test(error.message))
      return "Tu sesión ha caducado. Vuelve a iniciar sesión.";
    if (/Failed to fetch|NetworkError/i.test(error.message))
      return "No hay conexión con el servidor. Comprueba tu conexión a internet.";
    return error.message;
  }
  return "Ha ocurrido un error inesperado. Inténtalo de nuevo.";
}

export function toastError(error: unknown) {
  toast.error(errorMessage(error));
}
