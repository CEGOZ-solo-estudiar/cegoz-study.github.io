import { supabase } from "@/integrations/supabase/client";
import type { SourceKind } from "@/lib/files/extract";

const BUCKET = "temarios";

function safeName(name: string) {
  return name
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-zA-Z0-9._-]+/g, "_")
    .slice(-120);
}

async function currentUserId(): Promise<string> {
  const { data } = await supabase.auth.getUser();
  if (!data.user) throw new Error("Tu sesión ha caducado. Vuelve a iniciar sesión.");
  return data.user.id;
}

async function uploadOriginal(userId: string, documentId: string, file: File): Promise<string> {
  const path = `${userId}/${documentId}/${Date.now()}-${safeName(file.name)}`;
  const { error } = await supabase.storage.from(BUCKET).upload(path, file, {
    contentType: file.type || undefined,
    upsert: false,
  });
  if (error) throw new Error(`No se ha podido guardar el archivo «${file.name}».`);
  return path;
}

export type NewDocument = {
  topicId: string;
  title: string;
  kind: SourceKind | "pasted";
  text: string;
  file?: File;
};

export async function saveDocument(doc: NewDocument): Promise<string> {
  const userId = await currentUserId();
  const { data, error } = await supabase
    .from("documents")
    .insert({
      topic_id: doc.topicId,
      title: doc.title.slice(0, 200),
      source_type: doc.kind,
      mime_type: doc.file?.type || (doc.kind === "pasted" ? "text/plain" : null),
      size_bytes: doc.file?.size ?? new Blob([doc.text]).size,
      content: doc.text,
      char_count: doc.text.length,
    })
    .select("id")
    .single();
  if (error || !data) throw new Error("No se ha podido guardar el documento.");
  if (doc.file) {
    try {
      const path = await uploadOriginal(userId, data.id, doc.file);
      await supabase.from("documents").update({ storage_path: path }).eq("id", data.id);
    } catch (e) {
      // Keep the extracted text even if the original file could not be stored.
      console.error(e);
    }
  }
  return data.id;
}

export async function replaceDocument(
  existing: { id: string; storage_path: string | null },
  next: Omit<NewDocument, "topicId">,
): Promise<void> {
  const userId = await currentUserId();
  let storagePath: string | null = null;
  if (next.file) storagePath = await uploadOriginal(userId, existing.id, next.file);
  const { error } = await supabase
    .from("documents")
    .update({
      title: next.title.slice(0, 200),
      source_type: next.kind,
      mime_type: next.file?.type || (next.kind === "pasted" ? "text/plain" : null),
      size_bytes: next.file?.size ?? new Blob([next.text]).size,
      content: next.text,
      char_count: next.text.length,
      storage_path: storagePath,
      summary: null,
      key_concepts: [],
    })
    .eq("id", existing.id);
  if (error) throw new Error("No se ha podido sustituir el documento.");
  if (existing.storage_path) await supabase.storage.from(BUCKET).remove([existing.storage_path]);
}

export async function deleteDocument(doc: { id: string; storage_path: string | null }) {
  if (doc.storage_path) await supabase.storage.from(BUCKET).remove([doc.storage_path]);
  const { error } = await supabase.from("documents").delete().eq("id", doc.id);
  if (error) throw new Error("No se ha podido eliminar el documento.");
}

export async function openOriginal(storagePath: string) {
  const { data, error } = await supabase.storage.from(BUCKET).createSignedUrl(storagePath, 120);
  if (error || !data) throw new Error("No se ha podido abrir el archivo original.");
  window.open(data.signedUrl, "_blank", "noopener");
}

/** Deletes stored files for every document of the given topics (rows cascade in the database). */
export async function removeTopicFiles(topicIds: string[]) {
  if (topicIds.length === 0) return;
  const { data } = await supabase.from("documents").select("storage_path").in("topic_id", topicIds);
  const paths = (data ?? []).map((d) => d.storage_path).filter((p): p is string => !!p);
  if (paths.length) await supabase.storage.from(BUCKET).remove(paths);
}
