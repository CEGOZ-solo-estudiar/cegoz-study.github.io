import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

function check<T>(res: { data: T; error: { message: string } | null }, what: string): T {
  if (res.error) throw new Error(`No se ha podido cargar ${what}.`);
  return res.data;
}

function checkList<T>(
  res: { data: T[] | null; error: { message: string } | null },
  what: string,
): T[] {
  if (res.error) throw new Error(`No se ha podido cargar ${what}.`);
  return res.data ?? [];
}

export const userQuery = queryOptions({
  queryKey: ["user"],
  queryFn: async () => {
    const { data } = await supabase.auth.getUser();
    return data.user;
  },
  staleTime: 60_000,
});

export const profileQuery = queryOptions({
  queryKey: ["profile"],
  queryFn: async () => {
    const { data: auth } = await supabase.auth.getUser();
    if (!auth.user) return null;
    return check(
      await supabase
        .from("profiles")
        .select("id, display_name, level")
        .eq("id", auth.user.id)
        .maybeSingle(),
      "tu perfil",
    );
  },
});

export type LibrarySubject = {
  id: string;
  name: string;
  color: string;
  created_at: string;
  topics: { id: string; name: string; created_at: string; documents: { count: number }[] }[];
};

export const libraryQuery = queryOptions({
  queryKey: ["library"],
  queryFn: async () =>
    check(
      await supabase
        .from("subjects")
        .select("id, name, color, created_at, topics(id, name, created_at, documents(count))")
        .order("created_at", { ascending: true })
        .order("created_at", { referencedTable: "topics", ascending: true }),
      "tus temarios",
    ) as unknown as LibrarySubject[],
});

export const topicQuery = (topicId: string) =>
  queryOptions({
    queryKey: ["topic", topicId],
    queryFn: async () => {
      const topic = check(
        await supabase
          .from("topics")
          .select("id, name, subject_id, subjects(id, name)")
          .eq("id", topicId)
          .maybeSingle(),
        "el tema",
      );
      if (!topic) throw new Error("Este tema no existe o no tienes acceso.");
      const documents = checkList(
        await supabase
          .from("documents")
          .select(
            "id, title, source_type, storage_path, mime_type, size_bytes, char_count, summary, key_concepts, created_at, updated_at",
          )
          .eq("topic_id", topicId)
          .order("created_at", { ascending: true }),
        "los documentos",
      );
      return {
        topic: topic as typeof topic & { subjects: { id: string; name: string } | null },
        documents,
      };
    },
  });

export const documentContentQuery = (documentId: string) =>
  queryOptions({
    queryKey: ["document-content", documentId],
    queryFn: async () =>
      check(
        await supabase.from("documents").select("id, content").eq("id", documentId).single(),
        "el documento",
      ),
  });

export const classSessionsQuery = queryOptions({
  queryKey: ["class-sessions"],
  queryFn: async () =>
    checkList(
      await supabase
        .from("class_sessions")
        .select("id, title, progress_note, created_at, updated_at, topic_id, topics(name)")
        .order("updated_at", { ascending: false })
        .limit(30),
      "tus clases",
    ),
});

export const classSessionQuery = (sessionId: string) =>
  queryOptions({
    queryKey: ["class-session", sessionId],
    queryFn: async () => {
      const session = check(
        await supabase
          .from("class_sessions")
          .select("id, title, progress_note, topic_id, topics(name, subjects(name))")
          .eq("id", sessionId)
          .maybeSingle(),
        "la clase",
      );
      if (!session) throw new Error("Esta clase no existe.");
      const messages = checkList(
        await supabase
          .from("class_messages")
          .select("id, role, kind, content, created_at")
          .eq("session_id", sessionId)
          .order("created_at", { ascending: true }),
        "los mensajes",
      );
      return { session, messages };
    },
  });

export const examsQuery = queryOptions({
  queryKey: ["exams"],
  queryFn: async () =>
    checkList(
      await supabase
        .from("exams")
        .select(
          "id, status, score, difficulty, question_count, question_types, topic_id, created_at, completed_at, topics(name)",
        )
        .order("created_at", { ascending: false })
        .limit(50),
      "tus exámenes",
    ),
});

export const examQuery = (examId: string) =>
  queryOptions({
    queryKey: ["exam", examId],
    queryFn: async () => {
      const exam = check(
        await supabase
          .from("exams")
          .select(
            "id, status, score, difficulty, question_count, question_types, topic_id, created_at, topics(name)",
          )
          .eq("id", examId)
          .maybeSingle(),
        "el examen",
      );
      if (!exam) throw new Error("Este examen no existe.");
      const questions = checkList(
        await supabase
          .from("questions")
          .select("id, position, qtype, prompt, options, concept, user_answer")
          .eq("exam_id", examId)
          .order("position"),
        "las preguntas",
      );
      return { exam, questions };
    },
  });

export const materialsQuery = queryOptions({
  queryKey: ["materials"],
  queryFn: async () =>
    checkList(
      await supabase
        .from("study_materials")
        .select("id, kind, title, created_at, topic_id, topics(name)")
        .order("created_at", { ascending: false })
        .limit(100),
      "tus materiales",
    ),
});

export const materialQuery = (materialId: string) =>
  queryOptions({
    queryKey: ["material", materialId],
    queryFn: async () => {
      const m = check(
        await supabase
          .from("study_materials")
          .select("id, kind, title, content, data, created_at, topic_id, topics(name)")
          .eq("id", materialId)
          .maybeSingle(),
        "el material",
      );
      if (!m) throw new Error("Este material no existe.");
      return m;
    },
  });

export const progressQuery = queryOptions({
  queryKey: ["progress"],
  queryFn: async () => {
    const [activity, mastery, exams, practice] = await Promise.all([
      supabase
        .from("study_activity")
        .select("id, kind, title, score, created_at, topic_id, details")
        .order("created_at", { ascending: false })
        .limit(200),
      supabase
        .from("concept_mastery")
        .select("id, concept, correct_count, incorrect_count, last_seen_at, topic_id, topics(name)")
        .order("last_seen_at", { ascending: false })
        .limit(300),
      supabase
        .from("exams")
        .select("id, score, completed_at, created_at, topic_id, topics(name)")
        .eq("status", "completado")
        .order("completed_at", { ascending: true })
        .limit(100),
      supabase
        .from("questions")
        .select("id, is_correct, answered_at")
        .eq("source", "practica")
        .not("answered_at", "is", null)
        .order("answered_at", { ascending: false })
        .limit(500),
    ]);
    return {
      activity: checkList(activity, "tu actividad"),
      mastery: checkList(mastery, "tus conceptos"),
      exams: checkList(exams, "tus exámenes"),
      practice: checkList(practice, "tu práctica"),
    };
  },
});
