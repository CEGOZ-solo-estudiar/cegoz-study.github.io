# CEGOZ Study — Roadmap

- [x] Diseño (blanco/azul/violeta), barra lateral y navegación móvil
- [x] Cuentas: registro (con confirmación de correo), inicio/cierre de sesión, recuperación de contraseña
- [x] Temarios: asignaturas, temas, subida de PDF/imagen/Word/texto, extracción, eliminar/sustituir
- [x] Capa de IA en servidor intercambiable (gestión de errores y límites)
- [x] Modo clase (profesor virtual)
- [x] Modo examen (generación, una pregunta cada vez, corrección, nota /10, repetir)
- [x] Modo práctica (corrección inmediata, repetir falladas, dificultad adaptable)
- [x] Resúmenes, esquemas, conceptos, definiciones, tarjetas, preguntas de repaso
- [x] Progreso e historial
- [x] Inicio: bienvenida, accesos a Temarios/Clase/Examen/Práctica y tarjeta de progreso
- [x] Pantallas privadas verificadas: Inicio, Temarios, tema, Clase, Examen, Práctica, Resúmenes, Progreso, Perfil (sin errores de consola, también en móvil)
- [x] Flujo real verificado: pegar apuntes → análisis → resumen; examen de 6 preguntas → corrección con nota /10; clase con preguntas y corrección; práctica con corrección inmediata; progreso e historial actualizados
- [x] Registro verificado: la cuenta se crea y, mientras no confirme, el acceso avisa «Todavía no has confirmado tu correo»
- [x] Publicación solicitada: la app se publicó en https://your-notes-wise-guide.lovable.app y la URL responde 200
- [ ] Abrir el enlace de confirmación y iniciar sesión después: ya se puede probar en la URL publicada (antes el enlace apuntaba al origen de la preview y no era comprobable desde este entorno)
- [ ] Probar con los apuntes reales del usuario: hasta ahora las pruebas se hicieron con material de ejemplo
