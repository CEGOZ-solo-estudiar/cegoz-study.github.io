-- ============================================================================
-- CEGOZ Study — esquema de la base de datos
-- ============================================================================
-- Generado el 2026-11-21 a partir del backend en uso por la aplicación.
--
-- Para qué sirve:
--   Recrea en una base de datos nueva las 12 tablas, las claves, los índices,
--   las políticas de seguridad por usuario (RLS) y el depósito de archivos
--   que usa CEGOZ Study.
--
-- Requisitos:
--   - Una base de datos de Supabase (o Postgres con los roles
--     anon, authenticated y service_role, y el schema auth de Supabase).
--   - Ejecutar este archivo completo antes de arrancar la app.
--
-- Orden: tablas -> claves -> índices -> RLS y políticas -> permisos -> storage.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- 1. Tablas
-- ---------------------------------------------------------------------------

create table public.subjects (
  id uuid not null default gen_random_uuid(),
  user_id uuid not null default auth.uid(),
  name text not null,
  color text not null default 'blue'::text,
  created_at timestamp with time zone not null default now()
);

create table public.topics (
  id uuid not null default gen_random_uuid(),
  user_id uuid not null default auth.uid(),
  subject_id uuid not null,
  name text not null,
  created_at timestamp with time zone not null default now()
);

create table public.documents (
  id uuid not null default gen_random_uuid(),
  user_id uuid not null default auth.uid(),
  topic_id uuid not null,
  title text not null,
  source_type text not null,
  storage_path text,
  mime_type text,
  size_bytes bigint,
  content text not null default ''::text,
  char_count integer not null default 0,
  summary text,
  key_concepts jsonb not null default '[]'::jsonb,
  created_at timestamp with time zone not null default now(),
  updated_at timestamp with time zone not null default now()
);

create table public.study_materials (
  id uuid not null default gen_random_uuid(),
  user_id uuid not null default auth.uid(),
  topic_id uuid not null,
  kind text not null,
  title text not null,
  content text not null default ''::text,
  data jsonb,
  created_at timestamp with time zone not null default now()
);

create table public.class_sessions (
  id uuid not null default gen_random_uuid(),
  user_id uuid not null default auth.uid(),
  topic_id uuid not null,
  title text not null default 'Clase'::text,
  progress_note text,
  created_at timestamp with time zone not null default now(),
  updated_at timestamp with time zone not null default now()
);

create table public.class_messages (
  id uuid not null default gen_random_uuid(),
  user_id uuid not null default auth.uid(),
  session_id uuid not null,
  role text not null,
  kind text not null default 'message'::text,
  content text not null,
  created_at timestamp with time zone not null default now()
);

create table public.exams (
  id uuid not null default gen_random_uuid(),
  user_id uuid not null,
  topic_id uuid not null,
  difficulty text not null,
  question_count integer not null,
  question_types jsonb not null default '[]'::jsonb,
  status text not null default 'en_curso'::text,
  score numeric(4,2),
  feedback text,
  created_at timestamp with time zone not null default now(),
  completed_at timestamp with time zone
);

create table public.questions (
  id uuid not null default gen_random_uuid(),
  user_id uuid not null,
  topic_id uuid not null,
  exam_id uuid,
  source text not null,
  "position" integer not null default 0,
  qtype text not null,
  difficulty text not null,
  prompt text not null,
  options jsonb,
  concept text,
  user_answer text,
  is_correct boolean,
  score numeric(4,3),
  feedback text,
  answered_at timestamp with time zone,
  retry_of uuid,
  created_at timestamp with time zone not null default now()
);

-- Las soluciones no son accesibles desde el cliente: esta tabla no tiene
-- ninguna política de lectura, solo las funciones de servidor la consultan.
create table public.question_keys (
  question_id uuid not null,
  correct_answer text not null,
  explanation text not null,
  rubric text
);

create table public.concept_mastery (
  id uuid not null default gen_random_uuid(),
  user_id uuid not null default auth.uid(),
  topic_id uuid not null,
  concept text not null,
  correct_count integer not null default 0,
  incorrect_count integer not null default 0,
  last_seen_at timestamp with time zone not null default now()
);

create table public.study_activity (
  id uuid not null default gen_random_uuid(),
  user_id uuid not null default auth.uid(),
  topic_id uuid,
  kind text not null,
  title text not null,
  score numeric(4,2),
  details jsonb,
  created_at timestamp with time zone not null default now()
);

create table public.profiles (
  id uuid not null,
  display_name text not null default ''::text,
  level text not null default 'intermedio'::text,
  created_at timestamp with time zone not null default now(),
  updated_at timestamp with time zone not null default now()
);

-- ---------------------------------------------------------------------------
-- 2. Claves primarias, únicas y ajenas
-- ---------------------------------------------------------------------------

alter table only public.subjects add constraint subjects_pkey primary key (id);
alter table only public.topics add constraint topics_pkey primary key (id);
alter table only public.documents add constraint documents_pkey primary key (id);
alter table only public.study_materials add constraint study_materials_pkey primary key (id);
alter table only public.class_sessions add constraint class_sessions_pkey primary key (id);
alter table only public.class_messages add constraint class_messages_pkey primary key (id);
alter table only public.exams add constraint exams_pkey primary key (id);
alter table only public.questions add constraint questions_pkey primary key (id);
alter table only public.question_keys add constraint question_keys_pkey primary key (question_id);
alter table only public.concept_mastery add constraint concept_mastery_pkey primary key (id);
alter table only public.study_activity add constraint study_activity_pkey primary key (id);
alter table only public.profiles add constraint profiles_pkey primary key (id);

alter table only public.concept_mastery
  add constraint concept_mastery_user_id_topic_id_concept_key
  unique (user_id, topic_id, concept);

alter table only public.topics
  add constraint topics_subject_id_fkey foreign key (subject_id)
  references public.subjects(id) on delete cascade;

alter table only public.documents
  add constraint documents_topic_id_fkey foreign key (topic_id)
  references public.topics(id) on delete cascade;

alter table only public.study_materials
  add constraint study_materials_topic_id_fkey foreign key (topic_id)
  references public.topics(id) on delete cascade;

alter table only public.class_sessions
  add constraint class_sessions_topic_id_fkey foreign key (topic_id)
  references public.topics(id) on delete cascade;

alter table only public.class_messages
  add constraint class_messages_session_id_fkey foreign key (session_id)
  references public.class_sessions(id) on delete cascade;

alter table only public.exams
  add constraint exams_topic_id_fkey foreign key (topic_id)
  references public.topics(id) on delete cascade;

alter table only public.questions
  add constraint questions_topic_id_fkey foreign key (topic_id)
  references public.topics(id) on delete cascade;

alter table only public.questions
  add constraint questions_exam_id_fkey foreign key (exam_id)
  references public.exams(id) on delete cascade;

alter table only public.question_keys
  add constraint question_keys_question_id_fkey foreign key (question_id)
  references public.questions(id) on delete cascade;

alter table only public.concept_mastery
  add constraint concept_mastery_topic_id_fkey foreign key (topic_id)
  references public.topics(id) on delete cascade;

alter table only public.study_activity
  add constraint study_activity_topic_id_fkey foreign key (topic_id)
  references public.topics(id) on delete cascade;

alter table only public.profiles
  add constraint profiles_id_fkey foreign key (id)
  references auth.users(id) on delete cascade;

-- ---------------------------------------------------------------------------
-- 3. Índices de consulta
-- ---------------------------------------------------------------------------

create index class_messages_session_idx on public.class_messages using btree (session_id, created_at);
create index class_sessions_user_idx on public.class_sessions using btree (user_id);
create index documents_topic_idx on public.documents using btree (topic_id);
create index documents_user_idx on public.documents using btree (user_id);
create index exams_user_idx on public.exams using btree (user_id, created_at desc);
create index questions_exam_idx on public.questions using btree (exam_id, "position");
create index questions_user_idx on public.questions using btree (user_id, created_at desc);
create index study_activity_user_idx on public.study_activity using btree (user_id, created_at desc);
create index study_materials_user_idx on public.study_materials using btree (user_id, created_at desc);
create index subjects_user_idx on public.subjects using btree (user_id);
create index topics_subject_idx on public.topics using btree (subject_id);
create index topics_user_idx on public.topics using btree (user_id);

-- ---------------------------------------------------------------------------
-- 4. Seguridad por usuario (RLS)
-- ---------------------------------------------------------------------------
-- Cada estudiante solo ve y modifica sus propias filas.

alter table public.subjects enable row level security;
alter table public.topics enable row level security;
alter table public.documents enable row level security;
alter table public.study_materials enable row level security;
alter table public.class_sessions enable row level security;
alter table public.class_messages enable row level security;
alter table public.exams enable row level security;
alter table public.questions enable row level security;
alter table public.question_keys enable row level security;
alter table public.concept_mastery enable row level security;
alter table public.study_activity enable row level security;
alter table public.profiles enable row level security;

create policy "Own subjects" on public.subjects as PERMISSIVE for ALL to authenticated
  using ((auth.uid() = user_id)) with check ((auth.uid() = user_id));

create policy "Own topics" on public.topics as PERMISSIVE for ALL to authenticated
  using ((auth.uid() = user_id)) with check ((auth.uid() = user_id));

create policy "Own documents" on public.documents as PERMISSIVE for ALL to authenticated
  using ((auth.uid() = user_id)) with check ((auth.uid() = user_id));

create policy "Own materials" on public.study_materials as PERMISSIVE for ALL to authenticated
  using ((auth.uid() = user_id)) with check ((auth.uid() = user_id));

create policy "Own class sessions" on public.class_sessions as PERMISSIVE for ALL to authenticated
  using ((auth.uid() = user_id)) with check ((auth.uid() = user_id));

create policy "Own class messages" on public.class_messages as PERMISSIVE for ALL to authenticated
  using ((auth.uid() = user_id)) with check ((auth.uid() = user_id));

create policy "Own exams select" on public.exams as PERMISSIVE for SELECT to authenticated
  using ((auth.uid() = user_id));

create policy "Own exams delete" on public.exams as PERMISSIVE for DELETE to authenticated
  using ((auth.uid() = user_id));

create policy "Own questions select" on public.questions as PERMISSIVE for SELECT to authenticated
  using ((auth.uid() = user_id));

create policy "Own mastery" on public.concept_mastery as PERMISSIVE for ALL to authenticated
  using ((auth.uid() = user_id)) with check ((auth.uid() = user_id));

create policy "Own activity" on public.study_activity as PERMISSIVE for ALL to authenticated
  using ((auth.uid() = user_id)) with check ((auth.uid() = user_id));

create policy "Own profile select" on public.profiles as PERMISSIVE for SELECT to authenticated
  using ((auth.uid() = id));

create policy "Own profile insert" on public.profiles as PERMISSIVE for INSERT to authenticated
  with check ((auth.uid() = id));

create policy "Own profile update" on public.profiles as PERMISSIVE for UPDATE to authenticated
  using ((auth.uid() = id)) with check ((auth.uid() = id));

-- Sin política en public.question_keys: nadie la lee desde el cliente.
-- Las soluciones solo se leen desde el servidor, con la clave privilegiada.

-- ---------------------------------------------------------------------------
-- 5. Permisos de acceso
-- ---------------------------------------------------------------------------

grant select on public.subjects to anon, authenticated, service_role;
grant select on public.topics to anon, authenticated, service_role;
grant select on public.documents to anon, authenticated, service_role;
grant select on public.study_materials to anon, authenticated, service_role;
grant select on public.class_sessions to anon, authenticated, service_role;
grant select on public.class_messages to anon, authenticated, service_role;
grant select on public.exams to anon, authenticated, service_role;
grant select on public.questions to anon, authenticated, service_role;
grant select on public.question_keys to anon, authenticated, service_role;
grant select on public.concept_mastery to anon, authenticated, service_role;
grant select on public.study_activity to anon, authenticated, service_role;
grant select on public.profiles to anon, authenticated, service_role;

-- ---------------------------------------------------------------------------
-- 6. Almacenamiento de archivos (temarios subidos)
-- ---------------------------------------------------------------------------
-- Depósito privado: los PDF, fotos y Word se guardan aquí y solo su dueño
-- puede leerlos, con un límite de 25 MB por archivo.

insert into storage.buckets (id, name, public, file_size_limit)
values ('temarios', 'temarios', false, 26214400)
on conflict (id) do nothing;
